/**
 * nodalia-pack.js - HArvest Nodalia renderer pack.
 *
 * Inspired by the Nodalia Cards project by Daniel Miguel Tejedor.
 * Bold saturated color gradients, concentric circle depth, and
 * entity-driven color palettes.
 *
 * Loaded at runtime via script injection; references window.HArvest globals.
 */
(function () {
  "use strict";

  const HArvest = window.HArvest;
  if (!HArvest || !HArvest.renderers || !HArvest.renderers.BaseCard) {
    console.warn("[HArvest Nodalia] HArvest not found - pack not loaded.");
    return;
  }

  const BaseCard = HArvest.renderers.BaseCard;

  // ---------------------------------------------------------------------------
  // Helpers
  // ---------------------------------------------------------------------------

  const _esc = window.HArvest.esc;

  function _debounce(fn, ms) {
    let timer = null;
    let lastCtx = null;
    let lastArgs = null;
    function wrapped(...args) {
      lastCtx = this;
      lastArgs = args;
      if (timer) clearTimeout(timer);
      timer = setTimeout(() => { timer = null; fn.apply(lastCtx, lastArgs); lastArgs = null; }, ms);
    }
    wrapped.flush = function () {
      if (timer !== null) {
        clearTimeout(timer);
        timer = null;
        if (lastArgs) { fn.apply(lastCtx, lastArgs); lastArgs = null; }
      }
    };
    return wrapped;
  }

  function _capitalize(s) {
    return s ? s.charAt(0).toUpperCase() + s.slice(1).replace(/_/g, " ") : "";
  }

  function _clamp(val, min, max) {
    return Math.min(max, Math.max(min, val));
  }

  function _triggerBounce(el) {
    if (!el) return;
    el.classList.remove("is-pressing");
    void el.getBoundingClientRect();
    el.classList.add("is-pressing");
    el.addEventListener("animationend", () => {
      el.classList.remove("is-pressing");
    }, { once: true });
  }

  function _setControlsCollapsed(root, collapsed) {
    const shell = root.querySelector(".ndl-controls-shell");
    if (shell) shell.setAttribute("data-collapsed", String(collapsed));
  }

  // ---------------------------------------------------------------------------
  // Slider drag geometry (ported verbatim from danielmigueltejedor/nodalia-cards
  // beta @ nodalia-light-card.js). These produce smoother touch drags than the
  // native input event because we cache getBoundingClientRect at pointerdown
  // and resolve subsequent moves against the cached rect.
  // ---------------------------------------------------------------------------

  function _getRangeValueFromClientX(slider, clientX) {
    const rect = slider.getBoundingClientRect();
    if (!rect.width) {
      return Number(slider.value || 0);
    }
    const min = Number(slider.min || 0);
    const max = Number(slider.max || 100);
    const step = slider.step === "any" ? 0 : Number(slider.step || 1);
    const ratio = _clamp((clientX - rect.left) / rect.width, 0, 1);
    let nextValue = min + ((max - min) * ratio);
    if (Number.isFinite(step) && step > 0) {
      nextValue = min + (Math.round((nextValue - min) / step) * step);
    }
    return _clamp(nextValue, min, max);
  }

  function _getSliderDragGeometry(slider) {
    const rect = slider.getBoundingClientRect();
    return {
      left: rect.left,
      width: rect.width,
      min: Number(slider.min || 0),
      max: Number(slider.max || 100),
      step: slider.step === "any" ? 0 : Number(slider.step || 1),
    };
  }

  function _getRangeValueFromGeometry(geometry, currentValue, clientX) {
    if (!geometry || !Number.isFinite(geometry.width) || geometry.width <= 0) {
      return Number(currentValue || 0);
    }
    const ratio = _clamp((clientX - geometry.left) / geometry.width, 0, 1);
    let nextValue = geometry.min + ((geometry.max - geometry.min) * ratio);
    if (Number.isFinite(geometry.step) && geometry.step > 0) {
      nextValue = geometry.min + (Math.round((nextValue - geometry.min) / geometry.step) * geometry.step);
    }
    return _clamp(nextValue, geometry.min, geometry.max);
  }

  // ---------------------------------------------------------------------------
  // Color space + temperature conversions (ported verbatim from Daniel's pack)
  // ---------------------------------------------------------------------------

  function _miredToKelvin(value) {
    return value > 0 ? Math.round(1000000 / value) : 0;
  }

  function _kelvinToMired(value) {
    return value > 0 ? Math.round(1000000 / value) : 0;
  }

  function _rgbToHs(rgb) {
    if (!Array.isArray(rgb) || rgb.length !== 3) return null;
    const [rawRed, rawGreen, rawBlue] = rgb.map((v) => _clamp(Number(v) / 255, 0, 1));
    const max = Math.max(rawRed, rawGreen, rawBlue);
    const min = Math.min(rawRed, rawGreen, rawBlue);
    const delta = max - min;
    let hue = 0;
    if (delta !== 0) {
      if (max === rawRed) {
        hue = ((rawGreen - rawBlue) / delta) % 6;
      } else if (max === rawGreen) {
        hue = (rawBlue - rawRed) / delta + 2;
      } else {
        hue = (rawRed - rawGreen) / delta + 4;
      }
      hue *= 60;
      if (hue < 0) hue += 360;
    }
    const saturation = max === 0 ? 0 : (delta / max) * 100;
    return [Math.round(hue), Math.round(saturation)];
  }

  // ---------------------------------------------------------------------------
  // Layout observer - toggles ndl-compact / ndl-mini classes on [part=card]
  // based on container width. Cards opt-in by calling _layoutObserver(this) at
  // the end of render(). ResizeObserver fires sync at observe() time so the
  // initial class is set before applyState runs. Returns a teardown function
  // that should be called from destroy().
  // ---------------------------------------------------------------------------

  const _LAYOUT_BREAKPOINTS = { mini: 110, compact: 150 };

  function _layoutObserver(card) {
    const root = card?.root;
    if (!root || typeof ResizeObserver === "undefined") return () => {};
    const cardEl = root.querySelector("[part=card]");
    if (!cardEl) return () => {};

    const apply = (width) => {
      const isMini = width > 0 && width <= _LAYOUT_BREAKPOINTS.mini;
      const isCompact = !isMini && width > 0 && width <= _LAYOUT_BREAKPOINTS.compact;
      cardEl.classList.toggle("ndl-mini", isMini);
      cardEl.classList.toggle("ndl-compact", isCompact);
    };

    const observer = new ResizeObserver((entries) => {
      for (const entry of entries) {
        apply(entry.contentRect.width);
      }
    });
    observer.observe(cardEl);
    return () => observer.disconnect();
  }

  // ---------------------------------------------------------------------------
  // Domain color palettes - each domain gets its own color world
  // ---------------------------------------------------------------------------

  const _DOMAIN_COLORS = {
    light:         { from: "#ffd166", to: "#f4b55f", accent: "#e6a040" },
    switch:        { from: "#71c0ff", to: "#4dabf7", accent: "#3b9ae8" },
    input_boolean: { from: "#71c0ff", to: "#4dabf7", accent: "#3b9ae8" },
    lock:          { from: "#71c0ff", to: "#4dabf7", accent: "#3b9ae8" },
    fan:           { from: "#a5d8ff", to: "#71c0ff", accent: "#71c0ff" },
    climate:       { from: "#f5c77e", to: "#f59f42", accent: "#e8872e" },
    sensor:        { from: "#a5d8ff", to: "#71c0ff", accent: "#4dabf7" },
    binary_sensor: { from: "#b2f2bb", to: "#69db7c", accent: "#51cf66" },
    cover:         { from: "#d0bfff", to: "#b197fc", accent: "#9775fa" },
    media_player:  { from: "#ffd8a8", to: "#ffc078", accent: "#ffa94d" },
    input_number:  { from: "#c5f6fa", to: "#99e9f2", accent: "#66d9e8" },
    input_select:  { from: "#d3f9d8", to: "#b2f2bb", accent: "#8ce99a" },
    timer:         { from: "#e5dbff", to: "#d0bfff", accent: "#b197fc" },
    remote:        { from: "#dee2e6", to: "#ced4da", accent: "#adb5bd" },
    harvest_action:{ from: "#d0bfff", to: "#b197fc", accent: "#9775fa" },
  };

  const _DEFAULT_COLORS = { from: "#d0ebff", to: "#a5d8ff", accent: "#74c0fc" };

  function _colorsFor(domain) {
    return _DOMAIN_COLORS[domain] ?? _DEFAULT_COLORS;
  }

  // Accent color derived from light entity state (rgb_color, hs_color, color_temp).
  function _lightAccent(state, attrs) {
    if (state !== "on") return null;
    if (attrs.rgb_color) {
      const [r, g, b] = attrs.rgb_color;
      return `rgb(${r}, ${g}, ${b})`;
    }
    if (attrs.hs_color) {
      return `hsl(${attrs.hs_color[0]}, ${Math.max(attrs.hs_color[1], 50)}%, 55%)`;
    }
    const kelvin = attrs.color_temp_kelvin ?? (attrs.color_temp ? Math.round(1000000 / attrs.color_temp) : null);
    if (kelvin) {
      if (kelvin >= 5200) return "#8fd3ff";
      if (kelvin <= 3000) return "#f4b55f";
      return "#ffd166";
    }
    return "#ffd166";
  }

  // HVAC-specific palettes for climate card.
  // Daniel's exact mode palette. Off uses a muted grey so the card reads as
  // visibly "asleep" until a mode is selected.
  const _HVAC_PALETTE = {
    heat:      { accent: "#f59f42" },
    cool:      { accent: "#71c0ff" },
    heat_cool: { accent: "#c5a66f" },
    auto:      { accent: "#c5a66f" },
    dry:       { accent: "#7fd0c8" },
    fan_only:  { accent: "#83d39c" },
    off:       { accent: "#adb5bd" },
  };

  const _HVAC_ICONS = {
    heat: "mdi:fire",
    cool: "mdi:snowflake",
    heat_cool: "mdi:autorenew",
    auto: "mdi:autorenew",
    dry: "mdi:water-percent",
    fan_only: "mdi:fan",
    off: "mdi:power",
  };

  // ---------------------------------------------------------------------------
  // Shared Nodalia CSS
  // ---------------------------------------------------------------------------

  const NODALIA_BASE = /* css */`
    [part=card] {
      border-radius: var(--hrv-card-radius, 28px) !important;
      position: relative;
      overflow: hidden;
      padding: var(--hrv-card-padding, 14px) !important;
      background: var(--hrv-color-card-background, linear-gradient(135deg,
                  color-mix(in srgb, var(--hrv-color-primary, #6366f1) 6%, var(--hrv-color-surface, #ffffff)) 0%,
                  var(--hrv-color-surface, #ffffff) 100%));
      border: var(--hrv-card-border, 1px solid color-mix(in srgb, var(--hrv-color-text, #1a1a2e) 6%, transparent));
      box-shadow: var(--hrv-card-shadow,
                  inset 0 1px 0 rgba(255,255,255,0.4)) !important;
      isolation: isolate;
      transition: background var(--hrv-motion-card, 0.6s cubic-bezier(0.4,0,0.2,1)),
                  border-color var(--hrv-motion-card, 0.6s cubic-bezier(0.4,0,0.2,1)),
                  box-shadow  var(--hrv-motion-card, 0.6s cubic-bezier(0.4,0,0.2,1));
    }
    [part=card][data-state=on] {
      background: var(--hrv-color-card-background-on, linear-gradient(135deg,
                  color-mix(in srgb, var(--hrv-color-accent, #6366f1) 18%, var(--hrv-color-surface, #ffffff)) 0%,
                  var(--hrv-color-surface, #ffffff) 100%));
    }

    [part=card]::before {
      content: "";
      position: absolute;
      inset: 0;
      border-radius: inherit;
      pointer-events: none;
      z-index: 0;
      background: linear-gradient(180deg,
                  color-mix(in srgb, var(--hrv-color-text, #1a1a2e) 4%, transparent),
                  rgba(255,255,255,0));
    }
    [part=card][data-state=on]::before {
      background: linear-gradient(180deg,
                  color-mix(in srgb, var(--ndl-accent, var(--hrv-color-accent, #6366f1)) 18%,
                            color-mix(in srgb, var(--hrv-color-text, #1a1a2e) 6%, transparent)),
                  rgba(255,255,255,0));
    }

    [part=card] > * { position: relative; z-index: 1; }

    [part=card-header] {
      display: grid;
      grid-template-columns: 58px minmax(0, 1fr) auto;
      align-items: center;
      gap: 10px;
      margin-bottom: 0;
    }

    [part=card-icon] {
      width: 58px;
      height: 58px;
      flex-shrink: 0;
      display: flex;
      align-items: center;
      justify-content: center;
      border-radius: 50%;
      background: var(--hrv-glass-bg, linear-gradient(180deg, rgba(255,255,255,0.6) 0%, rgba(255,255,255,0.35) 100%));
      border: 1px solid var(--hrv-glass-border, rgba(255,255,255,0.3));
      box-shadow: var(--hrv-glass-shadow,
                  0 2px 6px rgba(0,0,0,0.08),
                  0 1px 2px rgba(0,0,0,0.05),
                  inset 0 1px 0 rgba(255,255,255,0.5));
      cursor: pointer;
      transition: background var(--hrv-transition-speed, 300ms) ease,
                  box-shadow var(--hrv-transition-speed, 300ms) ease;
    }
    [part=card][data-state=on] [part=card-icon] {
      background: color-mix(in srgb,
                  var(--ndl-accent, var(--hrv-color-accent, #6366f1)) 24%,
                  color-mix(in srgb, var(--hrv-color-text, #1a1a2e) 8%, transparent));
    }
    [part=card-icon] svg {
      width: 28px;
      height: 28px;
      color: var(--ndl-fg, var(--hrv-color-text, #1a1a2e));
      opacity: 0.8;
    }

    [part=card-name] {
      font-size: 15px;
      font-weight: 600;
      letter-spacing: 0.01em;
      color: var(--ndl-fg, var(--hrv-color-text, #1a1a2e));
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }

    /* Glass chip - color-mix tinted pill used for state labels and active values */
    .ndl-chip {
      display: inline-flex;
      align-items: center;
      height: 24px;
      padding: 0 10px;
      border-radius: 999px;
      background: var(--hrv-chip-bg, color-mix(in srgb, var(--hrv-color-primary, #6366f1) 12%, transparent));
      border: var(--hrv-chip-border, 1px solid color-mix(in srgb, var(--hrv-color-text, #1a1a2e) 10%, transparent));
      backdrop-filter: blur(12px);
      -webkit-backdrop-filter: blur(12px);
      font-size: 11px;
      font-weight: 700;
      color: var(--ndl-fg, var(--hrv-color-text, #1a1a2e));
      white-space: nowrap;
      transition: background var(--hrv-transition-speed, 300ms) ease,
                  border-color var(--hrv-transition-speed, 300ms) ease;
    }
    .ndl-chip[data-active=true] {
      background: var(--hrv-chip-bg-active, color-mix(in srgb, var(--hrv-color-primary, #6366f1) 24%, transparent));
      border: var(--hrv-chip-border-active, 1px solid color-mix(in srgb, var(--hrv-color-primary, #6366f1) 60%, transparent));
    }

    /* Circular icon buttons used across cards */
    .ndl-circle-btn {
      width: 40px;
      height: 40px;
      padding: 0;
      border: 1px solid var(--hrv-glass-border, rgba(255,255,255,0.3));
      border-radius: 50%;
      background: var(--hrv-glass-bg, linear-gradient(180deg, rgba(255,255,255,0.6) 0%, rgba(255,255,255,0.35) 100%));
      backdrop-filter: blur(8px);
      -webkit-backdrop-filter: blur(8px);
      cursor: pointer;
      display: flex;
      align-items: center;
      justify-content: center;
      transition: background var(--hrv-transition-speed, 200ms) ease,
                  box-shadow var(--hrv-transition-speed, 200ms) ease,
                  border-color var(--hrv-transition-speed, 200ms) ease;
      box-shadow: var(--hrv-glass-shadow,
                  0 2px 6px rgba(0,0,0,0.08),
                  0 1px 2px rgba(0,0,0,0.05));
    }
    .ndl-circle-btn:hover {
      background: var(--hrv-glass-bg-hover, linear-gradient(180deg, rgba(255,255,255,0.75) 0%, rgba(255,255,255,0.5) 100%));
    }
    .ndl-circle-btn.is-pressing {
      animation: ndl-btn-bounce var(--hrv-motion-bounce, 0.35s cubic-bezier(0.2, 0.9, 0.24, 1)) forwards;
    }
    .ndl-circle-btn > [part] {
      display: flex;
      align-items: center;
      justify-content: center;
    }
    .ndl-circle-btn svg {
      width: 20px;
      height: 20px;
      color: var(--ndl-fg, var(--hrv-color-text, #1a1a2e));
    }
    .ndl-circle-btn[data-active=true] {
      background: color-mix(in srgb, var(--hrv-color-primary, #6366f1) 32%, var(--hrv-color-surface, #ffffff));
      border-color: color-mix(in srgb, var(--hrv-color-primary, #6366f1) 60%, transparent);
    }
    .ndl-circle-btn.ndl-large {
      width: 50px;
      height: 50px;
    }
    .ndl-circle-btn.ndl-large svg {
      width: 24px;
      height: 24px;
    }

    @keyframes ndl-fade-up {
      0%   { opacity: 0; transform: translate3d(0, 14px, 0); }
      100% { opacity: 1; transform: translate3d(0, 0, 0); }
    }

    @keyframes ndl-btn-bounce {
      0%   { transform: scale(1); }
      40%  { transform: scale(0.85); }
      70%  { transform: scale(1.06); }
      100% { transform: scale(1); }
    }

    @keyframes ndl-power-up {
      0%   { opacity: 0.6; transform: scale(0.97); }
      50%  { opacity: 1; transform: scale(1.02); }
      100% { opacity: 1; transform: scale(1); }
    }

    @keyframes ndl-power-down {
      0%   { opacity: 1; transform: scale(1); }
      100% { opacity: 0.85; transform: scale(0.98); }
    }

    @keyframes ndl-glow-in {
      0%   { box-shadow: 0 4px 20px rgba(0,0,0,0.08), inset 0 1px 0 rgba(255,255,255,0.5), 0 0 0 0 transparent; }
      100% { box-shadow: 0 4px 20px rgba(0,0,0,0.08), inset 0 1px 0 rgba(255,255,255,0.5), 0 0 20px 4px var(--ndl-glow, rgba(255,209,102,0.3)); }
    }

    /* Mode swap animations - used by light card mode toggle, also reusable for any view-swap */
    @keyframes ndl-mode-out {
      0%   { opacity: 1; transform: scaleX(1); }
      100% { opacity: 0; transform: scaleX(0.18); }
    }
    @keyframes ndl-mode-in {
      0%   { opacity: 0; transform: scaleX(0.18); }
      100% { opacity: 1; transform: scaleX(1); }
    }
    .ndl-mode-out {
      animation: ndl-mode-out var(--hrv-motion-mode-out, 0.18s cubic-bezier(0.38, 0, 0.24, 1)) both;
      transform-origin: right center;
    }
    .ndl-mode-in {
      animation: ndl-mode-in var(--hrv-motion-mode-in, 0.22s cubic-bezier(0.22, 0.84, 0.26, 1)) both;
      transform-origin: right center;
    }

    .ndl-controls-shell {
      overflow: hidden;
      transition: max-height 0.45s cubic-bezier(0.22, 0.84, 0.26, 1),
                  margin-top 0.45s cubic-bezier(0.22, 0.84, 0.26, 1),
                  opacity 0.35s ease;
    }
    .ndl-controls-shell[data-collapsed="true"] {
      max-height: 0 !important;
      margin-top: 0 !important;
      opacity: 0;
      pointer-events: none;
    }
    .ndl-controls-shell[data-collapsed="false"] {
      max-height: 400px;
      margin-top: 12px;
      opacity: 1;
    }

    [part=card].ndl-powering-up {
      animation: ndl-power-up var(--hrv-motion-power, 0.5s cubic-bezier(0.24,0.82,0.25,1)) forwards;
    }
    [part=card].ndl-powering-down {
      animation: ndl-power-down 0.3s ease forwards;
    }

    /* Compact + mini layout breakpoints (toggled by _layoutObserver) */
    [part=card].ndl-compact {
      padding: 10px !important;
    }
    [part=card].ndl-compact [part=card-header] {
      grid-template-columns: 44px minmax(0, 1fr) auto;
      gap: 8px;
    }
    [part=card].ndl-compact [part=card-icon] {
      width: 44px;
      height: 44px;
    }
    [part=card].ndl-compact [part=card-icon] svg {
      width: 22px;
      height: 22px;
    }
    [part=card].ndl-compact .ndl-chip {
      height: 20px;
      padding: 0 8px;
      font-size: 10px;
    }
    [part=card].ndl-mini {
      padding: 8px !important;
    }
    [part=card].ndl-mini [part=card-header] {
      grid-template-columns: 36px minmax(0, 1fr);
      gap: 6px;
    }
    [part=card].ndl-mini [part=card-icon] {
      width: 36px;
      height: 36px;
    }
    [part=card].ndl-mini [part=card-icon] svg {
      width: 18px;
      height: 18px;
    }
    [part=card].ndl-mini [part=card-name] {
      font-size: 13px;
    }
    [part=card].ndl-mini .ndl-chip {
      display: none;
    }

    /* Shared thick slider */
    .ndl-slider-wrap {
      width: 100%;
      height: 56px;
      border-radius: 28px;
      background: color-mix(in srgb, var(--hrv-color-text, #1a1a2e) 8%, transparent);
      position: relative;
      overflow: hidden;
      box-shadow: inset 0 2px 4px rgba(0,0,0,0.06);
    }
    .ndl-slider-track {
      position: absolute;
      top: 50%;
      left: 14px;
      right: 14px;
      height: 16px;
      transform: translateY(-50%);
      border-radius: 8px;
      overflow: hidden;
      pointer-events: none;
    }
    .ndl-slider-track-fill {
      height: 100%;
      border-radius: 8px;
      transition: width 0.15s ease;
    }
    .ndl-slider-input {
      position: absolute;
      inset: 0;
      width: 100%;
      height: 100%;
      -webkit-appearance: none;
      appearance: none;
      background: transparent;
      cursor: pointer;
      margin: 0;
    }
    .ndl-slider-input::-webkit-slider-thumb {
      -webkit-appearance: none;
      width: 28px;
      height: 28px;
      border-radius: 50%;
      background: white;
      border: none;
      box-shadow: 0 2px 8px rgba(0,0,0,0.2), 0 0 0 2px rgba(255,255,255,0.8);
      cursor: grab;
    }
    .ndl-slider-input::-webkit-slider-thumb:active {
      cursor: grabbing;
      box-shadow: 0 2px 12px rgba(0,0,0,0.3), 0 0 0 3px rgba(255,255,255,0.9);
    }
    .ndl-slider-input::-moz-range-thumb {
      width: 28px;
      height: 28px;
      border-radius: 50%;
      background: white;
      border: none;
      box-shadow: 0 2px 8px rgba(0,0,0,0.2), 0 0 0 2px rgba(255,255,255,0.8);
      cursor: grab;
    }

    /* History graph - tinted with the per-domain accent for visual identity.
       The framework's graph SVG hardcodes fill="var(--hrv-color-primary)" on
       polygon/polyline/rect/path elements; redefining --hrv-color-primary at
       the history-zone scope re-routes the inline attribute through our
       per-card --ndl-accent. The fill / stroke opacities baked into the
       framework markup (10%/60%) carry through and read correctly. */
    [part=history-zone] {
      --hrv-color-primary: var(--ndl-accent, var(--hrv-color-accent, #6366f1));
      background: color-mix(in srgb, var(--hrv-color-text, #1a1a2e) 5%, transparent);
      border-radius: 14px;
      padding: 8px;
      margin-top: 8px;
    }
    [part=history-zone] svg line[stroke] {
      stroke: color-mix(in srgb, var(--hrv-color-text, #1a1a2e) 6%, transparent);
      stroke-dasharray: 4 3;
    }
    [part=history-zone] svg text {
      font-size: 10px;
      opacity: 0.5;
    }
    [part=history-zone] svg polyline,
    [part=history-zone] svg path.hrv-graph-line {
      stroke-width: 2.5;
    }
    [part=history-zone] svg .hrv-graph-fill {
      opacity: 0.35;
    }
    [part=history-zone] svg circle.hrv-graph-dot {
      r: 3;
      fill: white;
      stroke-width: 2;
    }

    :where(button, input, select, textarea, [role=slider]):focus-visible {
      outline: 2px solid var(--ndl-accent, var(--hrv-color-primary, #6366f1)) !important;
      outline-offset: 3px !important;
    }

    @media (prefers-reduced-motion: reduce) {
      *, *::before, *::after {
        transition: none !important;
        animation: none !important;
        scroll-behavior: auto !important;
      }
    }
  `;

  // Row layout overrides for entities block
  const NDL_ROW_CSS = /* css */`
    :host([layout=row]) {
      border-radius: var(--hrv-radius-m, 12px) !important;
      overflow: hidden !important;
      margin: 3px 6px !important;
    }
    :host([layout=row]) [part=card] {
      background: var(--hrv-color-surface-tint, rgba(88,91,216,0.06)) !important;
      box-shadow: none !important;
      border: var(--hrv-card-border, 1px solid color-mix(in srgb, var(--hrv-color-text) 6%, transparent)) !important;
      padding: 8px 14px 8px 10px !important;
    }
    :host([layout=row]) [part=card]::before { display: none; }
  `;

  // Companion dots
  const COMPANION_DOT_STYLES = /* css */`
    [part=companion-zone] {
      display: flex;
      flex-wrap: wrap;
      justify-content: center;
      gap: 10px;
      padding: 10px 0 0;
      border-top: none;
      margin-top: 8px;
    }
    [part=companion-zone]:empty { display: none; }
    [part=companion] {
      width: 30px;
      height: 30px;
      border-radius: 50%;
      background: rgba(255,255,255,0.5);
      backdrop-filter: blur(6px);
      border: none;
      padding: 0;
      cursor: default;
      flex-shrink: 0;
      box-shadow: 0 1px 4px rgba(0,0,0,0.06);
      transition: box-shadow 0.2s ease, background 0.2s ease;
    }
    [part=companion][data-on=true] {
      background: rgba(255,255,255,0.8);
      box-shadow: 0 0 0 2px rgba(255,255,255,0.9), 0 2px 8px rgba(0,0,0,0.1);
    }
    [part=companion][data-interactive=true] { cursor: pointer; }
    [part=companion][data-interactive=true]:hover { background: rgba(255,255,255,0.7); }
    [part=companion-icon]  { display: none; }
    [part=companion-state] { display: none; }
  `;

  function _applyCompanionTooltips(root) {
    root.querySelectorAll("[part=companion]").forEach((el) => {
      el.title = el.getAttribute("aria-label") ?? "";
    });
  }

  // ---------------------------------------------------------------------------
  // Card background - the bold saturated gradient that defines Nodalia
  // ---------------------------------------------------------------------------

  function _applyCardGradient(card, colors, isActive) {
    if (!card) return;
    if (!isActive) {
      card.style.background = `linear-gradient(145deg, var(--ndl-inactive-from, #f0f1f3) 0%, var(--ndl-inactive-to, #e4e5e9) 100%)`;
      card.style.removeProperty("--ndl-fg");
      return;
    }
    card.style.background = `linear-gradient(145deg, ${colors.from} 0%, ${colors.to} 60%, `
      + `color-mix(in srgb, ${colors.to} 85%, white) 100%)`;
    card.style.removeProperty("--ndl-fg");
  }

  function _applyCardGradientCustom(card, fromColor, toColor) {
    if (!card) return;
    card.style.background = `linear-gradient(145deg, ${fromColor} 0%, ${toColor} 60%, `
      + `color-mix(in srgb, ${toColor} 85%, white) 100%)`;
    card.style.removeProperty("--ndl-fg");
  }

  // Radial glow overlay via ::before
  function _glowOverlayCSS() {
    return /* css */`
      [part=card]::before {
        background:
          radial-gradient(ellipse at 15% 20%,
            rgba(255,255,255,0.45) 0%, transparent 55%),
          radial-gradient(ellipse at 85% 80%,
            rgba(255,255,255,0.15) 0%, transparent 50%);
      }
    `;
  }

  // ---------------------------------------------------------------------------
  // Concentric circle gauge (sensor, climate)
  // ---------------------------------------------------------------------------

  function _concentricGaugeSVG(opts) {
    const cx = 100, cy = 105;
    const outerR = 88, midR = 72, innerR = 56;
    const arcR = 72;
    const startAngle = 225, sweepAngle = 270;

    const toRad = (d) => d * Math.PI / 180;
    const ptAt = (a, r) => ({
      x: cx + r * Math.cos(toRad(a)),
      y: cy - r * Math.sin(toRad(a)),
    });

    const arcStart = ptAt(startAngle, arcR);
    const arcEnd = ptAt(startAngle - sweepAngle, arcR);
    const arcD = `M ${arcStart.x} ${arcStart.y} A ${arcR} ${arcR} 0 1 1 ${arcEnd.x} ${arcEnd.y}`;
    const arcLen = 2 * Math.PI * arcR * (sweepAngle / 360);

    return {
      arcD, arcLen, arcR, cx, cy, startAngle, sweepAngle,
      svg: /* html */`
        <svg viewBox="0 0 200 200" class="ndl-gauge-svg">
          <!-- Track arc -->
          <path class="ndl-gauge-track" d="${arcD}" fill="none"
            stroke="rgba(0,0,0,0.08)" stroke-width="14" stroke-linecap="round" />
          <!-- Fill arc -->
          <path class="ndl-gauge-fill" d="${arcD}" fill="none"
            stroke="${opts.fillColor ?? "rgba(0,0,0,0.25)"}"
            stroke-width="14" stroke-linecap="round"
            stroke-dasharray="${arcLen}" stroke-dashoffset="${arcLen}" />
          <!-- Thumb -->
          <circle class="ndl-gauge-thumb" r="8"
            cx="${arcStart.x}" cy="${arcStart.y}"
            fill="white" stroke="rgba(0,0,0,0.1)" stroke-width="1"
            filter="drop-shadow(0 1px 3px rgba(0,0,0,0.2))" />
        </svg>
      `,
    };
  }

  // Update gauge fill + thumb position from a 0-1 fraction.
  function _updateGauge(root, frac, color) {
    const arcR = 72, cx = 100, cy = 110;
    const startAngle = 225, sweepAngle = 270;
    const arcLen = 2 * Math.PI * arcR * (sweepAngle / 360);
    const toRad = (d) => d * Math.PI / 180;

    frac = _clamp(frac, 0, 1);
    const offset = arcLen * (1 - frac);
    const angle = startAngle - frac * sweepAngle;
    const px = cx + arcR * Math.cos(toRad(angle));
    const py = cy - arcR * Math.sin(toRad(angle));

    const fill = root.querySelector(".ndl-gauge-fill");
    const thumb = root.querySelector(".ndl-gauge-thumb");
    if (fill) {
      fill.setAttribute("stroke-dashoffset", String(offset));
      if (color) fill.setAttribute("stroke", color);
    }
    if (thumb) {
      thumb.setAttribute("cx", String(px));
      thumb.setAttribute("cy", String(py));
    }
  }

  // Pointer-to-fraction for dial drag.
  function _pointerToFrac(e, dialEl) {
    const rect = dialEl.getBoundingClientRect();
    const cx = rect.left + rect.width / 2;
    const cy = rect.top + rect.height / 2;
    const dx = e.clientX - cx;
    const dy = -(e.clientY - cy);
    let angle = Math.atan2(dy, dx) * (180 / Math.PI);
    if (angle < 0) angle += 360;
    let swept = 225 - angle;
    if (swept < 0) swept += 360;
    if (swept > 290) return null;
    return _clamp(swept / 270, 0, 1);
  }

  // ---------------------------------------------------------------------------
  // LightCard
  // ---------------------------------------------------------------------------

  const LIGHT_STYLES = /* css */`
    ${NODALIA_BASE}
    ${_glowOverlayCSS()}

    [part=card-body] {
      display: flex;
      flex-direction: column;
    }

    /* Light icon: when on, accent-tinted background using --ndl-accent */
    [part=card][data-state=on] [part=card-icon].ndl-light-icon {
      background: color-mix(in srgb,
                  var(--ndl-accent, var(--hrv-color-accent, #ffd166)) 28%,
                  var(--hrv-glass-bg, rgba(255,255,255,0.6)));
    }

    /* Controls shell - collapses when light is off */
    .ndl-light-controls-shell {
      display: grid;
      gap: 10px;
      overflow: hidden;
      margin-top: 12px;
      max-height: 400px;
      opacity: 1;
      transition: max-height 0.45s cubic-bezier(0.22, 0.84, 0.26, 1),
                  margin-top 0.45s cubic-bezier(0.22, 0.84, 0.26, 1),
                  opacity 0.35s ease;
    }
    .ndl-light-controls-shell[data-collapsed="true"] {
      max-height: 0;
      margin-top: 0;
      opacity: 0;
      pointer-events: none;
    }

    /* Mode panel + the inner element that animates on mode swap */
    .ndl-light-mode-panel {
      display: grid;
      align-items: center;
      min-height: 56px;
      overflow: hidden;
      width: 100%;
    }
    .ndl-light-mode-panel-inner {
      display: grid;
      width: 100%;
      transform-origin: right center;
    }

    /* Slider wrap - the outer pill */
    .ndl-light-slider-wrap {
      align-items: center;
      background: color-mix(in srgb, var(--hrv-color-text, #1a1a2e) 4%, transparent);
      border: 1px solid color-mix(in srgb, var(--hrv-color-text, #1a1a2e) 6%, transparent);
      border-radius: 999px;
      display: grid;
      min-height: 56px;
      padding: 0 16px;
    }
    .ndl-light-slider-shell {
      min-width: 0;
      overflow: visible;
      position: relative;
      width: 100%;
    }

    /* Slider track - the visible bar */
    .ndl-light-slider-track {
      position: absolute;
      top: 50%;
      left: 0;
      right: 0;
      height: 16px;
      transform: translateY(-50%);
      border-radius: 999px;
      pointer-events: none;
      overflow: hidden;
    }
    .ndl-light-slider-track[data-mode="brightness"] {
      background: color-mix(in srgb, var(--hrv-color-text, #1a1a2e) 14%, transparent);
    }
    .ndl-light-slider-track[data-mode="brightness"]::before {
      content: "";
      position: absolute;
      inset: 0;
      border-radius: inherit;
      background: var(--ndl-accent, #ffd166);
      transform: scaleX(calc(var(--brightness-progress, 0) / 100));
      transform-origin: left center;
      transition: transform 0.15s ease;
    }
    .ndl-light-slider-track[data-mode="temp"] {
      background: linear-gradient(90deg, #f4b55f 0%, #ffd166 32%, #fff1c1 56%, #8fd3ff 100%);
    }
    .ndl-light-slider-track[data-mode="color"] {
      background: linear-gradient(90deg, #ff4d6d 0%, #ff9f1c 17%, #ffe66d 33%, #4cd964 50%, #4dabf7 67%, #845ef7 83%, #ff4d6d 100%);
    }

    /* Slider thumb - hidden for brightness, visible for temp/color */
    .ndl-light-slider-thumb {
      display: none;
      pointer-events: none;
      position: absolute;
      top: 50%;
      width: 20px;
      height: 26px;
      border-radius: 999px;
      transform: translate(-50%, -50%);
      transition: transform 180ms cubic-bezier(0.22, 0.84, 0.26, 1);
      z-index: 2;
    }
    .ndl-light-slider-shell[data-mode="temp"] .ndl-light-slider-thumb,
    .ndl-light-slider-shell[data-mode="color"] .ndl-light-slider-thumb {
      display: block;
      background: linear-gradient(180deg, rgba(255,255,255,0.84) 0%, rgba(255,255,255,0.62) 100%);
      border: 1px solid color-mix(in srgb, var(--hrv-color-text, #1a1a2e) 18%, transparent);
      box-shadow: 0 8px 18px rgba(0,0,0,0.18),
                  inset 0 1px 0 color-mix(in srgb, var(--hrv-color-text, #1a1a2e) 22%, transparent);
      -webkit-backdrop-filter: blur(12px);
      backdrop-filter: blur(12px);
    }
    .ndl-light-slider-shell[data-mode="temp"] .ndl-light-slider-thumb {
      left: clamp(10px, calc(var(--temp-progress, 0) * 1%), calc(100% - 10px));
    }
    .ndl-light-slider-shell[data-mode="color"] .ndl-light-slider-thumb {
      left: clamp(10px, calc(var(--color-progress, 0) * 1%), calc(100% - 10px));
    }

    /* Slider input - transparent overlay that captures pointer */
    .ndl-light-slider {
      -webkit-appearance: none;
      appearance: none;
      background: transparent;
      border: 0;
      width: 100%;
      height: 44px;
      margin: 0;
      cursor: pointer;
      outline: none;
      position: relative;
      z-index: 3;
    }
    .ndl-light-slider::-webkit-slider-thumb {
      -webkit-appearance: none;
      width: 28px;
      height: 28px;
      background: transparent;
      cursor: grab;
    }
    .ndl-light-slider::-webkit-slider-thumb:active { cursor: grabbing; }
    .ndl-light-slider::-moz-range-thumb {
      width: 28px;
      height: 28px;
      background: transparent;
      border: 0;
      cursor: grab;
    }

    /* Mode action buttons (below slider) */
    .ndl-light-mode-actions {
      display: flex;
      gap: 10px;
    }
    .ndl-light-mode-btn {
      align-items: center;
      appearance: none;
      background: color-mix(in srgb, var(--hrv-color-text, #1a1a2e) 5%, transparent);
      border: 1px solid color-mix(in srgb, var(--hrv-color-text, #1a1a2e) 8%, transparent);
      border-radius: 999px;
      color: var(--ndl-fg, var(--hrv-color-text, #1a1a2e));
      cursor: pointer;
      display: inline-flex;
      height: 36px;
      justify-content: center;
      line-height: 0;
      padding: 0;
      width: 36px;
      transition: transform 180ms cubic-bezier(0.22, 0.84, 0.26, 1),
                  background 200ms ease;
    }
    .ndl-light-mode-btn[hidden] { display: none; }
    .ndl-light-mode-btn:hover {
      background: color-mix(in srgb, var(--hrv-color-text, #1a1a2e) 8%, transparent);
    }
    .ndl-light-mode-btn.is-pressing {
      animation: ndl-btn-bounce var(--hrv-motion-bounce, 0.35s cubic-bezier(0.2, 0.9, 0.24, 1)) forwards;
    }
    .ndl-light-mode-btn svg { width: 18px; height: 18px; }
    .ndl-light-mode-btn [part^="light-mode-"] {
      display: inline-flex;
      align-items: center;
      justify-content: center;
    }

    /* Effect cycle pill */
    .ndl-effect-pill {
      justify-self: start;
      display: inline-flex;
      align-items: center;
      gap: 6px;
      padding: 4px 10px;
      border: 1px solid color-mix(in srgb, var(--hrv-color-text, #1a1a2e) 8%, transparent);
      border-radius: 999px;
      background: var(--hrv-glass-bg, linear-gradient(180deg, rgba(255,255,255,0.5) 0%, rgba(255,255,255,0.25) 100%));
      font-size: 10px;
      font-weight: 600;
      color: var(--ndl-fg, var(--hrv-color-text, #1a1a2e));
      cursor: pointer;
      transition: background 0.2s ease, box-shadow 0.2s ease;
      -webkit-backdrop-filter: blur(6px);
      backdrop-filter: blur(6px);
      box-shadow: 0 1px 4px rgba(0,0,0,0.06);
    }
    .ndl-effect-pill:hover {
      background: var(--hrv-glass-bg-hover, linear-gradient(180deg, rgba(255,255,255,0.65) 0%, rgba(255,255,255,0.4) 100%));
      box-shadow: 0 2px 6px rgba(0,0,0,0.08);
    }
    .ndl-effect-pill svg { opacity: 0.6; width: 14px; height: 14px; }
    .ndl-effect-pill [part=light-effect-icon] { display: inline-flex; align-items: center; }

    /* Read-only state label (non-writable lights) */
    .ndl-light-ro-label {
      font-size: 13px;
      font-weight: 600;
      color: var(--ndl-fg, var(--hrv-color-text, #1a1a2e));
      opacity: 0.6;
      text-align: center;
      padding: 4px 0;
    }

    /* Hide value slots until applyState populates them */
    .ndl-light-chip:empty,
    .ndl-effect-label:empty,
    .ndl-light-ro-label:empty { display: none; }

    /* Compact / mini layout adjustments */
    [part=card].ndl-compact .ndl-light-slider-wrap { min-height: 48px; padding: 0 12px; }
    [part=card].ndl-compact .ndl-light-mode-panel { min-height: 48px; }
    [part=card].ndl-compact .ndl-light-mode-btn { height: 32px; width: 32px; }
    [part=card].ndl-compact .ndl-light-mode-btn svg { width: 16px; height: 16px; }
    [part=card].ndl-mini .ndl-light-controls-shell { display: none; }
  `;

  const LIGHT_MODES = ["brightness", "temp", "color"];
  const _LIGHT_MODE_ICONS = { brightness: "mdi:brightness-5", temp: "mdi:thermometer", color: "mdi:palette" };

  class LightCard extends BaseCard {
    #card = null;
    #shellEl = null;
    #panelInner = null;
    #sliderShell = null;
    #slider = null;
    #track = null;
    #chipEl = null;
    #roLabel = null;
    #modeButtons = [];
    #effectPill = null;

    #brightness = 0;
    #colorTempK = 4000;
    #hue = 0;
    #isOn = false;
    #mode = 0;
    #hasAnyMode = false;
    #minCt = 2000;
    #maxCt = 6500;
    #lastAttrs = {};
    #effectList = [];
    #currentEffect = null;
    #wasOn = null;
    #sendValue;
    #layoutTeardown = null;
    #modeAnimTimer = null;

    constructor(def, root, config, i18n) {
      super(def, root, config, i18n);
      this.#sendValue = _debounce(this.#doSendValue.bind(this), 300);
    }

    render() {
      const isWritable = this.def.capabilities === "read-write";
      const features = this.def.supported_features ?? [];
      const hints = this.config.displayHints ?? {};
      const hasBrightness = hints.show_brightness !== false && features.includes("brightness");
      const hasColorTemp = hints.show_color_temp !== false && features.includes("color_temp");
      const hasColor = hints.show_rgb !== false && features.includes("rgb_color");
      const hasEffect = features.includes("effect");
      const showSlider = isWritable && (hasBrightness || hasColorTemp || hasColor);
      const modeCount = [hasBrightness, hasColorTemp, hasColor].filter(Boolean).length;
      this.#minCt = this.def.feature_config?.min_color_temp_kelvin ?? 2000;
      this.#maxCt = this.def.feature_config?.max_color_temp_kelvin ?? 6500;

      // Ensure current mode is supported.
      const modeAvail = [hasBrightness, hasColorTemp, hasColor];
      if (!modeAvail[this.#mode]) {
        this.#mode = modeAvail.findIndex(Boolean);
        if (this.#mode === -1) this.#mode = 0;
      }
      this.#hasAnyMode = modeAvail.some(Boolean);

      const activeModeName = LIGHT_MODES[this.#mode] ?? "brightness";

      // Render with controls visible. applyState collapses if the state is off.
      // This avoids the rare race where state arrives late and the card stays
      // stuck in a "looks-off" appearance while actually on.
      this.root.innerHTML = /* html */`
        <style>${LIGHT_STYLES}${COMPANION_DOT_STYLES}${NDL_ROW_CSS}</style>
        <div part="card" class="ndl-light-card">
          <div part="card-header">
            <span part="card-icon" class="ndl-light-icon" aria-hidden="true"></span>
            <span part="card-name">${_esc(this.def.friendly_name)}</span>
            <span class="ndl-chip ndl-light-chip"></span>
          </div>
          <div part="card-body">
            ${showSlider ? /* html */`
              <div class="ndl-light-controls-shell">
                <div class="ndl-light-mode-panel">
                  <div class="ndl-light-mode-panel-inner">
                    <div class="ndl-light-slider-wrap">
                      <div class="ndl-light-slider-shell" data-mode="${activeModeName}">
                        <div class="ndl-light-slider-track" data-mode="${activeModeName}"></div>
                        <input type="range" class="ndl-light-slider"
                          min="0" max="100" step="1" value="0"
                          aria-label="${_esc(this.def.friendly_name)} ${activeModeName}">
                        <div class="ndl-light-slider-thumb"></div>
                      </div>
                    </div>
                  </div>
                </div>
                ${modeCount > 1 ? /* html */`
                  <div class="ndl-light-mode-actions">
                    ${hasBrightness ? /* html */`<button class="ndl-light-mode-btn" data-mode="brightness" type="button" aria-label="Brightness"><span part="light-mode-brightness" aria-hidden="true"></span></button>` : ""}
                    ${hasColorTemp ? /* html */`<button class="ndl-light-mode-btn" data-mode="temp" type="button" aria-label="Color temperature"><span part="light-mode-temp" aria-hidden="true"></span></button>` : ""}
                    ${hasColor ? /* html */`<button class="ndl-light-mode-btn" data-mode="color" type="button" aria-label="Color"><span part="light-mode-color" aria-hidden="true"></span></button>` : ""}
                  </div>
                ` : ""}
                ${hasEffect && isWritable ? /* html */`
                  <button class="ndl-effect-pill" type="button" title="Cycle effect">
                    <span part="light-effect-icon" aria-hidden="true"></span>
                    <span class="ndl-effect-label"></span>
                  </button>
                ` : ""}
              </div>
            ` : !isWritable ? /* html */`
              <div class="ndl-light-ro-label"></div>
            ` : ""}
          </div>
          ${this.renderAriaLiveHTML()}
          ${this.renderCompanionZoneHTML()}
          <div part="stale-indicator" aria-hidden="true"></div>
        </div>
      `;

      // Cache DOM refs
      this.#card = this.root.querySelector("[part=card]");
      this.#shellEl = this.root.querySelector(".ndl-light-controls-shell");
      this.#panelInner = this.root.querySelector(".ndl-light-mode-panel-inner");
      this.#sliderShell = this.root.querySelector(".ndl-light-slider-shell");
      this.#slider = this.root.querySelector(".ndl-light-slider");
      this.#track = this.root.querySelector(".ndl-light-slider-track");
      this.#chipEl = this.root.querySelector(".ndl-light-chip");
      this.#roLabel = this.root.querySelector(".ndl-light-ro-label");
      this.#modeButtons = [...this.root.querySelectorAll(".ndl-light-mode-btn")];
      this.#effectPill = this.root.querySelector(".ndl-effect-pill");

      // Initial icons
      this.renderIcon(this.resolveIcon(this.def.icon, "mdi:lightbulb"), "card-icon");
      for (const btn of this.#modeButtons) {
        this.renderIcon(_LIGHT_MODE_ICONS[btn.dataset.mode] ?? "mdi:help-circle", `light-mode-${btn.dataset.mode}`);
      }
      if (this.root.querySelector("[part=light-effect-icon]")) {
        this.renderIcon("mdi:transition", "light-effect-icon");
      }

      // Tap on icon = toggle (with gesture override)
      const iconEl = this.root.querySelector("[part=card-icon]");
      if (iconEl && isWritable) {
        this._attachGestureHandlers(iconEl, {
          onTap: () => {
            _triggerBounce(iconEl);
            const tap = this.config.gestureConfig?.tap;
            if (tap) { this._runAction(tap); return; }
            this.config.card?.sendCommand("toggle", {});
          },
        });
      }

      // Mode buttons - click cycles to that mode with animated swap
      for (const btn of this.#modeButtons) {
        btn.addEventListener("click", () => {
          _triggerBounce(btn);
          const newModeIdx = LIGHT_MODES.indexOf(btn.dataset.mode);
          if (newModeIdx < 0 || newModeIdx === this.#mode) return;
          this.#swapMode(newModeIdx);
        });
      }

      // Effect-cycle pill
      if (this.#effectPill) {
        this.#effectPill.addEventListener("click", () => {
          _triggerBounce(this.#effectPill);
          if (!this.#effectList.length) return;
          const idx = this.#currentEffect ? this.#effectList.indexOf(this.#currentEffect) : -1;
          const next = this.#effectList[(idx + 1) % this.#effectList.length];
          this.config.card?.sendCommand("turn_on", { effect: next });
        });
      }

      // Slider input - debounced send while dragging
      if (this.#slider) {
        this.#slider.addEventListener("input", () => {
          const val = parseInt(this.#slider.value, 10);
          const mode = LIGHT_MODES[this.#mode] ?? "brightness";
          if (mode === "brightness") {
            this.#brightness = val;
          } else if (mode === "temp") {
            this.#colorTempK = Math.round(this.#minCt + (val / 100) * (this.#maxCt - this.#minCt));
          } else {
            this.#hue = Math.round(val * 3.6);
          }
          this.#updateProgressVar();
          this.#updateChipLabel();
          this.#sendValue(mode);
        });
        this.guardSlider(this.#slider, this.#sendValue);
      }

      this.renderCompanions();
      _applyCompanionTooltips(this.root);
      this._attachGestureHandlers(this.#card);

      // Compact / mini layout based on container width
      this.#layoutTeardown = _layoutObserver(this);
    }

    applyState(state, attributes) {
      const newIsOn = state === "on";
      this.#isOn = newIsOn;
      this.#lastAttrs = attributes;

      // Drive surface tint via data attribute (NODALIA_BASE picks it up)
      if (this.#card) this.#card.dataset.state = newIsOn ? "on" : "off";

      // Effect list / current effect
      this.#effectList = attributes.effect_list ?? [];
      this.#currentEffect = attributes.effect ?? null;
      if (this.#effectPill) {
        const label = this.#effectPill.querySelector(".ndl-effect-label");
        if (label) label.textContent = this.#currentEffect ?? "";
        this.#effectPill.style.display = this.#effectList.length ? "" : "none";
      }

      // Power-up / power-down animation on transition
      if (this.#wasOn !== null && this.#wasOn !== newIsOn && this.#card) {
        this.#card.classList.remove("ndl-powering-up", "ndl-powering-down");
        void this.#card.getBoundingClientRect();
        this.#card.classList.add(newIsOn ? "ndl-powering-up" : "ndl-powering-down");
      }
      this.#wasOn = newIsOn;

      // Collapse the controls shell when off
      if (this.#shellEl) this.#shellEl.dataset.collapsed = String(!newIsOn);

      // Compute accent color from light state and expose as --ndl-accent
      const accent = _lightAccent(state, attributes);
      if (this.#card) {
        if (accent) this.#card.style.setProperty("--ndl-accent", accent);
        else this.#card.style.removeProperty("--ndl-accent");
      }

      // Read attribute values for the chip + slider, BUT preserve the user's
      // tentative drag value when they are mid-drag. Otherwise an intermediate
      // server state echo (e.g. brightness=40 on the way to 100) snaps the
      // visual fill / chip backwards mid-stroke.
      const sliderActive = this.#slider && this.isSliderActive(this.#slider);
      if (!sliderActive) {
        this.#brightness = attributes.brightness != null
          ? Math.round((attributes.brightness / 255) * 100) : 0;
        this.#colorTempK = attributes.color_temp_kelvin
          ?? (attributes.color_temp ? _miredToKelvin(attributes.color_temp) : 4000);
        this.#hue = attributes.hs_color?.[0] ?? 42;
      }

      this.#updateProgressVar();
      this.#updateSliderValue();
      this.#updateChipLabel();

      // Icon based on isOn
      const iconName = newIsOn
        ? this.resolveIcon(this.def.icon, "mdi:lightbulb")
        : this.resolveIcon(this.def.icon, "mdi:lightbulb-off");
      this.renderIcon(iconName, "card-icon");

      // Read-only label (non-writable lights)
      if (this.#roLabel) {
        if (newIsOn && attributes.brightness != null) {
          this.#roLabel.textContent = `${this.#brightness}%`;
        } else {
          this.#roLabel.textContent = _capitalize(state);
        }
      }

      this.announceState(`${this.def.friendly_name}, ${state}${newIsOn ? `, ${this.#brightness}%` : ""}`);
    }

    predictState(action, _data) {
      if (action !== "toggle") return null;
      return { state: this.#isOn ? "off" : "on", attributes: this.#lastAttrs };
    }

    destroy() {
      if (this.#layoutTeardown) { this.#layoutTeardown(); this.#layoutTeardown = null; }
      if (this.#modeAnimTimer) { clearTimeout(this.#modeAnimTimer); this.#modeAnimTimer = null; }
    }

    // Animated mode swap (brightness <-> temp <-> color). Uses NODALIA_BASE
    // ndl-mode-out / ndl-mode-in keyframes (180ms scaleX out, 220ms scaleX in).
    #swapMode(newModeIdx) {
      const inner = this.#panelInner;
      if (!inner) {
        this.#mode = newModeIdx;
        this.#applyModeToDOM();
        return;
      }
      if (this.#modeAnimTimer) clearTimeout(this.#modeAnimTimer);

      inner.classList.add("ndl-mode-out");
      this.#modeAnimTimer = setTimeout(() => {
        inner.classList.remove("ndl-mode-out");
        this.#mode = newModeIdx;
        this.#applyModeToDOM();
        inner.classList.add("ndl-mode-in");
        this.#modeAnimTimer = setTimeout(() => {
          inner.classList.remove("ndl-mode-in");
          this.#modeAnimTimer = null;
        }, 250);
      }, 190);
    }

    #applyModeToDOM() {
      const mode = LIGHT_MODES[this.#mode] ?? "brightness";
      if (this.#sliderShell) this.#sliderShell.dataset.mode = mode;
      if (this.#track) this.#track.dataset.mode = mode;
      this.#updateProgressVar();
      this.#updateSliderValue();
      this.#updateChipLabel();
    }

    #updateChipLabel() {
      if (!this.#chipEl) return;
      if (!this.#isOn) { this.#chipEl.textContent = "Off"; return; }
      // On/off-only lights (no brightness/temp/colour features) just show "On"
      // - showing "0%" would be misleading.
      if (!this.#hasAnyMode) { this.#chipEl.textContent = "On"; return; }
      const mode = LIGHT_MODES[this.#mode] ?? "brightness";
      if (mode === "brightness") this.#chipEl.textContent = `${this.#brightness}%`;
      else if (mode === "temp") this.#chipEl.textContent = `${this.#colorTempK}K`;
      else this.#chipEl.textContent = `${this.#hue}°`;
    }

    // Set the per-mode CSS progress var so the brightness fill / temp+color
    // thumb follow the current value.
    #updateProgressVar() {
      if (!this.#sliderShell) return;
      const mode = LIGHT_MODES[this.#mode] ?? "brightness";
      let pct = 0;
      if (mode === "brightness") pct = this.#brightness;
      else if (mode === "temp") {
        const span = Math.max(1, this.#maxCt - this.#minCt);
        pct = Math.round(((this.#colorTempK - this.#minCt) / span) * 100);
      } else {
        pct = Math.round(this.#hue / 3.6);
      }
      this.#sliderShell.style.setProperty(`--${mode}-progress`, String(pct));
    }

    // Push the slider's value to match the current mode value (guarded so we
    // do not clobber the user mid-drag).
    #updateSliderValue() {
      if (!this.#slider || this.isSliderActive(this.#slider)) return;
      const mode = LIGHT_MODES[this.#mode] ?? "brightness";
      let val = 0;
      if (mode === "brightness") val = this.#brightness;
      else if (mode === "temp") {
        const span = Math.max(1, this.#maxCt - this.#minCt);
        val = Math.round(((this.#colorTempK - this.#minCt) / span) * 100);
      } else {
        val = Math.round(this.#hue / 3.6);
      }
      this.#slider.value = String(val);

      // Hide the active mode's button, show the alternatives.
      const activeName = LIGHT_MODES[this.#mode];
      for (const btn of this.#modeButtons) {
        btn.hidden = btn.dataset.mode === activeName;
      }
    }

    #doSendValue(mode) {
      if (mode === "brightness") {
        if (this.#brightness <= 0) this.config.card?.sendCommand("turn_off", {});
        else this.config.card?.sendCommand("turn_on", { brightness: Math.round(this.#brightness * 2.55) });
      } else if (mode === "temp") {
        this.config.card?.sendCommand("turn_on", { color_temp_kelvin: this.#colorTempK });
      } else {
        this.config.card?.sendCommand("turn_on", { hs_color: [this.#hue, 100] });
      }
    }
  }

  // ---------------------------------------------------------------------------
  // SwitchCard
  // ---------------------------------------------------------------------------

  const SWITCH_STYLES = /* css */`
    ${NODALIA_BASE}

    /* Switch icon: accent-tinted background when on, glass when off */
    [part=card][data-state="on"] [part=card-icon].ndl-switch-icon {
      background: color-mix(in srgb,
                  var(--ndl-accent, var(--hrv-color-accent, #3b9ae8)) 26%,
                  color-mix(in srgb, var(--hrv-color-text, #1a1a2e) 8%, transparent));
    }
    [part=card][data-state="on"] [part=card-icon].ndl-switch-icon svg {
      color: var(--ndl-accent, var(--hrv-color-accent, #3b9ae8));
    }

    /* State chip - accent-tinted when on */
    .ndl-switch-chip {
      font-size: 12px;
      font-weight: 700;
      height: 24px;
      padding: 0 12px;
    }
    .ndl-switch-chip[data-state="on"] {
      background: color-mix(in srgb, var(--ndl-accent, var(--hrv-color-accent, #3b9ae8)) 22%, transparent);
      border-color: color-mix(in srgb, var(--ndl-accent, var(--hrv-color-accent, #3b9ae8)) 50%, transparent);
    }

    /* Hide chip until populated */
    .ndl-switch-chip:empty { display: none; }
  `;

  class SwitchCard extends BaseCard {
    #card = null;
    #chipEl = null;
    #isOn = false;
    #wasOn = null;
    #layoutTeardown = null;

    render() {
      const isWritable = this.def.capabilities === "read-write";

      this.root.innerHTML = /* html */`
        <style>${SWITCH_STYLES}${COMPANION_DOT_STYLES}${NDL_ROW_CSS}</style>
        <div part="card" class="ndl-switch-card">
          <div part="card-header">
            <span part="card-icon" class="ndl-switch-icon" aria-hidden="true"></span>
            <span part="card-name">${_esc(this.def.friendly_name)}</span>
            <span class="ndl-chip ndl-switch-chip"></span>
          </div>
          ${this.renderAriaLiveHTML()}
          ${this.renderCompanionZoneHTML()}
          <div part="stale-indicator" aria-hidden="true"></div>
        </div>
      `;

      this.#card = this.root.querySelector("[part=card]");
      this.#chipEl = this.root.querySelector(".ndl-switch-chip");

      this.renderIcon(this.resolveIcon(this.def.icon, "mdi:toggle-switch-off-outline"), "card-icon");

      // Tap on icon: toggle (with gestureConfig.tap override)
      const iconEl = this.root.querySelector("[part=card-icon]");
      if (iconEl && isWritable) {
        this._attachGestureHandlers(iconEl, {
          onTap: () => {
            _triggerBounce(iconEl);
            const tap = this.config.gestureConfig?.tap;
            if (tap) { this._runAction(tap); return; }
            this.config.card?.sendCommand("toggle", {});
          },
        });
      }

      this.renderCompanions();
      _applyCompanionTooltips(this.root);
      this._attachGestureHandlers(this.#card);
      this.#layoutTeardown = _layoutObserver(this);
    }

    applyState(state, attributes) {
      const newIsOn = state === "on";
      this.#isOn = newIsOn;

      // data-state drives surface tint via NODALIA_BASE
      if (this.#card) this.#card.dataset.state = newIsOn ? "on" : "off";

      // Power-up/down animation on state change
      if (this.#wasOn !== null && this.#wasOn !== newIsOn && this.#card) {
        this.#card.classList.remove("ndl-powering-up", "ndl-powering-down");
        void this.#card.getBoundingClientRect();
        this.#card.classList.add(newIsOn ? "ndl-powering-up" : "ndl-powering-down");
      }
      this.#wasOn = newIsOn;

      // Accent: switch palette (drives icon background, chip tint)
      const palette = _colorsFor(this.def.domain ?? "switch");
      if (this.#card) {
        if (newIsOn) this.#card.style.setProperty("--ndl-accent", palette.accent);
        else this.#card.style.removeProperty("--ndl-accent");
      }

      // Chip: state text + data-state for accent tint when on
      if (this.#chipEl) {
        this.#chipEl.textContent = _capitalize(state);
        this.#chipEl.dataset.state = newIsOn ? "on" : "off";
      }

      // Icon swap (toggle-switch glyph reflects state directly)
      const iconName = newIsOn
        ? this.resolveIcon(this.def.icon, "mdi:toggle-switch")
        : this.resolveIcon(this.def.icon, "mdi:toggle-switch-off-outline");
      this.renderIcon(iconName, "card-icon");

      this.announceState(`${this.def.friendly_name}, ${state}`);
    }

    predictState(action, _data) {
      if (action !== "toggle") return null;
      return { state: this.#isOn ? "off" : "on", attributes: {} };
    }

    destroy() {
      if (this.#layoutTeardown) { this.#layoutTeardown(); this.#layoutTeardown = null; }
    }
  }

  // ---------------------------------------------------------------------------
  // LockCard
  // ---------------------------------------------------------------------------

  const LOCK_STYLES = /* css */`
    ${NODALIA_BASE}

    /* Lock icon: always accent-tinted circle; SVG color changes per state */
    [part=card-icon].ndl-lock-icon {
      background: color-mix(in srgb,
                  var(--ndl-accent, var(--hrv-color-accent, #3b9ae8)) 26%,
                  color-mix(in srgb, var(--hrv-color-text, #1a1a2e) 8%, transparent));
    }
    [part=card][data-lock-state="locked"] [part=card-icon].ndl-lock-icon svg {
      color: var(--ndl-accent, var(--hrv-color-accent, #3b9ae8));
    }
    [part=card][data-lock-state="jammed"] [part=card-icon].ndl-lock-icon svg {
      color: var(--hrv-color-error, #f44336);
    }

    /* State chip */
    .ndl-lock-chip {
      font-size: 12px;
      font-weight: 700;
      height: 24px;
      padding: 0 12px;
    }
    .ndl-lock-chip[data-state="locked"] {
      background: color-mix(in srgb, var(--ndl-accent, var(--hrv-color-accent, #3b9ae8)) 22%, transparent);
      border-color: color-mix(in srgb, var(--ndl-accent, var(--hrv-color-accent, #3b9ae8)) 50%, transparent);
    }
    .ndl-lock-chip[data-state="jammed"] {
      background: color-mix(in srgb, var(--hrv-color-error, #f44336) 18%, transparent);
      border-color: color-mix(in srgb, var(--hrv-color-error, #f44336) 40%, transparent);
    }
    .ndl-lock-chip:empty { display: none; }
  `;

  class LockCard extends BaseCard {
    #card = null;
    #chipEl = null;
    #isLocked = false;
    #currentState = "unknown";
    #wasLocked = null;
    #layoutTeardown = null;

    render() {
      const isWritable = this.def.capabilities === "read-write";

      this.root.innerHTML = /* html */`
        <style>${LOCK_STYLES}${COMPANION_DOT_STYLES}${NDL_ROW_CSS}</style>
        <div part="card" class="ndl-lock-card">
          <div part="card-header">
            <span part="card-icon" class="ndl-lock-icon" aria-hidden="true"></span>
            <span part="card-name">${_esc(this.def.friendly_name)}</span>
            <span class="ndl-chip ndl-lock-chip"></span>
          </div>
          ${this.renderAriaLiveHTML()}
          ${this.renderCompanionZoneHTML()}
          <div part="stale-indicator" aria-hidden="true"></div>
        </div>
      `;

      this.#card = this.root.querySelector("[part=card]");
      this.#chipEl = this.root.querySelector(".ndl-lock-chip");

      this.renderIcon(this.resolveIcon(this.def.icon, "mdi:lock"), "card-icon");

      const iconEl = this.root.querySelector("[part=card-icon]");
      if (iconEl && isWritable) {
        this._attachGestureHandlers(iconEl, {
          onTap: () => {
            _triggerBounce(iconEl);
            const tap = this.config.gestureConfig?.tap;
            if (tap) { this._runAction(tap); return; }
            this.config.card?.sendCommand(this.#isLocked ? "unlock" : "lock", {});
          },
        });
      }

      this.renderCompanions();
      _applyCompanionTooltips(this.root);
      this._attachGestureHandlers(this.#card);
      this.#layoutTeardown = _layoutObserver(this);
    }

    applyState(state, _attributes) {
      this.#currentState = state;
      this.#isLocked = state === "locked";
      const isJammed = state === "jammed";

      if (this.#card) {
        // "on"/"off" drives NODALIA_BASE gradient; data-lock-state carries the full lock state for icon CSS
        this.#card.dataset.state = this.#isLocked ? "on" : "off";
        this.#card.dataset.lockState = state;
      }

      if (this.#wasLocked !== null && this.#wasLocked !== this.#isLocked && this.#card) {
        this.#card.classList.remove("ndl-powering-up", "ndl-powering-down");
        void this.#card.getBoundingClientRect();
        this.#card.classList.add(this.#isLocked ? "ndl-powering-up" : "ndl-powering-down");
      }
      this.#wasLocked = this.#isLocked;

      const palette = _colorsFor("lock");
      if (this.#card) {
        if (this.#isLocked) this.#card.style.setProperty("--ndl-accent", palette.accent);
        else this.#card.style.removeProperty("--ndl-accent");
      }

      if (this.#chipEl) {
        this.#chipEl.textContent = _capitalize(state);
        this.#chipEl.dataset.state = state;
      }

      const defaultIcon = isJammed ? "mdi:lock-alert" : this.#isLocked ? "mdi:lock" : "mdi:lock-open";
      const rawIcon = this.def.icon_state_map?.[state] ?? this.def.icon ?? defaultIcon;
      this.renderIcon(this.resolveIcon(rawIcon, defaultIcon), "card-icon");

      this.announceState(`${this.def.friendly_name}, ${state}`);
    }

    predictState(action, _data) {
      if (action === "lock")   return { state: "locking",   attributes: {} };
      if (action === "unlock") return { state: "unlocking", attributes: {} };
      return null;
    }

    destroy() {
      if (this.#layoutTeardown) { this.#layoutTeardown(); this.#layoutTeardown = null; }
    }
  }

  // ---------------------------------------------------------------------------
  // BinarySensorCard
  // ---------------------------------------------------------------------------

  const BSENSOR_STYLES = /* css */`
    ${NODALIA_BASE}

    /* Binary sensor icon: accent-tinted when on (or alerting) */
    [part=card][data-state="on"] [part=card-icon].ndl-bsensor-icon {
      background: color-mix(in srgb,
                  var(--ndl-accent, var(--hrv-color-accent, #51cf66)) 26%,
                  color-mix(in srgb, var(--hrv-color-text, #1a1a2e) 8%, transparent));
    }
    [part=card][data-state="on"] [part=card-icon].ndl-bsensor-icon svg {
      color: var(--ndl-accent, var(--hrv-color-accent, #51cf66));
    }

    .ndl-bsensor-chip {
      font-size: 12px;
      font-weight: 700;
      height: 24px;
      padding: 0 12px;
    }
    .ndl-bsensor-chip[data-state="on"] {
      background: color-mix(in srgb, var(--ndl-accent, var(--hrv-color-accent, #51cf66)) 22%, transparent);
      border-color: color-mix(in srgb, var(--ndl-accent, var(--hrv-color-accent, #51cf66)) 50%, transparent);
    }
    .ndl-bsensor-chip:empty { display: none; }
  `;

  // Device-class-aware icon pairs (on/off states map to different glyphs).
  const _BS_ICON_MAP = {
    door:         { on: "mdi:door-open",                   off: "mdi:door-closed" },
    garage_door:  { on: "mdi:garage-open",                 off: "mdi:garage" },
    window:       { on: "mdi:window-open",                 off: "mdi:window-closed" },
    opening:      { on: "mdi:square-rounded",              off: "mdi:square-rounded-outline" },
    motion:       { on: "mdi:motion-sensor",               off: "mdi:motion-sensor-off" },
    occupancy:    { on: "mdi:home-account",                off: "mdi:home-outline" },
    presence:     { on: "mdi:home-account",                off: "mdi:home-outline" },
    moisture:     { on: "mdi:water",                       off: "mdi:water-off" },
    smoke:        { on: "mdi:smoke-detector-variant-alert", off: "mdi:smoke-detector-variant" },
    gas:          { on: "mdi:gas-cylinder",                off: "mdi:gas-cylinder" },
    safety:       { on: "mdi:shield-alert",                off: "mdi:shield-check" },
    problem:      { on: "mdi:alert-circle",                off: "mdi:check-circle" },
    tamper:       { on: "mdi:shield-alert",                off: "mdi:shield" },
    sound:        { on: "mdi:volume-high",                 off: "mdi:volume-off" },
    vibration:    { on: "mdi:vibrate",                     off: "mdi:vibrate-off" },
    connectivity: { on: "mdi:wifi",                        off: "mdi:wifi-off" },
    plug:         { on: "mdi:power-plug",                  off: "mdi:power-plug-off" },
    power:        { on: "mdi:flash",                       off: "mdi:flash-off" },
    battery:      { on: "mdi:battery-alert",               off: "mdi:battery" },
    cold:         { on: "mdi:snowflake",                   off: "mdi:snowflake-off" },
    heat:         { on: "mdi:fire",                        off: "mdi:fire-off" },
    light:        { on: "mdi:lightbulb",                   off: "mdi:lightbulb-off" },
    lock:         { on: "mdi:lock-open",                   off: "mdi:lock" },
    running:      { on: "mdi:play-circle",                 off: "mdi:stop-circle" },
    update:       { on: "mdi:package-up",                  off: "mdi:package-variant" },
  };

  // Device classes where "on" indicates an alert / problem state. Card uses
  // a red accent in those cases instead of the generic green-on look.
  const _BS_ALERT_CLASSES = new Set([
    "smoke", "gas", "safety", "problem", "tamper", "moisture", "battery",
  ]);

  // Device classes where the natural "active" colour is something other than
  // green (e.g. cold = blue, heat = orange).
  const _BS_ACCENT_OVERRIDES = {
    cold: "#71c0ff",
    heat: "#ff8a3d",
    light: "#ffd166",
    motion: "#51cf66",
    sound: "#9775fa",
  };

  class BinarySensorCard extends BaseCard {
    #card = null;
    #chipEl = null;
    #isOn = false;
    #wasOn = null;
    #layoutTeardown = null;

    render() {
      this.root.innerHTML = /* html */`
        <style>${BSENSOR_STYLES}${COMPANION_DOT_STYLES}${NDL_ROW_CSS}</style>
        <div part="card" class="ndl-bsensor-card">
          <div part="card-header">
            <span part="card-icon" class="ndl-bsensor-icon" aria-hidden="true"></span>
            <span part="card-name">${_esc(this.def.friendly_name)}</span>
            <span class="ndl-chip ndl-bsensor-chip"></span>
          </div>
          ${this.renderHistoryZoneHTML()}
          ${this.renderAriaLiveHTML()}
          ${this.renderCompanionZoneHTML()}
          <div part="stale-indicator" aria-hidden="true"></div>
        </div>
      `;
      this.#card = this.root.querySelector("[part=card]");
      this.#chipEl = this.root.querySelector(".ndl-bsensor-chip");
      this.renderIcon(this.resolveIcon(this.def.icon, "mdi:radiobox-blank"), "card-icon");
      this.renderCompanions();
      _applyCompanionTooltips(this.root);
      this._attachGestureHandlers(this.#card);
      this.#layoutTeardown = _layoutObserver(this);
    }

    applyState(state, attributes) {
      const newIsOn = state === "on";
      this.#isOn = newIsOn;

      // data-state drives surface tint via NODALIA_BASE
      if (this.#card) this.#card.dataset.state = newIsOn ? "on" : "off";

      // Power-up/down animation on transition
      if (this.#wasOn !== null && this.#wasOn !== newIsOn && this.#card) {
        this.#card.classList.remove("ndl-powering-up", "ndl-powering-down");
        void this.#card.getBoundingClientRect();
        this.#card.classList.add(newIsOn ? "ndl-powering-up" : "ndl-powering-down");
      }
      this.#wasOn = newIsOn;

      // Pick accent: alert classes go red, otherwise device-class override or
      // domain default (green).
      const dc = attributes.device_class ?? "";
      let accent = _colorsFor("binary_sensor").accent;
      if (newIsOn) {
        if (_BS_ALERT_CLASSES.has(dc)) accent = "#ff6b6b";
        else if (_BS_ACCENT_OVERRIDES[dc]) accent = _BS_ACCENT_OVERRIDES[dc];
      }
      if (this.#card) {
        if (newIsOn) this.#card.style.setProperty("--ndl-accent", accent);
        else this.#card.style.removeProperty("--ndl-accent");
      }

      // Icon: device-class-aware on/off pair
      const iconMap = _BS_ICON_MAP[dc];
      const iconName = iconMap
        ? (newIsOn ? iconMap.on : iconMap.off)
        : (newIsOn
            ? this.resolveIcon(this.def.icon, "mdi:radiobox-marked")
            : this.resolveIcon(this.def.icon, "mdi:radiobox-blank"));
      this.renderIcon(this.resolveIcon(iconName, "mdi:radiobox-blank"), "card-icon");

      if (this.#chipEl) {
        this.#chipEl.textContent = this.formatStateLabel(state);
        this.#chipEl.dataset.state = newIsOn ? "on" : "off";
      }

      this.announceState(`${this.def.friendly_name}, ${this.formatStateLabel(state)}`);
    }

    destroy() {
      if (this.#layoutTeardown) { this.#layoutTeardown(); this.#layoutTeardown = null; }
    }
  }

  // ---------------------------------------------------------------------------
  // SensorCard (concentric circle gauge)
  // ---------------------------------------------------------------------------

  const SENSOR_STYLES = /* css */`
    ${NODALIA_BASE}

    /* Sensor icon: accent-tinted by value */
    [part=card][data-state="on"] [part=card-icon].ndl-sensor-icon {
      background: color-mix(in srgb,
                  var(--ndl-accent, var(--hrv-color-accent, #4dabf7)) 22%,
                  color-mix(in srgb, var(--hrv-color-text, #1a1a2e) 8%, transparent));
    }
    [part=card][data-state="on"] [part=card-icon].ndl-sensor-icon svg {
      color: var(--ndl-accent, var(--hrv-color-accent, #4dabf7));
    }

    .ndl-sensor-chip {
      font-size: 12px;
      font-weight: 700;
      height: 24px;
      padding: 0 12px;
      font-variant-numeric: tabular-nums;
    }
    .ndl-sensor-chip:empty { display: none; }

    /* Slim value bar showing position within typical range. Hidden when the
       sensor reports a non-numeric state. */
    .ndl-sensor-bar {
      height: 8px;
      border-radius: 999px;
      background: color-mix(in srgb, var(--hrv-color-text, #1a1a2e) 10%, transparent);
      overflow: hidden;
      margin-top: 12px;
    }
    .ndl-sensor-bar-fill {
      height: 100%;
      width: 0%;
      border-radius: inherit;
      background: var(--ndl-accent, var(--hrv-color-accent, #4dabf7));
      transition: width 0.5s ease;
    }
    .ndl-sensor-bar[data-show="false"] { display: none; }
  `;

  // Pick an accent colour for a numeric sensor based on its value and unit.
  // Temperature scales cold→hot, percentages scale low→high (low = warning),
  // power/energy stays green, fallback is blue.
  function _sensorAccent(value, unit) {
    if (unit === "°C" || unit === "°F") {
      const c = unit === "°F" ? (value - 32) * 5 / 9 : value;
      if (c < 10) return "#4dabf7";  // cold blue
      if (c < 20) return "#66d9e8";  // cool cyan
      if (c < 30) return "#ffa94d";  // warm orange
      return "#ff6b6b";              // hot red
    }
    if (unit === "%" || unit === "lx") {
      if (value < 20) return "#ff6b6b";
      if (value < 50) return "#ffa94d";
      return "#51cf66";
    }
    if (unit === "W" || unit === "kWh" || unit === "Wh") {
      return "#51cf66";
    }
    return "#4dabf7";
  }

  class SensorCard extends BaseCard {
    #card = null;
    #chipEl = null;
    #barEl = null;
    #barFill = null;
    #min = 0;
    #max = 100;
    #wasOn = null;
    #layoutTeardown = null;

    render() {
      const unit = this.def.unit_of_measurement ?? "";
      // Sensible default ranges for the value bar by unit
      if (unit === "°C") { this.#min = 0; this.#max = 50; }
      else if (unit === "°F") { this.#min = 32; this.#max = 120; }
      else if (unit === "W") { this.#min = 0; this.#max = 3000; }
      else if (unit === "kWh" || unit === "Wh") { this.#min = 0; this.#max = 500; }
      else { this.#min = 0; this.#max = 100; }

      this.root.innerHTML = /* html */`
        <style>${SENSOR_STYLES}${COMPANION_DOT_STYLES}${NDL_ROW_CSS}</style>
        <div part="card" class="ndl-sensor-card">
          <div part="card-header">
            <span part="card-icon" class="ndl-sensor-icon" aria-hidden="true"></span>
            <span part="card-name">${_esc(this.def.friendly_name)}</span>
            <span class="ndl-chip ndl-sensor-chip"></span>
          </div>
          <div class="ndl-sensor-bar" data-show="false">
            <div class="ndl-sensor-bar-fill"></div>
          </div>
          ${this.renderHistoryZoneHTML()}
          ${this.renderAriaLiveHTML()}
          ${this.renderCompanionZoneHTML()}
          <div part="stale-indicator" aria-hidden="true"></div>
        </div>
      `;

      this.#card = this.root.querySelector("[part=card]");
      this.#chipEl = this.root.querySelector(".ndl-sensor-chip");
      this.#barEl = this.root.querySelector(".ndl-sensor-bar");
      this.#barFill = this.root.querySelector(".ndl-sensor-bar-fill");
      this.renderIcon(this.resolveIcon(this.def.icon, "mdi:gauge"), "card-icon");
      this.renderCompanions();
      _applyCompanionTooltips(this.root);
      this._attachGestureHandlers(this.#card);
      this.#layoutTeardown = _layoutObserver(this);
    }

    applyState(state, attributes) {
      const numVal = parseFloat(state);
      const unit = this.def.unit_of_measurement ?? "";
      const isNumeric = !isNaN(numVal) && state !== "unavailable" && state !== "unknown";
      const isAvailable = state !== "unavailable" && state !== "unknown";

      // data-state drives surface tint via NODALIA_BASE. Sensor is "on" when
      // the entity is reporting any usable value.
      if (this.#card) this.#card.dataset.state = isAvailable ? "on" : "off";

      // Power-up/down animation on availability change
      if (this.#wasOn !== null && this.#wasOn !== isAvailable && this.#card) {
        this.#card.classList.remove("ndl-powering-up", "ndl-powering-down");
        void this.#card.getBoundingClientRect();
        this.#card.classList.add(isAvailable ? "ndl-powering-up" : "ndl-powering-down");
      }
      this.#wasOn = isAvailable;

      // Accent: numeric sensors get a value-driven colour, non-numeric get
      // the generic sensor blue, unavailable clears it.
      if (this.#card) {
        if (isNumeric) {
          this.#card.style.setProperty("--ndl-accent", _sensorAccent(numVal, unit));
        } else if (isAvailable) {
          this.#card.style.setProperty("--ndl-accent", _colorsFor("sensor").accent);
        } else {
          this.#card.style.removeProperty("--ndl-accent");
        }
      }

      // Chip: numeric gets formatted value + unit; non-numeric shows the raw
      // state. suggested_display_precision is HA's hint for how many decimals.
      if (this.#chipEl) {
        if (isNumeric) {
          const precision = attributes.suggested_display_precision;
          const display = precision != null
            ? numVal.toFixed(precision)
            : String(Math.round(numVal * 10) / 10);
          this.#chipEl.textContent = unit ? `${display} ${unit}` : display;
        } else if (isAvailable) {
          this.#chipEl.textContent = this.formatStateLabel(state);
        } else {
          this.#chipEl.textContent = "";
        }
      }

      // Value bar: only meaningful for numeric sensors with a plausible range.
      if (this.#barEl && this.#barFill) {
        if (isNumeric) {
          const span = Math.max(1, this.#max - this.#min);
          const frac = _clamp((numVal - this.#min) / span, 0, 1);
          this.#barFill.style.width = `${frac * 100}%`;
          this.#barEl.dataset.show = "true";
        } else {
          this.#barEl.dataset.show = "false";
        }
      }

      this.announceState(`${this.def.friendly_name}, ${isNumeric ? numVal : state}${unit ? ` ${unit}` : ""}`);
    }

    destroy() {
      if (this.#layoutTeardown) { this.#layoutTeardown(); this.#layoutTeardown = null; }
    }
  }

  // ---------------------------------------------------------------------------
  // ClimateCard
  // ---------------------------------------------------------------------------

  // Dial geometry - ported verbatim from Daniel's nodalia-climate-card. Full
  // 270 sweep starting at 135 (top-left) going clockwise to 405 (= 45). The
  // SVG circle uses stroke-dasharray to mask the bottom 90 hidden gap.
  const DIAL_START_ANGLE = 135;
  const DIAL_END_ANGLE = 405;
  const DIAL_SWEEP = DIAL_END_ANGLE - DIAL_START_ANGLE;
  const DIAL_VIEWBOX_SIZE = 240;
  const DIAL_CIRCLE_RADIUS = 86;
  const DIAL_CIRCUMFERENCE = 2 * Math.PI * DIAL_CIRCLE_RADIUS;
  const DIAL_VISIBLE_LENGTH = DIAL_CIRCUMFERENCE * (DIAL_SWEEP / 360);
  const DIAL_HIDDEN_LENGTH = DIAL_CIRCUMFERENCE - DIAL_VISIBLE_LENGTH;
  const DIAL_MARKER_RADIUS_PCT = (DIAL_CIRCLE_RADIUS / DIAL_VIEWBOX_SIZE) * 100;

  function _dialMarkerPosition(angle) {
    const radians = (angle * Math.PI) / 180;
    return {
      left: 50 + Math.cos(radians) * DIAL_MARKER_RADIUS_PCT,
      top: 50 + Math.sin(radians) * DIAL_MARKER_RADIUS_PCT,
    };
  }

  // Pointer-to-temperature: returns null if pointer is in the inner deadzone
  // (so taps on the centre buttons do not change temperature).
  function _dialPointerToTemp(clientX, clientY, dialEl, range, step, fallback) {
    const rect = dialEl.getBoundingClientRect();
    const cx = rect.left + rect.width / 2;
    const cy = rect.top + rect.height / 2;
    const dx = clientX - cx;
    const dy = clientY - cy;
    const distance = Math.sqrt(dx * dx + dy * dy);
    const outerRadius = Math.min(rect.width, rect.height) / 2;
    if (distance < outerRadius * 0.42 && Number.isFinite(Number(fallback))) {
      return Number(fallback);
    }
    let angle = Math.atan2(dy, dx) * (180 / Math.PI);
    if (angle < 0) angle += 360;
    if (angle < DIAL_START_ANGLE) angle += 360;
    angle = _clamp(angle, DIAL_START_ANGLE, DIAL_END_ANGLE);
    const ratio = (angle - DIAL_START_ANGLE) / DIAL_SWEEP;
    const raw = range.min + (range.max - range.min) * ratio;
    const safeStep = Number.isFinite(step) && step > 0 ? step : 0.5;
    const rounded = range.min + Math.round((raw - range.min) / safeStep) * safeStep;
    return _clamp(Number(rounded.toFixed(2)), range.min, range.max);
  }

  // HVAC action -> icon for the small action glyph next to the current temp.
  const _HVAC_ACTION_ICONS = {
    heating: "mdi:fire",
    cooling: "mdi:snowflake",
    drying: "mdi:water-percent",
    fan: "mdi:fan",
    idle: "mdi:thermostat",
    off: "mdi:power",
  };

  const CLIMATE_STYLES = /* css */`
    ${NODALIA_BASE}

    [part=card-body] {
      display: flex;
      flex-direction: column;
      gap: 12px;
      align-items: stretch;
    }

    /* Header chips - state on the left, target/current temp on the right */
    .ndl-climate-chips {
      display: flex;
      align-items: center;
      gap: 6px;
      flex-wrap: nowrap;
      justify-content: flex-end;
    }
    .ndl-climate-chips .ndl-chip {
      font-size: 11px;
      font-weight: 700;
      height: 22px;
      padding: 0 8px;
    }
    .ndl-climate-chip-state[data-state="off"] {
      opacity: 0.65;
    }

    /* Climate icon - accent-tinted background when on, glass when off */
    [part=card][data-state="off"] [part=card-icon].ndl-climate-icon {
      background: var(--hrv-glass-bg, linear-gradient(180deg, rgba(255,255,255,0.6) 0%, rgba(255,255,255,0.35) 100%));
    }
    [part=card]:not([data-state="off"]) [part=card-icon].ndl-climate-icon {
      background: color-mix(in srgb,
                  var(--ndl-accent, var(--hrv-color-accent, #6366f1)) 28%,
                  var(--hrv-glass-bg, rgba(255,255,255,0.6)));
    }

    /* Controls shell - climate cards stay visible whether on or off, matching
       Daniel's design. Off-state appearance is conveyed via accent removal +
       icon colour, not collapse. */
    .ndl-climate-controls-shell {
      display: grid;
      gap: 12px;
    }

    /* Dial container */
    .ndl-climate-dial-wrap {
      align-items: center;
      display: flex;
      justify-content: center;
      padding: 4px 0;
    }
    .ndl-climate-dial {
      --ndl-dial-thumb-left: 50%;
      --ndl-dial-thumb-top: 50%;
      --ndl-dial-current-left: 50%;
      --ndl-dial-current-top: 50%;
      --ndl-dial-progress-length: 0;
      align-self: center;
      aspect-ratio: 1;
      -webkit-backdrop-filter: blur(18px);
      backdrop-filter: blur(18px);
      background:
        radial-gradient(circle at 24% 18%,
          color-mix(in srgb, var(--ndl-accent, var(--hrv-color-accent, #6366f1)) 20%, transparent),
          transparent 30%),
        linear-gradient(180deg,
          color-mix(in srgb, var(--ndl-accent, var(--hrv-color-accent, #6366f1)) 14%,
                    color-mix(in srgb, var(--hrv-color-text, #1a1a2e) 4%, transparent)) 0%,
          rgba(255, 255, 255, 0) 42%),
        color-mix(in srgb, var(--hrv-color-surface, #ffffff) 80%, transparent);
      border: 1px solid color-mix(in srgb,
                  var(--ndl-accent, var(--hrv-color-accent, #6366f1)) 10%,
                  color-mix(in srgb, var(--hrv-color-text, #1a1a2e) 8%, transparent));
      border-radius: 50%;
      box-shadow:
        inset 0 1px 0 color-mix(in srgb, var(--hrv-color-text, #1a1a2e) 5%, transparent),
        0 18px 38px rgba(0, 0, 0, 0.16);
      cursor: grab;
      flex-shrink: 0;
      max-width: 100%;
      position: relative;
      touch-action: none;
      user-select: none;
      -webkit-user-select: none;
      width: min(280px, 100%);
      transition: background 220ms cubic-bezier(0.22, 0.84, 0.26, 1),
                  border-color 220ms ease, box-shadow 220ms ease;
    }
    .ndl-climate-dial:active { cursor: grabbing; }
    [part=card][data-state="off"] .ndl-climate-dial { cursor: default; }

    .ndl-climate-dial-svg {
      display: block;
      height: 100%;
      width: 100%;
      overflow: visible;
    }
    .ndl-climate-dial-track,
    .ndl-climate-dial-hit,
    .ndl-climate-dial-progress {
      fill: none;
      stroke-dasharray: ${DIAL_VISIBLE_LENGTH} ${DIAL_HIDDEN_LENGTH};
      stroke-linecap: round;
      stroke-width: 18;
      transform: rotate(${DIAL_START_ANGLE}deg);
      transform-origin: ${DIAL_VIEWBOX_SIZE / 2}px ${DIAL_VIEWBOX_SIZE / 2}px;
    }
    .ndl-climate-dial-track {
      stroke: color-mix(in srgb, var(--hrv-color-text, #1a1a2e) 8%, transparent);
    }
    .ndl-climate-dial-hit {
      pointer-events: stroke;
      stroke: transparent;
      stroke-width: 40;
      cursor: grab;
    }
    .ndl-climate-dial-progress {
      stroke: var(--ndl-accent, var(--hrv-color-accent, #6366f1));
      stroke-dasharray: var(--ndl-dial-progress-length, 0) ${DIAL_CIRCUMFERENCE};
      opacity: 0.94;
      transition: stroke-dasharray 220ms ease-out, stroke 220ms ease;
    }

    /* Thumb (target temperature marker) */
    .ndl-climate-dial-thumb {
      position: absolute;
      width: 24px;
      height: 24px;
      left: var(--ndl-dial-thumb-left);
      top: var(--ndl-dial-thumb-top);
      transform: translate(-50%, -50%);
      border-radius: 50%;
      background: rgba(255, 255, 255, 0.96);
      box-shadow:
        0 0 0 1px color-mix(in srgb, var(--hrv-color-text, #1a1a2e) 6%, transparent),
        0 0 0 6px color-mix(in srgb, var(--hrv-color-text, #1a1a2e) 5%, transparent),
        0 0 18px color-mix(in srgb, var(--ndl-accent, var(--hrv-color-accent, #6366f1)) 14%, transparent),
        0 10px 24px rgba(0, 0, 0, 0.18);
      pointer-events: none;
      z-index: 2;
      transition: left 220ms ease-out, top 220ms ease-out;
    }
    /* Smaller marker for the current actual temperature */
    .ndl-climate-dial-current-marker {
      position: absolute;
      width: 11px;
      height: 11px;
      left: var(--ndl-dial-current-left);
      top: var(--ndl-dial-current-top);
      transform: translate(-50%, -50%);
      border-radius: 50%;
      background: rgba(255, 255, 255, 0.94);
      border: 2px solid color-mix(in srgb, var(--hrv-color-text, #1a1a2e) 10%, transparent);
      box-shadow: 0 0 0 2px color-mix(in srgb, var(--hrv-color-text, #1a1a2e) 6%, transparent);
      pointer-events: none;
      z-index: 1;
      opacity: var(--ndl-dial-current-opacity, 1);
      transition: left 220ms ease-out, top 220ms ease-out, opacity 220ms ease;
    }
    /* Disable transitions while dragging for snappy feel */
    .ndl-climate-dial.is-dragging .ndl-climate-dial-progress,
    .ndl-climate-dial.is-dragging .ndl-climate-dial-thumb,
    .ndl-climate-dial.is-dragging .ndl-climate-dial-current-marker {
      transition: none !important;
    }

    /* Centre block: target temp, current temp, action, mode buttons */
    .ndl-climate-dial-center {
      position: absolute;
      top: 50%;
      left: 50%;
      transform: translate(-50%, -50%);
      width: 70%;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      gap: 6px;
      pointer-events: none;
      user-select: none;
      z-index: 3;
    }
    .ndl-climate-dial-center > * { pointer-events: auto; }

    .ndl-climate-target {
      display: flex;
      align-items: baseline;
      gap: 2px;
      color: var(--ndl-fg, var(--hrv-color-text, #1a1a2e));
    }
    .ndl-climate-target-value {
      font-size: 50px;
      font-weight: 700;
      line-height: 1;
      font-variant-numeric: tabular-nums;
    }
    .ndl-climate-target-unit {
      display: inline-flex;
      align-items: baseline;
      gap: 1px;
      font-size: 18px;
      font-weight: 500;
      opacity: 0.7;
    }
    .ndl-climate-target-degree { line-height: 1; }
    .ndl-climate-target-scale { line-height: 1; }

    .ndl-climate-divider {
      width: 60%;
      height: 1px;
      background: color-mix(in srgb, var(--hrv-color-text, #1a1a2e) 10%, transparent);
      pointer-events: none;
    }
    .ndl-climate-meta {
      display: flex;
      align-items: center;
      gap: 6px;
      font-size: 11px;
      color: var(--ndl-fg, var(--hrv-color-text, #1a1a2e));
      opacity: 0.75;
      pointer-events: none;
    }
    .ndl-climate-meta [part=climate-action-icon] {
      display: inline-flex;
      align-items: center;
    }
    .ndl-climate-meta svg {
      width: 12px;
      height: 12px;
      opacity: 0.7;
    }

    /* Mode buttons row inside the dial centre */
    .ndl-climate-mode-row {
      display: flex;
      gap: 6px;
      flex-wrap: wrap;
      justify-content: center;
    }
    .ndl-climate-mode-btn {
      align-items: center;
      appearance: none;
      -webkit-backdrop-filter: blur(18px);
      backdrop-filter: blur(18px);
      background:
        radial-gradient(circle at top left, color-mix(in srgb, var(--hrv-color-text, #1a1a2e) 6%, transparent), transparent 60%),
        color-mix(in srgb, var(--hrv-color-text, #1a1a2e) 4%, transparent);
      border: 1px solid color-mix(in srgb, var(--hrv-color-text, #1a1a2e) 8%, transparent);
      border-radius: 999px;
      color: var(--ndl-fg, var(--hrv-color-text, #1a1a2e));
      cursor: pointer;
      display: inline-flex;
      height: 38px;
      width: 38px;
      justify-content: center;
      line-height: 0;
      padding: 0;
      transition: transform 180ms cubic-bezier(0.22, 0.84, 0.26, 1),
                  background 200ms ease, border-color 200ms ease;
    }
    .ndl-climate-mode-btn[hidden] { display: none; }
    .ndl-climate-mode-btn:hover {
      transform: translateY(-1px);
    }
    .ndl-climate-mode-btn.is-pressing {
      animation: ndl-btn-bounce var(--hrv-motion-bounce, 0.35s cubic-bezier(0.2, 0.9, 0.24, 1)) forwards;
    }
    .ndl-climate-mode-btn svg { width: 18px; height: 18px; }
    .ndl-climate-mode-btn [part^="climate-mode-"] {
      display: inline-flex;
      align-items: center;
      justify-content: center;
    }

    /* Step buttons (+/-) below the dial */
    .ndl-climate-steps {
      display: flex;
      gap: 12px;
      justify-content: center;
    }
    .ndl-climate-step-btn {
      align-items: center;
      appearance: none;
      -webkit-backdrop-filter: blur(18px);
      backdrop-filter: blur(18px);
      background:
        radial-gradient(circle at top left, color-mix(in srgb, var(--hrv-color-text, #1a1a2e) 5%, transparent), transparent 60%),
        color-mix(in srgb, var(--hrv-color-text, #1a1a2e) 4%, transparent);
      border: 1px solid color-mix(in srgb, var(--hrv-color-text, #1a1a2e) 6%, transparent);
      border-radius: 999px;
      color: var(--ndl-fg, var(--hrv-color-text, #1a1a2e));
      cursor: pointer;
      display: inline-flex;
      font-weight: 600;
      height: 50px;
      width: 50px;
      justify-content: center;
      padding: 0;
      box-shadow:
        inset 0 1px 0 color-mix(in srgb, var(--hrv-color-text, #1a1a2e) 6%, transparent),
        0 10px 24px rgba(0, 0, 0, 0.16);
      transition: transform 180ms cubic-bezier(0.22, 0.84, 0.26, 1),
                  background 200ms ease;
    }
    .ndl-climate-step-btn:hover { transform: translateY(-1px); }
    .ndl-climate-step-btn.is-pressing {
      animation: ndl-btn-bounce var(--hrv-motion-bounce, 0.35s cubic-bezier(0.2, 0.9, 0.24, 1)) forwards;
    }
    .ndl-climate-step-btn svg {
      width: 36px;
      height: 36px;
    }
    .ndl-climate-step-btn [part^="climate-step-"] {
      display: inline-flex;
      align-items: center;
      justify-content: center;
    }

    /* Fan / swing / preset attribute row: each is a single pill that opens
       a dropdown with the available options. */
    .ndl-climate-attr-row {
      display: flex;
      flex-wrap: wrap;
      gap: 6px;
      justify-content: center;
    }
    .ndl-climate-attr {
      position: relative;
      display: inline-flex;
    }
    .ndl-climate-attr-pill {
      appearance: none;
      display: inline-flex;
      align-items: center;
      gap: 6px;
      padding: 5px 12px;
      border-radius: 999px;
      border: 1px solid color-mix(in srgb, var(--hrv-color-text, #1a1a2e) 10%, transparent);
      background: color-mix(in srgb, var(--hrv-color-text, #1a1a2e) 4%, transparent);
      font-family: inherit;
      font-size: 11px;
      font-weight: 600;
      color: var(--ndl-fg, var(--hrv-color-text, #1a1a2e));
      cursor: pointer;
      transition: background 200ms ease, border-color 200ms ease;
    }
    .ndl-climate-attr-pill:hover {
      background: color-mix(in srgb, var(--hrv-color-text, #1a1a2e) 8%, transparent);
    }
    [part=card]:not([data-state="off"]) .ndl-climate-attr-pill {
      background: color-mix(in srgb, var(--ndl-accent, var(--hrv-color-accent, #6366f1)) 14%, transparent);
      border-color: color-mix(in srgb, var(--ndl-accent, var(--hrv-color-accent, #6366f1)) 30%, transparent);
    }
    .ndl-climate-attr-label {
      font-weight: 700;
      opacity: 0.7;
    }
    .ndl-climate-attr-value {
      max-width: 96px;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }
    .ndl-climate-attr-arrow {
      font-size: 9px;
      opacity: 0.6;
      transition: transform 200ms ease;
    }
    .ndl-climate-attr-pill[aria-expanded="true"] .ndl-climate-attr-arrow {
      transform: rotate(180deg);
    }

    /* Dropdown menu (popover, top-layer escapes the card stacking context) */
    .ndl-climate-attr-menu {
      position: fixed;
      margin: 0;
      inset: unset;
      background: var(--hrv-card-background, #ffffff);
      border: 1px solid color-mix(in srgb, var(--hrv-color-text, #1a1a2e) 10%, transparent);
      border-radius: 14px;
      box-shadow: 0 8px 24px rgba(0,0,0,0.25);
      max-height: 240px;
      overflow-y: auto;
      scrollbar-width: thin;
      padding: 4px;
      color: var(--ndl-fg, var(--hrv-color-text, #1a1a2e));
      font-family: inherit;
    }
    .ndl-climate-attr-menu:not(:popover-open) { display: none; }
    .ndl-climate-attr-option {
      display: block;
      width: 100%;
      padding: 8px 12px;
      border: none;
      background: transparent;
      color: var(--ndl-fg, var(--hrv-color-text, #1a1a2e));
      font-family: inherit;
      font-size: 12px;
      text-align: left;
      cursor: pointer;
      border-radius: 10px;
      transition: background 150ms ease;
    }
    .ndl-climate-attr-option:hover,
    .ndl-climate-attr-option:focus-visible {
      background: color-mix(in srgb, var(--hrv-color-text, #1a1a2e) 8%, transparent);
      outline: none;
    }
    .ndl-climate-attr-option[data-selected="true"] {
      background: color-mix(in srgb, var(--ndl-accent, var(--hrv-color-accent, #6366f1)) 22%, transparent);
      font-weight: 600;
    }

    /* Read-only label */
    .ndl-climate-ro-label {
      font-size: 13px;
      font-weight: 600;
      color: var(--ndl-fg, var(--hrv-color-text, #1a1a2e));
      opacity: 0.6;
      text-align: center;
      padding: 8px 0;
    }

    /* Hide chips until populated */
    .ndl-climate-chip-state:empty,
    .ndl-climate-chip-temp:empty,
    .ndl-climate-ro-label:empty { display: none; }

    /* Compact / mini layout */
    [part=card].ndl-compact .ndl-climate-dial { width: min(180px, 100%); }
    [part=card].ndl-compact .ndl-climate-target-value { font-size: 30px; }
    [part=card].ndl-compact .ndl-climate-mode-btn { height: 24px; width: 24px; }
    [part=card].ndl-compact .ndl-climate-mode-btn svg { width: 12px; height: 12px; }
    [part=card].ndl-mini .ndl-climate-dial { width: min(140px, 100%); }
    [part=card].ndl-mini .ndl-climate-target-value { font-size: 24px; }
    [part=card].ndl-mini .ndl-climate-divider,
    [part=card].ndl-mini .ndl-climate-meta { display: none; }
    [part=card].ndl-mini .ndl-climate-attr-row,
    [part=card].ndl-mini .ndl-climate-steps { display: none; }
  `;

  class ClimateCard extends BaseCard {
    #card = null;
    #shellEl = null;
    #dialEl = null;
    #targetEl = null;
    #scaleEl = null;
    #currentMetaEl = null;
    #stateChipEl = null;
    #tempChipEl = null;
    #roLabel = null;
    #modeButtons = [];
    /** Map of attr name (fan_mode|swing_mode|preset_mode) -> pill metadata. */
    #attrControls = new Map();
    #attrDocClick = null;

    #targetTemp = 20;
    #currentTemp = null;
    #hvacMode = "off";
    #hvacAction = null;
    #minTemp = 7;
    #maxTemp = 35;
    #tempStep = 0.5;
    #unit = "C";
    #dragging = false;
    #lastAttrs = {};
    #wasOn = null;
    #sendTemp;
    #layoutTeardown = null;
    #activePointerId = null;

    constructor(def, root, config, i18n) {
      super(def, root, config, i18n);
      this.#sendTemp = _debounce(this.#doSendTemp.bind(this), 300);
    }

    render() {
      const isWritable = this.def.capabilities === "read-write";
      const features = this.def.supported_features ?? [];
      const hints = this.config.displayHints ?? {};
      const hasTargetTemp = features.includes("target_temperature");
      const showDial = isWritable && hasTargetTemp;
      const allHvacModes = this.def.feature_config?.hvac_modes ?? ["off", "heat", "cool", "auto"];
      const hvacModes = hints.show_hvac_modes !== false ? allHvacModes : [];
      const fanModes = hints.show_fan_mode !== false ? (this.def.feature_config?.fan_modes ?? []) : [];
      const presetModes = hints.show_presets !== false ? (this.def.feature_config?.preset_modes ?? []) : [];
      const swingModes = hints.show_swing_mode !== false ? (this.def.feature_config?.swing_modes ?? []) : [];
      this.#minTemp = this.def.feature_config?.min_temp ?? 7;
      this.#maxTemp = this.def.feature_config?.max_temp ?? 35;
      this.#tempStep = this.def.feature_config?.target_temp_step ?? 0.5;

      const cx = DIAL_VIEWBOX_SIZE / 2;

      this.root.innerHTML = /* html */`
        <style>${CLIMATE_STYLES}${COMPANION_DOT_STYLES}${NDL_ROW_CSS}</style>
        <div part="card" class="ndl-climate-card">
          <div part="card-header">
            <span part="card-icon" class="ndl-climate-icon" aria-hidden="true"></span>
            <span part="card-name">${_esc(this.def.friendly_name)}</span>
            <div class="ndl-climate-chips">
              <span class="ndl-chip ndl-climate-chip-state"></span>
              <span class="ndl-chip ndl-climate-chip-temp"></span>
            </div>
          </div>
          <div part="card-body">
            ${showDial ? /* html */`
              <div class="ndl-climate-controls-shell">
                <div class="ndl-climate-dial-wrap">
                  <div part="climate-dial" class="ndl-climate-dial" role="slider" tabindex="0"
                    aria-valuemin="${this.#minTemp}"
                    aria-valuemax="${this.#maxTemp}"
                    aria-valuenow="${this.#targetTemp}"
                    aria-label="${_esc(this.def.friendly_name)} temperature">
                    <svg class="ndl-climate-dial-svg" viewBox="0 0 ${DIAL_VIEWBOX_SIZE} ${DIAL_VIEWBOX_SIZE}" aria-hidden="true">
                      <circle class="ndl-climate-dial-track" cx="${cx}" cy="${cx}" r="${DIAL_CIRCLE_RADIUS}"/>
                      <circle class="ndl-climate-dial-hit" cx="${cx}" cy="${cx}" r="${DIAL_CIRCLE_RADIUS}"/>
                      <circle class="ndl-climate-dial-progress" cx="${cx}" cy="${cx}" r="${DIAL_CIRCLE_RADIUS}"/>
                    </svg>
                    <span class="ndl-climate-dial-current-marker" aria-hidden="true"></span>
                    <span class="ndl-climate-dial-thumb" aria-hidden="true"></span>
                    <div class="ndl-climate-dial-center">
                      <div class="ndl-climate-target">
                        <span class="ndl-climate-target-value">--</span>
                        <span class="ndl-climate-target-unit">
                          <span class="ndl-climate-target-degree">°</span><span class="ndl-climate-target-scale">C</span>
                        </span>
                      </div>
                      <div class="ndl-climate-divider"></div>
                      <div class="ndl-climate-meta">
                        <span class="ndl-climate-current-text"></span>
                        <span part="climate-action-icon" aria-hidden="true"></span>
                      </div>
                      ${hvacModes.length > 1 ? /* html */`
                        <div class="ndl-climate-mode-row">
                          ${hvacModes.map((m) => /* html */`<button class="ndl-climate-mode-btn" data-mode="${_esc(m)}" type="button" title="${_capitalize(m)}" aria-label="${_capitalize(m)}"><span part="climate-mode-${_esc(m)}" aria-hidden="true"></span></button>`).join("")}
                        </div>
                      ` : ""}
                    </div>
                  </div>
                </div>
                <div class="ndl-climate-steps">
                  <button class="ndl-climate-step-btn ndl-climate-step-down" type="button"
                    aria-label="Decrease temperature" title="Decrease">
                    <span part="climate-step-down" aria-hidden="true"></span>
                  </button>
                  <button class="ndl-climate-step-btn ndl-climate-step-up" type="button"
                    aria-label="Increase temperature" title="Increase">
                    <span part="climate-step-up" aria-hidden="true"></span>
                  </button>
                </div>
                ${(fanModes.length || presetModes.length || swingModes.length) ? /* html */`
                  <div class="ndl-climate-attr-row">
                    ${fanModes.length    ? /* html */`<div class="ndl-climate-attr" data-attr="fan_mode"   data-options='${_esc(JSON.stringify(fanModes))}'><button class="ndl-climate-attr-pill" type="button" aria-haspopup="listbox" aria-expanded="false"><span class="ndl-climate-attr-label">Fan</span><span class="ndl-climate-attr-value">--</span><span class="ndl-climate-attr-arrow" aria-hidden="true">&#9660;</span></button><div class="ndl-climate-attr-menu" role="listbox" popover="manual"></div></div>` : ""}
                    ${swingModes.length  ? /* html */`<div class="ndl-climate-attr" data-attr="swing_mode" data-options='${_esc(JSON.stringify(swingModes))}'><button class="ndl-climate-attr-pill" type="button" aria-haspopup="listbox" aria-expanded="false"><span class="ndl-climate-attr-label">Swing</span><span class="ndl-climate-attr-value">--</span><span class="ndl-climate-attr-arrow" aria-hidden="true">&#9660;</span></button><div class="ndl-climate-attr-menu" role="listbox" popover="manual"></div></div>` : ""}
                    ${presetModes.length ? /* html */`<div class="ndl-climate-attr" data-attr="preset_mode" data-options='${_esc(JSON.stringify(presetModes))}'><button class="ndl-climate-attr-pill" type="button" aria-haspopup="listbox" aria-expanded="false"><span class="ndl-climate-attr-label">Preset</span><span class="ndl-climate-attr-value">--</span><span class="ndl-climate-attr-arrow" aria-hidden="true">&#9660;</span></button><div class="ndl-climate-attr-menu" role="listbox" popover="manual"></div></div>` : ""}
                  </div>
                ` : ""}
              </div>
            ` : /* html */`
              <div class="ndl-climate-ro-label"></div>
            `}
          </div>
          ${this.renderAriaLiveHTML()}
          ${this.renderCompanionZoneHTML()}
          <div part="stale-indicator" aria-hidden="true"></div>
        </div>
      `;

      // Cache DOM refs
      this.#card = this.root.querySelector("[part=card]");
      this.#shellEl = this.root.querySelector(".ndl-climate-controls-shell");
      this.#dialEl = this.root.querySelector(".ndl-climate-dial");
      this.#targetEl = this.root.querySelector(".ndl-climate-target-value");
      this.#scaleEl = this.root.querySelector(".ndl-climate-target-scale");
      this.#currentMetaEl = this.root.querySelector(".ndl-climate-current-text");
      this.#stateChipEl = this.root.querySelector(".ndl-climate-chip-state");
      this.#tempChipEl = this.root.querySelector(".ndl-climate-chip-temp");
      this.#roLabel = this.root.querySelector(".ndl-climate-ro-label");
      this.#modeButtons = [...this.root.querySelectorAll(".ndl-climate-mode-btn")];

      // Build attr-pill metadata for fan / swing / preset.
      this.#attrControls = new Map();
      const ATTR_TO_ACTION = {
        fan_mode:    "set_fan_mode",
        swing_mode:  "set_swing_mode",
        preset_mode: "set_preset_mode",
      };
      for (const wrap of this.root.querySelectorAll(".ndl-climate-attr")) {
        const attr = wrap.dataset.attr;
        let options = [];
        try { options = JSON.parse(wrap.dataset.options); } catch { /* ignore */ }
        const pill  = wrap.querySelector(".ndl-climate-attr-pill");
        const valueEl = wrap.querySelector(".ndl-climate-attr-value");
        const menu  = wrap.querySelector(".ndl-climate-attr-menu");
        const meta = { wrap, pill, valueEl, menu, options, attr, action: ATTR_TO_ACTION[attr], optionEls: [] };
        this.#attrControls.set(attr, meta);

        // Build option buttons inside the dropdown.
        for (const opt of options) {
          const btn = document.createElement("button");
          btn.type = "button";
          btn.className = "ndl-climate-attr-option";
          btn.role = "option";
          btn.dataset.option = opt;
          btn.textContent = _capitalize(opt);
          btn.addEventListener("click", () => {
            this.config.card?.sendCommand(meta.action, { [attr]: opt });
            this.#closeAttrMenu(meta);
            meta.pill?.focus();
          });
          menu.appendChild(btn);
          meta.optionEls.push(btn);
        }

        pill?.addEventListener("click", (e) => {
          e.stopPropagation();
          if (menu.matches(":popover-open")) this.#closeAttrMenu(meta);
          else this.#openAttrMenu(meta);
        });
      }
      // Single document-click handler closes any open attr menu.
      if (this.#attrControls.size && !this.#attrDocClick) {
        this.#attrDocClick = (e) => {
          for (const meta of this.#attrControls.values()) {
            if (meta.menu?.matches(":popover-open") && !this.root.host.contains(e.target)) {
              this.#closeAttrMenu(meta);
            }
          }
        };
        document.addEventListener("click", this.#attrDocClick);
      }

      // Icons
      this.renderIcon(this.resolveIcon(this.def.icon, "mdi:thermostat"), "card-icon");
      this.renderIcon("mdi:minus", "climate-step-down");
      this.renderIcon("mdi:plus", "climate-step-up");
      this.renderIcon("mdi:thermostat", "climate-action-icon");
      for (const btn of this.#modeButtons) {
        const iconName = _HVAC_ICONS[btn.dataset.mode] ?? "mdi:thermostat";
        this.renderIcon(iconName, `climate-mode-${btn.dataset.mode}`);
      }

      // Tap on card icon = toggle on/off. When turning on, pick the first
      // mode the entity actually supports (heat_cool > heat > cool > auto > ...)
      // matching Daniel's getPreferredOnMode logic.
      const iconEl = this.root.querySelector("[part=card-icon]");
      if (iconEl && isWritable) {
        this._attachGestureHandlers(iconEl, {
          onTap: () => {
            _triggerBounce(iconEl);
            const tap = this.config.gestureConfig?.tap;
            if (tap) { this._runAction(tap); return; }
            const next = this.#hvacMode === "off"
              ? this.#getPreferredOnMode()
              : "off";
            if (next) {
              this.config.card?.sendCommand("set_hvac_mode", { hvac_mode: next });
            }
          },
        });
      }

      // Step buttons
      const downBtn = this.root.querySelector(".ndl-climate-step-down");
      const upBtn = this.root.querySelector(".ndl-climate-step-up");
      if (downBtn) {
        downBtn.addEventListener("click", () => {
          _triggerBounce(downBtn);
          this.#targetTemp = Math.max(this.#minTemp, this.#targetTemp - this.#tempStep);
          this.#updateDialFromTarget();
          this.#sendTemp();
        });
      }
      if (upBtn) {
        upBtn.addEventListener("click", () => {
          _triggerBounce(upBtn);
          this.#targetTemp = Math.min(this.#maxTemp, this.#targetTemp + this.#tempStep);
          this.#updateDialFromTarget();
          this.#sendTemp();
        });
      }

      // HVAC mode buttons
      for (const btn of this.#modeButtons) {
        btn.addEventListener("click", () => {
          _triggerBounce(btn);
          this.config.card?.sendCommand("set_hvac_mode", { hvac_mode: btn.dataset.mode });
        });
      }


      // Dial drag - pointer events on the dial element. Inner dead-zone keeps
      // taps on the centre buttons from changing the temperature.
      if (this.#dialEl && isWritable) this.#initDialDrag();

      this.renderCompanions();
      _applyCompanionTooltips(this.root);
      this._attachGestureHandlers(this.#card);
      this.#layoutTeardown = _layoutObserver(this);
    }

    applyState(state, attributes) {
      this.#hvacMode = state;
      this.#hvacAction = attributes.hvac_action ?? null;
      this.#lastAttrs = attributes;
      this.#currentTemp = attributes.current_temperature ?? null;
      this.#unit = attributes.temperature_unit === "°F" ? "F" : "C";

      const isOff = state === "off";
      const newOn = !isOff;

      if (this.#card) this.#card.dataset.state = isOff ? "off" : "on";

      // Power-up/down animation on transition
      if (this.#wasOn !== null && this.#wasOn !== newOn && this.#card) {
        this.#card.classList.remove("ndl-powering-up", "ndl-powering-down");
        void this.#card.getBoundingClientRect();
        this.#card.classList.add(newOn ? "ndl-powering-up" : "ndl-powering-down");
      }
      this.#wasOn = newOn;

      // HVAC palette drives accent. Off uses a muted grey so the card reads
      // as "asleep" until a mode is selected (matches Daniel's design).
      const palette = _HVAC_PALETTE[state] ?? _HVAC_PALETTE.off;
      if (this.#card) this.#card.style.setProperty("--ndl-accent", palette.accent);

      // Sync target temperature only when not mid-drag
      if (!this.#dragging) {
        this.#targetTemp = attributes.temperature ?? this.#targetTemp ?? this.#minTemp;
        this.#updateDialFromTarget();
      }

      // Update temperature scale (C / F) inside the dial centre
      if (this.#scaleEl) {
        this.#scaleEl.textContent = this.#unit;
      }

      // Header chips - state on the left, target/current temp on the right
      if (this.#stateChipEl) {
        this.#stateChipEl.textContent = _capitalize(state);
        this.#stateChipEl.dataset.state = isOff ? "off" : "on";
      }
      if (this.#tempChipEl) {
        const t = Math.round(this.#targetTemp * 10) / 10;
        this.#tempChipEl.textContent = this.#currentTemp != null
          ? `${t}° / ${this.#currentTemp}°`
          : `${t}°`;
      }

      // Current temperature inside dial centre
      if (this.#currentMetaEl) {
        this.#currentMetaEl.textContent = this.#currentTemp != null
          ? `${this.#currentTemp}°` : "";
      }

      // HVAC action icon (heating / cooling / drying / fan / idle / off)
      const actionKey = this.#hvacAction ?? (isOff ? "off" : "idle");
      const actionIcon = _HVAC_ACTION_ICONS[actionKey] ?? "mdi:thermostat";
      this.renderIcon(actionIcon, "climate-action-icon");

      // Mode buttons: hide the currently-active mode so the row shows only
      // the other modes the user can switch to (Daniel's pattern). The active
      // mode is conveyed via the dial accent + chip.
      for (const btn of this.#modeButtons) {
        btn.hidden = btn.dataset.mode === state;
      }

      // Fan / swing / preset attr pills: each shows the currently selected
      // option as text inside the pill. Tapping the pill opens a dropdown
      // with the rest of the options.
      for (const meta of this.#attrControls.values()) {
        const current = attributes[meta.attr] ?? "";
        if (meta.valueEl) meta.valueEl.textContent = current ? _capitalize(current) : "--";
        for (const btn of meta.optionEls) {
          const isActive = btn.dataset.option === current;
          btn.setAttribute("data-selected", String(isActive));
          btn.setAttribute("aria-selected", String(isActive));
        }
      }

      // Read-only label
      if (this.#roLabel) {
        this.#roLabel.textContent = this.#currentTemp != null
          ? `${_capitalize(state)}, ${this.#currentTemp}°`
          : _capitalize(state);
      }

      this.announceState(
        `${this.def.friendly_name}, ${_capitalize(state)}, target ${Math.round(this.#targetTemp)}°`
        + (this.#currentTemp != null ? `, currently ${this.#currentTemp}°` : ""),
      );
    }

    predictState(action, data) {
      if (action === "set_hvac_mode" && data.hvac_mode) {
        return { state: data.hvac_mode, attributes: this.#lastAttrs };
      }
      if (action === "set_fan_mode" && data.fan_mode) {
        return { state: this.#hvacMode, attributes: { ...this.#lastAttrs, fan_mode: data.fan_mode } };
      }
      if (action === "set_preset_mode" && data.preset_mode) {
        return { state: this.#hvacMode, attributes: { ...this.#lastAttrs, preset_mode: data.preset_mode } };
      }
      if (action === "set_swing_mode" && data.swing_mode) {
        return { state: this.#hvacMode, attributes: { ...this.#lastAttrs, swing_mode: data.swing_mode } };
      }
      if (action === "set_temperature" && data.temperature != null) {
        return { state: this.#hvacMode, attributes: { ...this.#lastAttrs, temperature: data.temperature } };
      }
      return null;
    }

    destroy() {
      if (this.#layoutTeardown) { this.#layoutTeardown(); this.#layoutTeardown = null; }
      if (this.#attrDocClick) { document.removeEventListener("click", this.#attrDocClick); this.#attrDocClick = null; }
      for (const meta of this.#attrControls.values()) {
        try { meta.menu?.hidePopover?.(); } catch { /* ignore */ }
      }
    }

    #openAttrMenu(meta) {
      if (!meta?.menu || !meta.options.length) return;
      // Close any other open attr menu first.
      for (const other of this.#attrControls.values()) {
        if (other !== meta && other.menu?.matches(":popover-open")) this.#closeAttrMenu(other);
      }
      try { meta.menu.showPopover(); } catch { /* ignore */ }
      meta.pill?.setAttribute("aria-expanded", "true");

      const r = meta.pill.getBoundingClientRect();
      const spaceBelow = window.innerHeight - r.bottom;
      const spaceAbove = r.top;
      const dropH = Math.min(meta.menu.scrollHeight || 240, 240);
      meta.menu.style.left = `${Math.round(r.left)}px`;
      const minW = Math.max(140, Math.round(r.width));
      meta.menu.style.minWidth = `${minW}px`;
      if (spaceBelow < dropH + 8 && spaceAbove > spaceBelow) {
        meta.menu.style.top = `${Math.max(8, Math.round(r.top - dropH - 6))}px`;
      } else {
        meta.menu.style.top = `${Math.round(r.bottom + 6)}px`;
      }
    }

    #closeAttrMenu(meta) {
      if (!meta?.menu) return;
      try { meta.menu.hidePopover(); } catch { /* ignore */ }
      meta.pill?.setAttribute("aria-expanded", "false");
    }

    // Pick the first on-mode the entity actually supports, mirroring Daniel's
    // preference order: heat_cool > heat > cool > auto > dry > fan_only > any
    // non-off mode > "heat" fallback.
    #getPreferredOnMode() {
      const modes = (this.def.feature_config?.hvac_modes ?? []).map((m) => String(m).trim());
      const set = new Set(modes);
      for (const candidate of ["heat_cool", "heat", "cool", "auto", "dry", "fan_only"]) {
        if (set.has(candidate)) return candidate;
      }
      const first = modes.find((m) => m && m !== "off");
      return first || "heat";
    }

    // Recompute thumb position, progress arc length, target value text from
    // the current target temperature.
    #updateDialFromTarget() {
      const range = Math.max(this.#tempStep, this.#maxTemp - this.#minTemp);
      const ratio = _clamp((this.#targetTemp - this.#minTemp) / range, 0, 1);
      const angle = DIAL_START_ANGLE + ratio * DIAL_SWEEP;
      const progress = (DIAL_VISIBLE_LENGTH * ratio).toFixed(3);
      const thumbPos = _dialMarkerPosition(angle);

      // Current-temperature marker
      let cMarker = null;
      if (this.#currentTemp != null) {
        const cRatio = _clamp((this.#currentTemp - this.#minTemp) / range, 0, 1);
        const cAngle = DIAL_START_ANGLE + cRatio * DIAL_SWEEP;
        cMarker = _dialMarkerPosition(cAngle);
      }

      if (this.#dialEl) {
        this.#dialEl.style.setProperty("--ndl-dial-thumb-left", `${thumbPos.left}%`);
        this.#dialEl.style.setProperty("--ndl-dial-thumb-top", `${thumbPos.top}%`);
        this.#dialEl.style.setProperty("--ndl-dial-progress-length", String(progress));
        if (cMarker) {
          this.#dialEl.style.setProperty("--ndl-dial-current-left", `${cMarker.left}%`);
          this.#dialEl.style.setProperty("--ndl-dial-current-top", `${cMarker.top}%`);
          this.#dialEl.style.setProperty("--ndl-dial-current-opacity", "1");
        } else {
          this.#dialEl.style.setProperty("--ndl-dial-current-opacity", "0");
        }
        const accessibleTemp = Math.round(this.#targetTemp * 10) / 10;
        this.#dialEl.setAttribute("aria-valuenow", String(accessibleTemp));
        this.#dialEl.setAttribute("aria-valuetext", `${accessibleTemp} degrees ${this.#unit}`);
      }
      if (this.#targetEl) {
        this.#targetEl.textContent = `${Math.round(this.#targetTemp * 10) / 10}`;
      }
    }

    #initDialDrag() {
      const dial = this.#dialEl;
      const onStart = (e) => {
        if (e.button !== undefined && e.button !== 0) return;
        // Skip if pointer is on the centre block (dead zone) - lets centre buttons receive the tap.
        const target = e.composedPath ? e.composedPath()[0] : e.target;
        if (target?.closest?.(".ndl-climate-dial-center")) return;
        // Verify the pointer is within the outer ring, not the inner dead zone
        const initial = _dialPointerToTemp(e.clientX, e.clientY, dial,
          { min: this.#minTemp, max: this.#maxTemp }, this.#tempStep, null);
        if (initial == null) return;
        this.#dragging = true;
        this.#activePointerId = e.pointerId;
        dial.classList.add("is-dragging");
        try { dial.setPointerCapture(e.pointerId); } catch (_) { /* ignore */ }
        this.#onDialDragMove(e);
      };
      const onMove = (e) => {
        if (!this.#dragging || e.pointerId !== this.#activePointerId) return;
        this.#onDialDragMove(e);
      };
      const onEnd = (e) => {
        if (!this.#dragging) return;
        if (e && e.pointerId !== undefined && e.pointerId !== this.#activePointerId) return;
        this.#dragging = false;
        this.#activePointerId = null;
        dial.classList.remove("is-dragging");
        this.#sendTemp();
      };
      dial.addEventListener("pointerdown", onStart);
      dial.addEventListener("pointermove", onMove);
      dial.addEventListener("pointerup", onEnd);
      dial.addEventListener("pointercancel", onEnd);
      dial.addEventListener("keydown", (e) => {
        let next = this.#targetTemp;
        if (e.key === "ArrowDown" || e.key === "ArrowLeft") next -= this.#tempStep;
        else if (e.key === "ArrowUp" || e.key === "ArrowRight") next += this.#tempStep;
        else if (e.key === "PageDown") next -= this.#tempStep * 10;
        else if (e.key === "PageUp") next += this.#tempStep * 10;
        else if (e.key === "Home") next = this.#minTemp;
        else if (e.key === "End") next = this.#maxTemp;
        else return;
        e.preventDefault();
        this.#targetTemp = _clamp(next, this.#minTemp, this.#maxTemp);
        this.#updateDialFromTarget();
        this.#sendTemp();
      });
    }

    #onDialDragMove(e) {
      const t = _dialPointerToTemp(e.clientX, e.clientY, this.#dialEl,
        { min: this.#minTemp, max: this.#maxTemp }, this.#tempStep, this.#targetTemp);
      if (t == null) return;
      this.#targetTemp = t;
      this.#updateDialFromTarget();
      this.#sendTemp();
    }

    #doSendTemp() {
      this.config.card?.sendCommand("set_temperature", { temperature: this.#targetTemp });
    }
  }

  // ---------------------------------------------------------------------------
  // FanCard - horizontal slider bar
  // ---------------------------------------------------------------------------

  // Compute the discrete percentage steps for a fan, based on feature_config.
  // Prefers `speed_count`; falls back to `percentage_step`; defaults to 3.
  //
  // CRITICAL: returns the EXACT (unrounded) percentage values. For a 6-speed
  // fan the step is 100/6 = 16.6666... HA's valid percentages are then
  // [16.6666, 33.3333, 50, 66.6666, 83.3333, 100]. If we sent rounded values
  // like 17%, HA's percentage->speed mapping (which uses ranges like
  // 16.67-33.33% = speed 2) would snap to the wrong speed. Exact values land
  // in the correct bucket. Rounding belongs only in the display label.
  function _fanStepPercentages(featureConfig) {
    const fc = featureConfig ?? {};
    let count = Number(fc.speed_count);
    if (!Number.isFinite(count) || count <= 0) {
      const step = Number(fc.percentage_step);
      if (Number.isFinite(step) && step > 0 && step <= 100) {
        count = Math.max(1, Math.round(100 / step));
      }
    }
    if (!Number.isFinite(count) || count <= 0) count = 3;
    count = Math.min(count, 10);

    // Prefer the entity's exact percentage_step when available - that's the
    // value HA's range mapping was computed against.
    const exactStep = Number(fc.percentage_step);
    if (Number.isFinite(exactStep) && exactStep > 0 && exactStep <= 100) {
      return Array.from({ length: count }, (_, i) => (i + 1) * exactStep);
    }
    // Fallback: evenly spaced across 0-100 (still unrounded).
    return Array.from({ length: count }, (_, i) => ((i + 1) / count) * 100);
  }

  // Step labels are simply 1..N - matches what the entity's physical remote
  // typically displays (most fan remotes / panels label speeds 1, 2, 3, ...).
  // Display-only - commands are sent against the underlying exact percentage.
  function _fanStepLabels(percentages) {
    return percentages.map((_, i) => String(i + 1));
  }

  const FAN_STYLES = /* css */`
    ${NODALIA_BASE}

    /* Fan icon: keep NODALIA_BASE 58px sizing for consistency with other Nodalia
       cards. Daniel uses 38px, but at HArvest scale a 58px icon reads better
       and centres correctly when the card is collapsed. */
    [part=card-icon] svg { opacity: 1; }
    [part=card][data-state="off"] [part=card-icon].ndl-fan-icon svg {
      color: color-mix(in srgb, var(--hrv-color-text, #1a1a2e) 50%, transparent);
    }
    [part=card][data-state="on"] [part=card-icon].ndl-fan-icon {
      background: color-mix(in srgb,
                  var(--ndl-accent, var(--hrv-color-accent, #6366f1)) 24%,
                  color-mix(in srgb, var(--hrv-color-text, #1a1a2e) 8%, transparent));
    }
    [part=card][data-state="on"] [part=card-icon].ndl-fan-icon svg {
      color: var(--ndl-accent, var(--hrv-color-accent, #6366f1));
    }

    /* Header chip cluster */
    .ndl-fan-chips {
      display: flex;
      align-items: center;
      gap: 6px;
      flex-wrap: nowrap;
      justify-content: flex-end;
    }
    .ndl-fan-chips .ndl-chip {
      font-size: 11px;
      font-weight: 700;
      height: 22px;
      padding: 0 8px;
    }
    .ndl-fan-chip-state[data-state="off"] {
      opacity: 0.65;
    }

    [part=card-body] {
      display: flex;
      flex-direction: column;
    }

    /* Spinning blade animation - opt-in via this.config.animate */
    @keyframes ndl-fan-spin {
      0%   { transform: rotate(0deg); }
      100% { transform: rotate(360deg); }
    }
    [part=card-icon][data-animate="true"] svg {
      animation: ndl-fan-spin 1.5s linear infinite;
      transform-origin: center;
    }

    /* Controls shell - collapses when fan is off, matching Daniel */
    .ndl-fan-controls-shell {
      display: grid;
      gap: 10px;
      overflow: hidden;
      max-height: 400px;
      opacity: 1;
      margin-top: 12px;
      transition: max-height 0.45s cubic-bezier(0.22, 0.84, 0.26, 1),
                  margin-top 0.45s cubic-bezier(0.22, 0.84, 0.26, 1),
                  opacity 0.35s ease;
    }
    .ndl-fan-controls-shell[data-collapsed="true"] {
      max-height: 0;
      margin-top: 0;
      opacity: 0;
      pointer-events: none;
    }

    /* Slider row - slider + action buttons side by side */
    .ndl-fan-slider-row {
      display: grid;
      grid-template-columns: minmax(0, 1fr) auto;
      align-items: center;
      gap: 14px;
      padding-inline: 4px;
    }
    .ndl-fan-slider-row--solo {
      grid-template-columns: minmax(0, 1fr);
    }

    .ndl-fan-slider-wrap {
      align-items: center;
      background: color-mix(in srgb, var(--hrv-color-text, #1a1a2e) 4%, transparent);
      border: 1px solid color-mix(in srgb, var(--hrv-color-text, #1a1a2e) 6%, transparent);
      border-radius: 999px;
      box-shadow: inset 0 1px 0 color-mix(in srgb, var(--hrv-color-text, #1a1a2e) 4%, transparent);
      display: flex;
      min-height: 44px;
      padding: 0 14px;
    }
    .ndl-fan-slider-shell {
      flex: 1;
      min-width: 0;
      position: relative;
    }
    .ndl-fan-slider-track {
      position: absolute;
      top: 50%;
      left: 0;
      right: 0;
      height: 22px;
      transform: translateY(-50%);
      border-radius: 999px;
      background: color-mix(in srgb, var(--hrv-color-text, #1a1a2e) 14%, transparent);
      overflow: hidden;
      pointer-events: none;
    }
    .ndl-fan-slider-track::before {
      content: "";
      position: absolute;
      inset: 0;
      border-radius: inherit;
      background: var(--ndl-accent, var(--hrv-color-accent, #6366f1));
      transform: scaleX(calc(var(--ndl-fan-percentage, 0) / 100));
      transform-origin: left center;
      transition: transform 0.15s ease;
    }

    .ndl-fan-slider {
      -webkit-appearance: none;
      appearance: none;
      background: transparent;
      border: 0;
      width: 100%;
      height: 44px;
      margin: 0;
      cursor: pointer;
      outline: none;
      position: relative;
      z-index: 2;
    }
    .ndl-fan-slider::-webkit-slider-thumb {
      -webkit-appearance: none;
      width: 28px;
      height: 28px;
      background: transparent;
      cursor: grab;
    }
    .ndl-fan-slider::-webkit-slider-thumb:active { cursor: grabbing; }
    .ndl-fan-slider::-moz-range-thumb {
      width: 28px;
      height: 28px;
      background: transparent;
      border: 0;
      cursor: grab;
    }

    /* Action buttons (oscillate, preset toggle) on the right of the slider */
    .ndl-fan-slider-actions {
      display: flex;
      gap: 8px;
      flex-shrink: 0;
    }
    .ndl-fan-control {
      align-items: center;
      appearance: none;
      -webkit-backdrop-filter: blur(18px);
      backdrop-filter: blur(18px);
      background: color-mix(in srgb, var(--hrv-color-text, #1a1a2e) 5%, transparent);
      border: 1px solid color-mix(in srgb, var(--hrv-color-text, #1a1a2e) 6%, transparent);
      border-radius: 999px;
      box-shadow: inset 0 1px 0 color-mix(in srgb, var(--hrv-color-text, #1a1a2e) 6%, transparent);
      color: var(--ndl-fg, var(--hrv-color-text, #1a1a2e));
      cursor: pointer;
      display: inline-flex;
      flex: 0 0 auto;
      height: 36px;
      width: 36px;
      justify-content: center;
      line-height: 0;
      padding: 0;
      transition: transform 180ms cubic-bezier(0.22, 0.84, 0.26, 1),
                  background 200ms ease, border-color 200ms ease;
    }
    .ndl-fan-control[data-active="true"] {
      background: color-mix(in srgb, var(--ndl-accent, var(--hrv-color-accent, #6366f1)) 18%,
                  color-mix(in srgb, var(--hrv-color-text, #1a1a2e) 8%, transparent));
      border-color: color-mix(in srgb, var(--ndl-accent, var(--hrv-color-accent, #6366f1)) 48%,
                  color-mix(in srgb, var(--hrv-color-text, #1a1a2e) 12%, transparent));
    }
    .ndl-fan-control:hover { transform: translateY(-1px); }
    .ndl-fan-control.is-pressing {
      animation: ndl-btn-bounce var(--hrv-motion-bounce, 0.35s cubic-bezier(0.2, 0.9, 0.24, 1)) forwards;
    }
    .ndl-fan-control svg {
      width: 18px;
      height: 18px;
    }
    .ndl-fan-control [part^="fan-"] {
      display: inline-flex;
      align-items: center;
      justify-content: center;
    }

    /* Stepped mode: row of pill buttons, one per speed step */
    .ndl-fan-stepped-row {
      display: flex;
      gap: 6px;
      flex-wrap: wrap;
      justify-content: stretch;
    }
    .ndl-fan-step-btn {
      align-items: center;
      appearance: none;
      background: color-mix(in srgb, var(--hrv-color-text, #1a1a2e) 4%, transparent);
      border: 1px solid color-mix(in srgb, var(--hrv-color-text, #1a1a2e) 6%, transparent);
      border-radius: 999px;
      box-shadow: inset 0 1px 0 color-mix(in srgb, var(--hrv-color-text, #1a1a2e) 4%, transparent);
      color: var(--ndl-fg, var(--hrv-color-text, #1a1a2e));
      cursor: pointer;
      display: inline-flex;
      flex: 1 1 0;
      font-size: 12px;
      font-weight: 600;
      min-width: 56px;
      height: 44px;
      justify-content: center;
      padding: 0 10px;
      transition: background 200ms ease, border-color 200ms ease, transform 180ms cubic-bezier(0.22, 0.84, 0.26, 1);
    }
    .ndl-fan-step-btn[data-active="true"] {
      background: color-mix(in srgb, var(--ndl-accent, var(--hrv-color-accent, #6366f1)) 22%,
                  color-mix(in srgb, var(--hrv-color-text, #1a1a2e) 6%, transparent));
      border-color: color-mix(in srgb, var(--ndl-accent, var(--hrv-color-accent, #6366f1)) 50%, transparent);
    }
    .ndl-fan-step-btn:hover { transform: translateY(-1px); }
    .ndl-fan-step-btn.is-pressing {
      animation: ndl-btn-bounce var(--hrv-motion-bounce, 0.35s cubic-bezier(0.2, 0.9, 0.24, 1)) forwards;
    }

    /* Cycle mode: one pill button showing the current percentage; tap advances */
    .ndl-fan-cycle-row {
      display: grid;
      grid-template-columns: minmax(0, 1fr) auto;
      gap: 14px;
      align-items: center;
      padding-inline: 4px;
    }
    .ndl-fan-cycle-row--solo { grid-template-columns: minmax(0, 1fr); }
    .ndl-fan-cycle-btn {
      align-items: center;
      appearance: none;
      background: color-mix(in srgb, var(--hrv-color-text, #1a1a2e) 4%, transparent);
      border: 1px solid color-mix(in srgb, var(--hrv-color-text, #1a1a2e) 6%, transparent);
      border-radius: 999px;
      box-shadow: inset 0 1px 0 color-mix(in srgb, var(--hrv-color-text, #1a1a2e) 4%, transparent);
      color: var(--ndl-fg, var(--hrv-color-text, #1a1a2e));
      cursor: pointer;
      display: inline-flex;
      gap: 8px;
      height: 44px;
      width: 100%;
      justify-content: center;
      padding: 0 18px;
      font-size: 16px;
      font-weight: 700;
      transition: background 200ms ease, border-color 200ms ease, transform 180ms cubic-bezier(0.22, 0.84, 0.26, 1);
    }
    .ndl-fan-cycle-btn[data-on="true"] {
      background: color-mix(in srgb, var(--ndl-accent, var(--hrv-color-accent, #6366f1)) 18%,
                  color-mix(in srgb, var(--hrv-color-text, #1a1a2e) 4%, transparent));
      border-color: color-mix(in srgb, var(--ndl-accent, var(--hrv-color-accent, #6366f1)) 40%, transparent);
    }
    .ndl-fan-cycle-btn:hover { transform: translateY(-1px); }
    .ndl-fan-cycle-btn.is-pressing {
      animation: ndl-btn-bounce var(--hrv-motion-bounce, 0.35s cubic-bezier(0.2, 0.9, 0.24, 1)) forwards;
    }
    .ndl-fan-cycle-icon {
      display: inline-flex;
      align-items: center;
    }
    .ndl-fan-cycle-icon svg {
      width: 18px;
      height: 18px;
      opacity: 0.85;
    }
    .ndl-fan-cycle-label {
      font-size: 14px;
      font-weight: 700;
      letter-spacing: 0.02em;
    }

    /* Preset panel - hidden by default, slides down when toggle button is on */
    .ndl-fan-preset-panel {
      display: grid;
      gap: 6px;
      grid-template-columns: repeat(auto-fit, minmax(72px, 1fr));
      max-height: 0;
      opacity: 0;
      overflow: hidden;
      pointer-events: none;
      transition: max-height 0.32s cubic-bezier(0.22, 0.84, 0.26, 1),
                  opacity 0.28s ease;
    }
    .ndl-fan-preset-panel[data-open="true"] {
      max-height: 200px;
      opacity: 1;
      pointer-events: auto;
    }
    .ndl-fan-preset {
      align-items: center;
      appearance: none;
      background: color-mix(in srgb, var(--hrv-color-text, #1a1a2e) 5%, transparent);
      border: 1px solid color-mix(in srgb, var(--hrv-color-text, #1a1a2e) 8%, transparent);
      border-radius: 999px;
      color: var(--ndl-fg, var(--hrv-color-text, #1a1a2e));
      cursor: pointer;
      display: inline-flex;
      font-size: 11px;
      font-weight: 600;
      height: 30px;
      justify-content: center;
      padding: 0 12px;
      transition: background 200ms ease, border-color 200ms ease;
    }
    .ndl-fan-preset[data-active="true"] {
      background: color-mix(in srgb, var(--ndl-accent, var(--hrv-color-accent, #6366f1)) 22%,
                  color-mix(in srgb, var(--hrv-color-text, #1a1a2e) 8%, transparent));
      border-color: color-mix(in srgb, var(--ndl-accent, var(--hrv-color-accent, #6366f1)) 50%, transparent);
    }

    /* Read-only label */
    .ndl-fan-ro-label {
      font-size: 13px;
      font-weight: 600;
      color: var(--ndl-fg, var(--hrv-color-text, #1a1a2e));
      opacity: 0.6;
      text-align: center;
      padding: 8px 0;
    }

    /* Hide chips and label until populated */
    .ndl-fan-chip-state:empty,
    .ndl-fan-chip-pct:empty,
    .ndl-fan-chip-preset:empty,
    .ndl-fan-ro-label:empty { display: none; }

    /* Compact / mini layout */
    [part=card].ndl-compact .ndl-fan-control { height: 32px; width: 32px; }
    [part=card].ndl-compact .ndl-fan-control svg { width: 16px; height: 16px; }
    [part=card].ndl-mini .ndl-fan-slider-actions { display: none; }
    [part=card].ndl-mini .ndl-fan-preset-panel { display: none; }
  `;

  class FanCard extends BaseCard {
    #card = null;
    #shellEl = null;
    #sliderShell = null;
    #slider = null;
    #stateChipEl = null;
    #pctChipEl = null;
    #presetChipEl = null;
    #roLabel = null;
    #oscBtn = null;
    #presetToggleBtn = null;
    #presetPanelEl = null;
    #presetPills = [];
    #stepBtns = [];
    #cycleBtn = null;
    #cycleStepIdx = -1;
    #presetCycleIdx = -1;
    #availablePresetModes = [];

    #isOn = false;
    #percentage = 0;
    #oscillating = false;
    #presetMode = "";
    #presetPanelOpen = false;
    #stateless = false;
    #speedMode = "continuous";
    #steppedPercentages = [];
    #lastAttrs = {};
    #wasOn = null;
    #sendPct;
    #layoutTeardown = null;

    constructor(def, root, config, i18n) {
      super(def, root, config, i18n);
      this.#sendPct = _debounce(this.#doSendPct.bind(this), 300);
    }

    render() {
      const isWritable = this.def.capabilities === "read-write";
      const features = this.def.supported_features ?? [];
      const hints = this.config.displayHints ?? this.def.display_hints ?? {};
      const displayMode = hints.display_mode ?? "continuous";
      const supportsSpeed = features.includes("set_speed");
      // The fan's speed UI flavour. "on-off" hides speed entirely; "continuous"
      // is a percentage slider; "stepped" is one pill button per speed step;
      // "cycle" is a single button that advances through speeds on each tap.
      const speedMode = !supportsSpeed ? "off" : (displayMode === "on-off" ? "off" : displayMode);
      const hasSpeed = speedMode !== "off";
      const hasOsc = hints.show_oscillate !== false && features.includes("oscillate");
      const presetModes = hints.show_presets !== false ? (this.def.feature_config?.preset_modes ?? []) : [];
      const hasSecondaryControls = hasOsc || presetModes.length > 0;
      const hasAnyControls = isWritable && (hasSpeed || hasSecondaryControls);
      const pctStep = this.def.feature_config?.percentage_step ?? 1;
      this.#speedMode = speedMode;
      this.#steppedPercentages = _fanStepPercentages(this.def.feature_config);
      this.#availablePresetModes = presetModes.slice();

      // Build the inner controls markup. If there are no controls at all
      // (on-off only fan), skip the shell wrapper entirely so the card height
      // stays constant when toggling on/off (no margin-top jiggle).
      const secondaryActionsMarkup = hasSecondaryControls
        ? /* html */`
            <div class="ndl-fan-slider-actions">
              ${hasOsc ? /* html */`<button class="ndl-fan-control ndl-fan-osc-btn" type="button" data-active="false" aria-label="Oscillation" title="Oscillation"><span part="fan-osc-icon" aria-hidden="true"></span></button>` : ""}
              ${presetModes.length ? /* html */`<button class="ndl-fan-control ndl-fan-preset-toggle" type="button" data-active="false" aria-label="Preset modes" title="Preset modes"><span part="fan-preset-icon" aria-hidden="true"></span></button>` : ""}
            </div>
          `
        : "";

      let speedRowMarkup = "";
      if (speedMode === "continuous") {
        speedRowMarkup = /* html */`
          <div class="ndl-fan-slider-row ${hasSecondaryControls ? "" : "ndl-fan-slider-row--solo"}">
            <div class="ndl-fan-slider-wrap">
              <div class="ndl-fan-slider-shell">
                <div class="ndl-fan-slider-track"></div>
                <input type="range" class="ndl-fan-slider"
                  min="0" max="100" step="${pctStep}" value="0"
                  aria-label="${_esc(this.def.friendly_name)} speed">
              </div>
            </div>
            ${secondaryActionsMarkup}
          </div>
        `;
      } else if (speedMode === "stepped") {
        const labels = _fanStepLabels(this.#steppedPercentages);
        speedRowMarkup = /* html */`
          <div class="ndl-fan-stepped-row">
            ${this.#steppedPercentages.map((pct, i) => /* html */`<button class="ndl-fan-step-btn" data-pct="${pct}" data-active="false" type="button">${_esc(labels[i])}</button>`).join("")}
          </div>
          ${hasSecondaryControls ? /* html */`<div class="ndl-fan-slider-actions ndl-fan-slider-actions--solo">${secondaryActionsMarkup.replace(/^\s*<div class="ndl-fan-slider-actions">|<\/div>\s*$/g, "").trim()}</div>` : ""}
        `;
        // Simpler: just include secondaryActionsMarkup again as its own row.
        speedRowMarkup = /* html */`
          <div class="ndl-fan-stepped-row">
            ${this.#steppedPercentages.map((pct, i) => /* html */`<button class="ndl-fan-step-btn" data-pct="${pct}" data-active="false" type="button">${_esc(labels[i])}</button>`).join("")}
          </div>
          ${secondaryActionsMarkup}
        `;
      } else if (speedMode === "cycle") {
        // Cycle mode: the button has a static label and a tap-to-cycle icon.
        // Stateless by definition - we never reflect any state-derived value
        // here (the user could have changed the fan via remote and we wouldn't
        // know). The bounce animation is the only feedback for a tap.
        speedRowMarkup = /* html */`
          <div class="ndl-fan-cycle-row ${hasSecondaryControls ? "" : "ndl-fan-cycle-row--solo"}">
            <button class="ndl-fan-cycle-btn" data-on="false" type="button" aria-label="Cycle speed">
              <span class="ndl-fan-cycle-icon" part="fan-cycle-icon" aria-hidden="true"></span>
              <span class="ndl-fan-cycle-label">Speed</span>
            </button>
            ${secondaryActionsMarkup}
          </div>
        `;
      }
      // Standalone secondary-actions row (oscillate / preset toggle) when there
      // is no speed control of any kind but we still have those controls.
      const standaloneActionsMarkup = (speedMode === "off" && hasSecondaryControls)
        ? /* html */`
            <div class="ndl-fan-slider-actions ndl-fan-slider-actions--solo">
              ${hasOsc ? /* html */`<button class="ndl-fan-control ndl-fan-osc-btn" type="button" data-active="false" aria-label="Oscillation" title="Oscillation"><span part="fan-osc-icon" aria-hidden="true"></span></button>` : ""}
              ${presetModes.length ? /* html */`<button class="ndl-fan-control ndl-fan-preset-toggle" type="button" data-active="false" aria-label="Preset modes" title="Preset modes"><span part="fan-preset-icon" aria-hidden="true"></span></button>` : ""}
            </div>
          `
        : "";
      // In cycle mode the preset toggle button cycles through preset modes
      // directly (one tap = next preset). No panel of pills is rendered.
      const presetPanelMarkup = (presetModes.length && speedMode !== "cycle")
        ? /* html */`
            <div class="ndl-fan-preset-panel" data-open="false">
              ${presetModes.map((m) => /* html */`<button class="ndl-fan-preset" data-preset="${_esc(m)}" data-active="false" type="button">${_capitalize(m)}</button>`).join("")}
            </div>
          `
        : "";

      this.root.innerHTML = /* html */`
        <style>${FAN_STYLES}${COMPANION_DOT_STYLES}${NDL_ROW_CSS}</style>
        <div part="card" class="ndl-fan-card">
          <div part="card-header">
            <span part="card-icon" class="ndl-fan-icon" aria-hidden="true"></span>
            <span part="card-name">${_esc(this.def.friendly_name)}</span>
            ${isWritable ? /* html */`
              <div class="ndl-fan-chips">
                <span class="ndl-chip ndl-fan-chip-state"></span>
                ${(hasSpeed && speedMode !== "cycle") ? `<span class="ndl-chip ndl-fan-chip-pct"></span>` : ""}
                ${(presetModes.length && speedMode !== "cycle") ? `<span class="ndl-chip ndl-fan-chip-preset"></span>` : ""}
              </div>
            ` : ""}
          </div>
          ${hasAnyControls ? /* html */`
            <div part="card-body">
              <div class="ndl-fan-controls-shell">
                ${speedRowMarkup}
                ${standaloneActionsMarkup}
                ${presetPanelMarkup}
              </div>
            </div>
          ` : !isWritable ? /* html */`
            <div part="card-body"><div class="ndl-fan-ro-label"></div></div>
          ` : ""}
          ${this.renderAriaLiveHTML()}
          ${this.renderCompanionZoneHTML()}
          <div part="stale-indicator" aria-hidden="true"></div>
        </div>
      `;

      // Cache refs
      this.#card = this.root.querySelector("[part=card]");
      this.#shellEl = this.root.querySelector(".ndl-fan-controls-shell");
      this.#sliderShell = this.root.querySelector(".ndl-fan-slider-shell");
      this.#slider = this.root.querySelector(".ndl-fan-slider");
      this.#stateChipEl = this.root.querySelector(".ndl-fan-chip-state");
      this.#pctChipEl = this.root.querySelector(".ndl-fan-chip-pct");
      this.#presetChipEl = this.root.querySelector(".ndl-fan-chip-preset");
      this.#roLabel = this.root.querySelector(".ndl-fan-ro-label");
      this.#oscBtn = this.root.querySelector(".ndl-fan-osc-btn");
      this.#presetToggleBtn = this.root.querySelector(".ndl-fan-preset-toggle");
      this.#presetPanelEl = this.root.querySelector(".ndl-fan-preset-panel");
      this.#presetPills = [...this.root.querySelectorAll(".ndl-fan-preset")];
      this.#stepBtns = [...this.root.querySelectorAll(".ndl-fan-step-btn")];
      this.#cycleBtn = this.root.querySelector(".ndl-fan-cycle-btn");

      // Icons
      this.renderIcon(this.resolveIcon(this.def.icon, "mdi:fan"), "card-icon");
      if (this.#oscBtn) this.renderIcon("mdi:rotate-360", "fan-osc-icon");
      if (this.#presetToggleBtn) this.renderIcon("mdi:tune-variant", "fan-preset-icon");
      if (this.#cycleBtn) this.renderIcon("mdi:rotate-360", "fan-cycle-icon");

      // Tap on icon = toggle
      const iconEl = this.root.querySelector("[part=card-icon]");
      if (iconEl && isWritable) {
        this._attachGestureHandlers(iconEl, {
          onTap: () => {
            _triggerBounce(iconEl);
            const tap = this.config.gestureConfig?.tap;
            if (tap) { this._runAction(tap); return; }
            this.config.card?.sendCommand("toggle", {});
          },
        });
      }

      // Oscillate
      if (this.#oscBtn) {
        this.#oscBtn.addEventListener("click", () => {
          _triggerBounce(this.#oscBtn);
          this.config.card?.sendCommand("oscillate", { oscillating: !this.#oscillating });
        });
      }

      // Preset toggle button.
      // - In cycle mode: each tap advances through presetModes locally and
      //   sends set_preset_mode. No panel is rendered. Stateless by design.
      // - In other modes: tap toggles the preset panel open/closed.
      if (this.#presetToggleBtn) {
        if (this.#speedMode === "cycle") {
          this.#presetToggleBtn.addEventListener("click", () => {
            _triggerBounce(this.#presetToggleBtn);
            if (!this.#availablePresetModes.length) return;
            this.#presetCycleIdx = (this.#presetCycleIdx + 1) % this.#availablePresetModes.length;
            const next = this.#availablePresetModes[this.#presetCycleIdx];
            this.config.card?.sendCommand("set_preset_mode", { preset_mode: next });
          });
        } else {
          this.#presetToggleBtn.addEventListener("click", () => {
            _triggerBounce(this.#presetToggleBtn);
            this.#presetPanelOpen = !this.#presetPanelOpen;
            this.#applyPresetPanelState();
          });
        }
      }

      // Preset pills
      for (const pill of this.#presetPills) {
        pill.addEventListener("click", () => {
          _triggerBounce(pill);
          this.config.card?.sendCommand("set_preset_mode", { preset_mode: pill.dataset.preset });
        });
      }

      // Slider drag (continuous mode). Use Number() not parseInt() so the
      // exact slider value (e.g. 16.6666... for a 6-speed fan with step
      // 100/6) is preserved instead of being truncated to 16.
      if (this.#slider) {
        this.#slider.addEventListener("input", () => {
          this.#percentage = Number(this.#slider.value);
          if (this.#sliderShell) {
            this.#sliderShell.style.setProperty("--ndl-fan-percentage", String(this.#percentage));
          }
          this.#updatePctChip();
          this.#sendPct();
        });
        this.guardSlider(this.#slider, this.#sendPct);
      }

      // Stepped buttons - each sends its assigned percentage immediately.
      // Optimistically update the chip so the label flips to the new step
      // without waiting for the server echo.
      for (const btn of this.#stepBtns) {
        btn.addEventListener("click", () => {
          _triggerBounce(btn);
          const pct = Number(btn.dataset.pct);
          if (!Number.isFinite(pct)) return;
          this.#percentage = pct;
          this.#isOn = true;
          this.#updatePctChip();
          this.config.card?.sendCommand("set_percentage", { percentage: pct });
        });
      }

      // Cycle button - advances through steppedPercentages on each tap and
      // wraps from the highest speed back to the lowest. Off is never part of
      // the loop (the top-left icon button is the dedicated power toggle).
      // We track the index purely locally because in cycle mode we cannot
      // trust the entity's reported percentage (the user might have changed
      // the fan via a physical remote without HA knowing).
      if (this.#cycleBtn) {
        this.#cycleBtn.addEventListener("click", () => {
          _triggerBounce(this.#cycleBtn);
          if (!this.#steppedPercentages.length) return;
          this.#cycleStepIdx = (this.#cycleStepIdx + 1) % this.#steppedPercentages.length;
          const next = this.#steppedPercentages[this.#cycleStepIdx];
          this.config.card?.sendCommand("set_percentage", { percentage: next });
        });
      }

      this.renderCompanions();
      _applyCompanionTooltips(this.root);
      this._attachGestureHandlers(this.#card);
      this.#layoutTeardown = _layoutObserver(this);
    }

    applyState(state, attributes) {
      const newIsOn = state === "on";
      this.#isOn = newIsOn;
      this.#lastAttrs = attributes;
      this.#oscillating = attributes.oscillating ?? false;
      this.#presetMode = attributes.preset_mode ?? "";
      // Stateless detection - lesson #35. When HA reports assumed_state:true,
      // suppress visual reflection of attributes on buttons. Cycle mode is
      // stateless by design (the user picked it precisely because the fan's
      // reported speed is unreliable) so we force stateless behaviour there
      // regardless of assumed_state.
      this.#stateless = attributes.assumed_state === true || this.#speedMode === "cycle";

      // Drive surface tint. In read-only mode always keep the accent circle visible,
      // matching the remote card reference. The ro-label already conveys the state.
      const _fanIsWritable = this.def.capabilities === "read-write";
      if (this.#card) this.#card.dataset.state = (newIsOn || !_fanIsWritable) ? "on" : "off";

      // Power-up / power-down animation
      if (this.#wasOn !== null && this.#wasOn !== newIsOn && this.#card) {
        this.#card.classList.remove("ndl-powering-up", "ndl-powering-down");
        void this.#card.getBoundingClientRect();
        this.#card.classList.add(newIsOn ? "ndl-powering-up" : "ndl-powering-down");
      }
      this.#wasOn = newIsOn;

      // Collapse controls when off
      if (this.#shellEl) this.#shellEl.dataset.collapsed = String(!newIsOn);

      // Accent: fan domain palette. In read-only mode always set accent so the
      // forced data-state="on" circle uses the fan colour rather than the generic fallback.
      const palette = _colorsFor("fan");
      if (this.#card) {
        if (newIsOn || !_fanIsWritable) this.#card.style.setProperty("--ndl-accent", palette.accent);
        else this.#card.style.removeProperty("--ndl-accent");
      }

      // Sync slider value (guarded so user drag isn't clobbered)
      if (!this.isSliderActive(this.#slider)) {
        this.#percentage = attributes.percentage ?? 0;
        if (this.#slider) this.#slider.value = String(this.#percentage);
        if (this.#sliderShell) {
          this.#sliderShell.style.setProperty("--ndl-fan-percentage", String(this.#percentage));
        }
      }

      // Stepped buttons - mark the rung closest to the current percentage.
      // Skip reflection for stateless fans.
      if (this.#stepBtns.length) {
        let activeIdx = -1;
        if (newIsOn && !this.#stateless) {
          let minDiff = Infinity;
          for (let i = 0; i < this.#steppedPercentages.length; i++) {
            const d = Math.abs(this.#steppedPercentages[i] - this.#percentage);
            if (d < minDiff) { minDiff = d; activeIdx = i; }
          }
        }
        for (let i = 0; i < this.#stepBtns.length; i++) {
          this.#stepBtns[i].setAttribute("data-active", String(i === activeIdx));
        }
      }

      // Cycle button - only the accent (data-on) reflects the entity's on/off
      // state. The label text is static; we never write a percentage here.
      if (this.#cycleBtn) {
        this.#cycleBtn.setAttribute("data-on", String(newIsOn));
      }

      // Header chips
      if (this.#stateChipEl) {
        this.#stateChipEl.textContent = _capitalize(state);
        this.#stateChipEl.dataset.state = newIsOn ? "on" : "off";
      }
      this.#updatePctChip();
      if (this.#presetChipEl) {
        this.#presetChipEl.textContent = newIsOn && this.#presetMode
          ? _capitalize(this.#presetMode)
          : "";
      }

      // Re-render the header icon for the current state. The server-side
      // icon_state_map gives us mdi:fan for "on" and mdi:fan-off for "off";
      // without this call the icon stays frozen on whatever state the def
      // was first sent with.
      const iconForState = this.def.icon_state_map?.[state]
        ?? this.def.icon_state_map?.["*"]
        ?? this.def.icon
        ?? "mdi:fan";
      this.renderIcon(this.resolveIcon(iconForState, "mdi:fan"), "card-icon");

      // Spinning blade animation - opt-in via this.config.animate; never animate in read-only mode
      const iconEl = this.root.querySelector("[part=card-icon]");
      if (iconEl) {
        iconEl.setAttribute("data-animate", String(_fanIsWritable && newIsOn && !!this.config.animate));
      }

      // Oscillate active state. Skip reflection for stateless fans.
      if (this.#oscBtn) {
        const active = this.#stateless ? false : this.#oscillating;
        this.#oscBtn.setAttribute("data-active", String(active));
      }

      // Preset toggle: in non-cycle modes this reflects the panel-open state.
      // In cycle mode the button cycles through presets and stays neutral.
      if (this.#presetToggleBtn) {
        const showActive = this.#speedMode !== "cycle" && this.#presetPanelOpen;
        this.#presetToggleBtn.setAttribute("data-active", String(showActive));
      }

      // Preset pill active. Skip reflection for stateless fans.
      for (const pill of this.#presetPills) {
        const active = this.#stateless ? false : (pill.dataset.preset === this.#presetMode);
        pill.setAttribute("data-active", String(active));
      }

      // Read-only label (rounded for display)
      if (this.#roLabel) {
        this.#roLabel.textContent = newIsOn
          ? `${Math.round(this.#percentage)}%`
          : _capitalize(state);
      }

      this.announceState(`${this.def.friendly_name}, ${state}${newIsOn ? `, ${Math.round(this.#percentage)}%` : ""}`);
    }

    predictState(action, data) {
      if (action === "toggle") {
        return { state: this.#isOn ? "off" : "on", attributes: this.#lastAttrs };
      }
      if (action === "oscillate" && data.oscillating != null) {
        return { state: this.#isOn ? "on" : "off", attributes: { ...this.#lastAttrs, oscillating: data.oscillating } };
      }
      if (action === "set_preset_mode" && data.preset_mode) {
        return { state: this.#isOn ? "on" : "off", attributes: { ...this.#lastAttrs, preset_mode: data.preset_mode } };
      }
      if (action === "set_percentage" && data.percentage != null) {
        return { state: this.#isOn ? "on" : "off", attributes: { ...this.#lastAttrs, percentage: data.percentage } };
      }
      return null;
    }

    destroy() {
      if (this.#layoutTeardown) { this.#layoutTeardown(); this.#layoutTeardown = null; }
    }

    // Update the percentage chip in the header. In stepped mode the chip
    // shows the step's label (Low / Medium / High) so it matches the active
    // step button rather than showing a raw percentage like "33%". In
    // continuous mode it shows the rounded percentage.
    #updatePctChip() {
      if (!this.#pctChipEl) return;
      if (!this.#isOn) { this.#pctChipEl.textContent = ""; return; }
      if (this.#speedMode === "stepped" && this.#steppedPercentages.length) {
        let nearest = 0;
        let minDiff = Infinity;
        for (let i = 0; i < this.#steppedPercentages.length; i++) {
          const d = Math.abs(this.#steppedPercentages[i] - this.#percentage);
          if (d < minDiff) { minDiff = d; nearest = i; }
        }
        const labels = _fanStepLabels(this.#steppedPercentages);
        this.#pctChipEl.textContent = labels[nearest] ?? `${Math.round(this.#percentage)}%`;
      } else {
        this.#pctChipEl.textContent = `${Math.round(this.#percentage)}%`;
      }
    }

    #applyPresetPanelState() {
      if (this.#presetPanelEl) {
        this.#presetPanelEl.dataset.open = String(this.#presetPanelOpen);
      }
      if (this.#presetToggleBtn) {
        this.#presetToggleBtn.setAttribute("data-active", String(this.#presetPanelOpen));
      }
    }

    #doSendPct() {
      if (this.#percentage <= 0) this.config.card?.sendCommand("turn_off", {});
      else this.config.card?.sendCommand("set_percentage", { percentage: this.#percentage });
    }
  }

  // ---------------------------------------------------------------------------
  // CoverCard
  // ---------------------------------------------------------------------------

  const COVER_STYLES = /* css */`
    ${NODALIA_BASE}

    /* Cover icon: accent-tinted background when open */
    [part=card][data-state="on"] [part=card-icon].ndl-cover-icon {
      background: color-mix(in srgb,
                  var(--ndl-accent, var(--hrv-color-accent, #9775fa)) 24%,
                  color-mix(in srgb, var(--hrv-color-text, #1a1a2e) 8%, transparent));
    }
    [part=card][data-state="on"] [part=card-icon].ndl-cover-icon svg {
      color: var(--ndl-accent, var(--hrv-color-accent, #9775fa));
    }

    [part=card-body] {
      display: flex;
      flex-direction: column;
    }

    .ndl-cover-controls-shell {
      display: grid;
      gap: 12px;
      overflow: hidden;
      max-height: 400px;
      opacity: 1;
      margin-top: 12px;
      transition: max-height 0.45s cubic-bezier(0.22, 0.84, 0.26, 1),
                  margin-top 0.45s cubic-bezier(0.22, 0.84, 0.26, 1),
                  opacity 0.35s ease;
    }
    .ndl-cover-controls-shell[data-collapsed="true"] {
      max-height: 0;
      margin-top: 0;
      opacity: 0;
      pointer-events: none;
    }

    /* Position slider (and tilt slider) shared visual.
       Same recipe as the fan slider: pill outer, accent-fill via --progress
       CSS variable on the shell, transparent native input on top. */
    .ndl-cover-slider-wrap {
      align-items: center;
      background: color-mix(in srgb, var(--hrv-color-text, #1a1a2e) 4%, transparent);
      border: 1px solid color-mix(in srgb, var(--hrv-color-text, #1a1a2e) 6%, transparent);
      border-radius: 999px;
      box-shadow: inset 0 1px 0 color-mix(in srgb, var(--hrv-color-text, #1a1a2e) 4%, transparent);
      display: flex;
      min-height: 44px;
      padding: 0 14px;
    }
    .ndl-cover-slider-shell {
      flex: 1;
      min-width: 0;
      position: relative;
    }
    .ndl-cover-slider-track {
      position: absolute;
      top: 50%;
      left: 0;
      right: 0;
      height: 18px;
      transform: translateY(-50%);
      border-radius: 999px;
      background: color-mix(in srgb, var(--hrv-color-text, #1a1a2e) 14%, transparent);
      overflow: hidden;
      pointer-events: none;
    }
    .ndl-cover-slider-track::before {
      content: "";
      position: absolute;
      inset: 0;
      border-radius: inherit;
      background: var(--ndl-accent, var(--hrv-color-accent, #9775fa));
      transform: scaleX(calc(var(--ndl-cover-progress, 0) / 100));
      transform-origin: left center;
      transition: transform 0.15s ease;
    }
    .ndl-cover-slider {
      -webkit-appearance: none;
      appearance: none;
      background: transparent;
      border: 0;
      width: 100%;
      height: 44px;
      margin: 0;
      cursor: pointer;
      outline: none;
      position: relative;
      z-index: 2;
    }
    .ndl-cover-slider::-webkit-slider-thumb {
      -webkit-appearance: none;
      width: 28px; height: 28px;
      background: transparent;
      cursor: grab;
    }
    .ndl-cover-slider::-webkit-slider-thumb:active { cursor: grabbing; }
    .ndl-cover-slider::-moz-range-thumb {
      width: 28px; height: 28px;
      background: transparent;
      border: 0;
      cursor: grab;
    }

    /* Open / Stop / Close action pill (3 buttons in a faintly distinct
       cluster, same idiom as media player transport pill) */
    .ndl-cover-actions {
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 4px;
      padding: 3px;
      border-radius: 999px;
      background: color-mix(in srgb, var(--hrv-color-text, #1a1a2e) 4%, transparent);
      border: 1px solid color-mix(in srgb, var(--hrv-color-text, #1a1a2e) 5%, transparent);
      align-self: center;
    }
    .ndl-cover-action-btn {
      align-items: center;
      appearance: none;
      background: transparent;
      border: 0;
      border-radius: 999px;
      color: var(--ndl-fg, var(--hrv-color-text, #1a1a2e));
      cursor: pointer;
      display: inline-flex;
      height: 40px;
      width: 40px;
      justify-content: center;
      line-height: 0;
      padding: 0;
      transition: background 200ms ease, transform 180ms cubic-bezier(0.22, 0.84, 0.26, 1);
    }
    .ndl-cover-action-btn:hover {
      background: color-mix(in srgb, var(--hrv-color-text, #1a1a2e) 6%, transparent);
    }
    .ndl-cover-action-btn.is-pressing {
      animation: ndl-btn-bounce var(--hrv-motion-bounce, 0.35s cubic-bezier(0.2, 0.9, 0.24, 1)) forwards;
    }
    .ndl-cover-action-btn svg { width: 20px; height: 20px; }
    .ndl-cover-action-btn [part^="c-"] {
      display: inline-flex;
      align-items: center;
      justify-content: center;
    }

    /* Tilt row: small label + slider on the right */
    .ndl-cover-tilt-row {
      display: grid;
      grid-template-columns: auto minmax(0, 1fr);
      gap: 10px;
      align-items: center;
    }
    .ndl-cover-tilt-label {
      font-size: 11px;
      font-weight: 700;
      text-transform: uppercase;
      letter-spacing: 0.06em;
      color: var(--ndl-fg, var(--hrv-color-text, #1a1a2e));
      opacity: 0.6;
    }

    /* Read-only label */
    .ndl-cover-ro-icon {
      display: flex;
      align-items: center;
      justify-content: center;
      width: 48px;
      height: 48px;
      margin: 8px auto 4px;
      opacity: 0.7;
    }
    .ndl-cover-ro-icon svg { width: 36px; height: 36px; }

    .ndl-cover-ro-label {
      font-size: 13px;
      font-weight: 600;
      color: var(--ndl-fg, var(--hrv-color-text, #1a1a2e));
      opacity: 0.6;
      text-align: center;
      padding: 4px 0 8px;
    }

    /* Hide chip + label until populated */
    .ndl-cover-chip:empty,
    .ndl-cover-ro-label:empty { display: none; }

    /* Compact / mini */
    [part=card].ndl-compact .ndl-cover-action-btn { height: 36px; width: 36px; }
    [part=card].ndl-compact .ndl-cover-slider-wrap { min-height: 40px; padding: 0 12px; }
    [part=card].ndl-mini .ndl-cover-controls-shell { display: none; }
  `;

  const _COVER_ICONS = {
    garage: { open: "mdi:garage-open", closed: "mdi:garage" },
    door: { open: "mdi:door-open", closed: "mdi:door-closed" },
    window: { open: "mdi:window-open", closed: "mdi:window-closed" },
    blind: { open: "mdi:blinds-open", closed: "mdi:blinds" },
    shutter: { open: "mdi:window-shutter-open", closed: "mdi:window-shutter" },
  };

  class CoverCard extends BaseCard {
    #card = null;
    #shellEl = null;
    #chipEl = null;
    #roLabel = null;
    #posSlider = null;
    #posShell = null;
    #tiltSlider = null;
    #tiltShell = null;

    #isOpen = false;
    #position = 0;
    #tiltPosition = 0;
    #lastState = "";
    #lastAttrs = {};
    #wasOn = null;
    #sendPos;
    #sendTilt;
    #layoutTeardown = null;

    constructor(def, root, config, i18n) {
      super(def, root, config, i18n);
      this.#sendPos = _debounce(this.#doSendPos.bind(this), 300);
      this.#sendTilt = _debounce(this.#doSendTilt.bind(this), 300);
    }

    render() {
      const isWritable = this.def.capabilities === "read-write";
      const features = this.def.supported_features ?? [];
      const hints = this.config.displayHints ?? {};
      const hasPosition = hints.show_position !== false && features.includes("set_position");
      const hasTilt = hints.show_tilt !== false && features.includes("set_tilt_position");
      const hasStop = features.includes("stop");

      this.root.innerHTML = /* html */`
        <style>${COVER_STYLES}${COMPANION_DOT_STYLES}${NDL_ROW_CSS}</style>
        <div part="card" class="ndl-cover-card">
          <div part="card-header">
            <span part="card-icon" class="ndl-cover-icon" aria-hidden="true"></span>
            <span part="card-name">${_esc(this.def.friendly_name)}</span>
            <span class="ndl-chip ndl-cover-chip"></span>
          </div>
          ${isWritable ? /* html */`
            <div part="card-body">
              <div class="ndl-cover-controls-shell">
                ${hasPosition ? /* html */`
                  <div class="ndl-cover-slider-wrap">
                    <div class="ndl-cover-slider-shell ndl-cover-pos-shell">
                      <div class="ndl-cover-slider-track"></div>
                      <input type="range" class="ndl-cover-slider ndl-cover-pos-slider"
                        min="0" max="100" step="1" value="0"
                        aria-label="${_esc(this.def.friendly_name)} position">
                    </div>
                  </div>
                ` : ""}
                <div class="ndl-cover-actions">
                  <button class="ndl-cover-action-btn" data-action="open" type="button" aria-label="Open" title="Open"><span part="c-open" aria-hidden="true"></span></button>
                  ${hasStop ? /* html */`<button class="ndl-cover-action-btn" data-action="stop" type="button" aria-label="Stop" title="Stop"><span part="c-stop" aria-hidden="true"></span></button>` : ""}
                  <button class="ndl-cover-action-btn" data-action="close" type="button" aria-label="Close" title="Close"><span part="c-close" aria-hidden="true"></span></button>
                </div>
                ${hasTilt ? /* html */`
                  <div class="ndl-cover-tilt-row">
                    <span class="ndl-cover-tilt-label">Tilt</span>
                    <div class="ndl-cover-slider-wrap">
                      <div class="ndl-cover-slider-shell ndl-cover-tilt-shell">
                        <div class="ndl-cover-slider-track"></div>
                        <input type="range" class="ndl-cover-slider ndl-cover-tilt-slider"
                          min="0" max="100" step="1" value="0"
                          aria-label="${_esc(this.def.friendly_name)} tilt">
                      </div>
                    </div>
                  </div>
                ` : ""}
              </div>
            </div>
          ` : /* html */`
            <div part="card-body">
              <span part="cover-ro-icon" class="ndl-cover-ro-icon" aria-hidden="true"></span>
              <div class="ndl-cover-ro-label"></div>
            </div>
          `}
          ${this.renderAriaLiveHTML()}
          ${this.renderCompanionZoneHTML()}
          <div part="stale-indicator" aria-hidden="true"></div>
        </div>
      `;

      this.#card = this.root.querySelector("[part=card]");
      this.#shellEl = this.root.querySelector(".ndl-cover-controls-shell");
      this.#chipEl = this.root.querySelector(".ndl-cover-chip");
      this.#roLabel = this.root.querySelector(".ndl-cover-ro-label");
      this.#posSlider = this.root.querySelector(".ndl-cover-pos-slider");
      this.#posShell = this.root.querySelector(".ndl-cover-pos-shell");
      this.#tiltSlider = this.root.querySelector(".ndl-cover-tilt-slider");
      this.#tiltShell = this.root.querySelector(".ndl-cover-tilt-shell");

      this.renderIcon(this.resolveIcon(this.def.icon, "mdi:window-shutter"), "card-icon");
      this.renderIcon("mdi:arrow-up", "c-open");
      if (hasStop) this.renderIcon("mdi:stop", "c-stop");
      this.renderIcon("mdi:arrow-down", "c-close");

      // Tap on icon: toggle. If open or in motion, close. Otherwise open.
      const iconEl = this.root.querySelector("[part=card-icon]");
      if (iconEl && isWritable) {
        this._attachGestureHandlers(iconEl, {
          onTap: () => {
            _triggerBounce(iconEl);
            const tap = this.config.gestureConfig?.tap;
            if (tap) { this._runAction(tap); return; }
            const goingClosed = this.#isOpen || this.#lastState === "opening";
            this.config.card?.sendCommand(goingClosed ? "close_cover" : "open_cover", {});
          },
        });
      }

      // Action pill buttons: open / stop / close
      this.root.querySelectorAll(".ndl-cover-action-btn").forEach((btn) => {
        btn.addEventListener("click", () => {
          _triggerBounce(btn);
          this.config.card?.sendCommand(`${btn.dataset.action}_cover`, {});
        });
      });

      // Position slider drag (uses Number() not parseInt - lesson #47)
      if (this.#posSlider) {
        this.#posSlider.addEventListener("input", () => {
          this.#position = Number(this.#posSlider.value);
          if (this.#posShell) {
            this.#posShell.style.setProperty("--ndl-cover-progress", String(this.#position));
          }
          this.#sendPos();
        });
        this.guardSlider(this.#posSlider, this.#sendPos);
      }

      // Tilt slider drag
      if (this.#tiltSlider) {
        this.#tiltSlider.addEventListener("input", () => {
          this.#tiltPosition = Number(this.#tiltSlider.value);
          if (this.#tiltShell) {
            this.#tiltShell.style.setProperty("--ndl-cover-progress", String(this.#tiltPosition));
          }
          this.#sendTilt();
        });
        this.guardSlider(this.#tiltSlider, this.#sendTilt);
      }

      this.renderCompanions();
      _applyCompanionTooltips(this.root);
      this._attachGestureHandlers(this.#card);
      this.#layoutTeardown = _layoutObserver(this);
    }

    applyState(state, attributes) {
      this.#lastState = state;
      this.#lastAttrs = attributes;
      this.#isOpen = state === "open" || state === "opening";
      // "Active" surface tint covers anything except fully closed/unavailable.
      const active = state !== "closed" && state !== "unavailable" && state !== "unknown";

      if (this.#card) this.#card.dataset.state = active ? "on" : "off";

      if (this.#wasOn !== null && this.#wasOn !== active && this.#card) {
        this.#card.classList.remove("ndl-powering-up", "ndl-powering-down");
        void this.#card.getBoundingClientRect();
        this.#card.classList.add(active ? "ndl-powering-up" : "ndl-powering-down");
      }
      this.#wasOn = active;

      // Collapse controls when closed (matches other interactive cards)
      if (this.#shellEl) this.#shellEl.dataset.collapsed = String(!active);

      // Accent: cover domain palette
      const palette = _colorsFor("cover");
      if (this.#card) {
        if (active) this.#card.style.setProperty("--ndl-accent", palette.accent);
        else this.#card.style.removeProperty("--ndl-accent");
      }

      // Icon: device-class aware open/closed pair
      const dc = attributes.device_class ?? "shutter";
      const iconSet = _COVER_ICONS[dc] ?? _COVER_ICONS.shutter;
      const iconName = this.resolveIcon(
        this.#isOpen ? iconSet.open : iconSet.closed,
        "mdi:window-shutter",
      );
      this.renderIcon(iconName, "card-icon");
      this.renderIcon(iconName, "cover-ro-icon");

      // Position slider sync (guarded)
      const pos = attributes.current_position;
      if (pos != null && this.#posSlider && !this.isSliderActive(this.#posSlider)) {
        this.#position = pos;
        this.#posSlider.value = String(pos);
        if (this.#posShell) {
          this.#posShell.style.setProperty("--ndl-cover-progress", String(pos));
        }
      }

      // Tilt slider sync (guarded)
      const tiltPos = attributes.current_tilt_position;
      if (tiltPos != null && this.#tiltSlider && !this.isSliderActive(this.#tiltSlider)) {
        this.#tiltPosition = tiltPos;
        this.#tiltSlider.value = String(tiltPos);
        if (this.#tiltShell) {
          this.#tiltShell.style.setProperty("--ndl-cover-progress", String(tiltPos));
        }
      }

      // Header chip - state name + position % when meaningful
      if (this.#chipEl) {
        if (state === "opening" || state === "closing") {
          this.#chipEl.textContent = _capitalize(state) + "...";
        } else if (pos != null && pos !== 0 && pos !== 100) {
          // Partial position: show percentage only
          this.#chipEl.textContent = `${Math.round(pos)}%`;
        } else {
          this.#chipEl.textContent = _capitalize(state);
        }
      }

      // Read-only label
      if (this.#roLabel) {
        this.#roLabel.textContent = pos != null && pos !== 0 && pos !== 100
          ? `${_capitalize(state)} ${Math.round(pos)}%`
          : _capitalize(state);
      }

      this.announceState(`${this.def.friendly_name}, ${state}${pos != null ? `, ${Math.round(pos)}%` : ""}`);
    }

    predictState(action, data) {
      if (action === "open_cover") {
        return { state: "opening", attributes: this.#lastAttrs };
      }
      if (action === "close_cover") {
        return { state: "closing", attributes: this.#lastAttrs };
      }
      if (action === "stop_cover") {
        // Best guess: settle on whichever side we were heading toward
        const settled = this.#lastState === "opening" ? "open" : (this.#lastState === "closing" ? "closed" : this.#lastState);
        return { state: settled, attributes: this.#lastAttrs };
      }
      if (action === "set_cover_position" && data.position != null) {
        return { state: data.position > 0 ? "open" : "closed", attributes: { ...this.#lastAttrs, current_position: data.position } };
      }
      if (action === "set_cover_tilt_position" && data.tilt_position != null) {
        return { state: this.#lastState, attributes: { ...this.#lastAttrs, current_tilt_position: data.tilt_position } };
      }
      return null;
    }

    destroy() {
      if (this.#layoutTeardown) { this.#layoutTeardown(); this.#layoutTeardown = null; }
    }

    #doSendPos() {
      this.config.card?.sendCommand("set_cover_position", { position: Math.round(this.#position) });
    }

    #doSendTilt() {
      this.config.card?.sendCommand("set_cover_tilt_position", { tilt_position: Math.round(this.#tiltPosition) });
    }
  }

  // ---------------------------------------------------------------------------
  // MediaPlayerCard
  // ---------------------------------------------------------------------------

  const MEDIA_STYLES = /* css */`
    ${NODALIA_BASE}

    /* Media cards keep a neutral surface (the subtle blurred album-bg gives
       what little colour is wanted). Override NODALIA_BASE's data-state
       gradient. */
    [part=card][data-state="on"].ndl-media-card,
    [part=card].ndl-media-card {
      background: var(--hrv-color-card-background, linear-gradient(135deg,
                  color-mix(in srgb, var(--hrv-color-primary, #6366f1) 6%, var(--hrv-color-surface, #ffffff)) 0%,
                  var(--hrv-color-surface, #ffffff) 100%));
    }
    [part=card][data-state="on"].ndl-media-card::before,
    [part=card].ndl-media-card::before {
      background: linear-gradient(180deg,
                  color-mix(in srgb, var(--hrv-color-text, #1a1a2e) 4%, transparent),
                  rgba(255,255,255,0));
    }

    /* Blurred album-art background. Heavy blur + low opacity gives a subtle
       colour wash that doesn't compete with the controls. */
    .ndl-media-album-bg {
      position: absolute;
      inset: 0;
      background-image: var(--ndl-media-art-url, none);
      background-size: cover;
      background-position: center;
      filter: blur(36px) saturate(1.3);
      opacity: 0.45;
      pointer-events: none;
      z-index: 0;
    }
    .ndl-media-album-bg[data-has-art="false"] { display: none; }

    [part=card-body].ndl-media-body {
      display: flex;
      flex-direction: column;
      gap: 14px;
      /* Reserve room for the bottom-edge progress bar so content doesn't
         butt against it. */
      padding-bottom: 14px;
    }

    /* Hero row: artwork tile + title/artist + entity chip. Info column is
       top-aligned with the artwork (not centred) - matches Daniel's design
       where text sits at the top and the artwork fills more of the card. */
    .ndl-media-hero {
      display: grid;
      grid-template-columns: 72px minmax(0, 1fr) auto;
      gap: 14px;
      align-items: start;
    }
    .ndl-media-art-btn {
      width: 72px;
      height: 72px;
      padding: 0;
      border: 1px solid color-mix(in srgb, var(--hrv-color-text, #1a1a2e) 6%, transparent);
      border-radius: 20px;
      background: var(--hrv-glass-bg, linear-gradient(180deg, rgba(255,255,255,0.6) 0%, rgba(255,255,255,0.35) 100%));
      box-shadow: var(--hrv-glass-shadow,
                  0 2px 6px rgba(0,0,0,0.08),
                  0 1px 2px rgba(0,0,0,0.05),
                  inset 0 1px 0 rgba(255,255,255,0.5));
      cursor: pointer;
      overflow: hidden;
      position: relative;
      flex-shrink: 0;
      transition: transform 180ms cubic-bezier(0.22, 0.84, 0.26, 1);
    }
    .ndl-media-art-btn:hover { transform: translateY(-1px); }
    .ndl-media-art-btn.is-pressing {
      animation: ndl-btn-bounce var(--hrv-motion-bounce, 0.35s cubic-bezier(0.2, 0.9, 0.24, 1)) forwards;
    }
    .ndl-media-art-img {
      width: 100%;
      height: 100%;
      object-fit: cover;
      display: block;
    }
    .ndl-media-art-btn[data-has-art="false"] .ndl-media-art-img { display: none; }
    .ndl-media-art-icon {
      position: absolute;
      inset: 0;
      display: flex;
      align-items: center;
      justify-content: center;
    }
    .ndl-media-art-icon svg {
      width: 32px;
      height: 32px;
      color: var(--ndl-fg, var(--hrv-color-text, #1a1a2e));
      opacity: 0.7;
    }
    .ndl-media-art-btn[data-has-art="true"] .ndl-media-art-icon { display: none; }

    .ndl-media-info {
      display: flex;
      flex-direction: column;
      gap: 2px;
      min-width: 0;
      align-self: start;
      padding-top: 2px;
    }
    .ndl-media-title {
      font-size: 14px;
      font-weight: 700;
      line-height: 1.25;
      color: var(--ndl-fg, var(--hrv-color-text, #1a1a2e));
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }
    .ndl-media-artist {
      font-size: 12px;
      line-height: 1.3;
      color: var(--ndl-fg, var(--hrv-color-text, #1a1a2e));
      opacity: 0.7;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }
    .ndl-media-title:empty,
    .ndl-media-artist:empty { display: none; }

    .ndl-media-chips {
      display: flex;
      align-items: flex-start;
      gap: 6px;
      align-self: start;
      padding-top: 2px;
    }
    .ndl-media-chips .ndl-chip {
      font-size: 12px;
      font-weight: 700;
      height: 28px;
      padding: 0 14px;
      max-width: 140px;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }

    /* Transport row: vol-down | [prev | play | next] | vol-up */
    .ndl-media-transport-row {
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 14px;
    }

    /* Smaller circular volume buttons flanking the transport pill */
    .ndl-media-vol-btn {
      align-items: center;
      appearance: none;
      background: color-mix(in srgb, var(--hrv-color-text, #1a1a2e) 5%, transparent);
      border: 1px solid color-mix(in srgb, var(--hrv-color-text, #1a1a2e) 6%, transparent);
      border-radius: 999px;
      box-shadow: inset 0 1px 0 color-mix(in srgb, var(--hrv-color-text, #1a1a2e) 6%, transparent);
      color: var(--ndl-fg, var(--hrv-color-text, #1a1a2e));
      cursor: pointer;
      display: inline-flex;
      height: 32px;
      width: 32px;
      justify-content: center;
      line-height: 0;
      padding: 0;
      transition: transform 180ms cubic-bezier(0.22, 0.84, 0.26, 1),
                  background 200ms ease;
    }
    .ndl-media-vol-btn:hover { transform: translateY(-1px); }
    .ndl-media-vol-btn.is-pressing {
      animation: ndl-btn-bounce var(--hrv-motion-bounce, 0.35s cubic-bezier(0.2, 0.9, 0.24, 1)) forwards;
    }
    .ndl-media-vol-btn svg { width: 16px; height: 16px; }
    .ndl-media-vol-btn [part^="m-"] {
      display: inline-flex;
      align-items: center;
      justify-content: center;
    }

    /* Transport pill - 3 circular buttons in a faintly distinct cluster */
    .ndl-media-transport-pill {
      display: flex;
      align-items: center;
      gap: 4px;
      padding: 3px;
      border-radius: 999px;
      background: color-mix(in srgb, var(--hrv-color-text, #1a1a2e) 4%, transparent);
      border: 1px solid color-mix(in srgb, var(--hrv-color-text, #1a1a2e) 5%, transparent);
    }
    .ndl-media-tp-btn {
      align-items: center;
      appearance: none;
      background: transparent;
      border: 0;
      border-radius: 999px;
      color: var(--ndl-fg, var(--hrv-color-text, #1a1a2e));
      cursor: pointer;
      display: inline-flex;
      height: 40px;
      width: 40px;
      justify-content: center;
      line-height: 0;
      padding: 0;
      transition: background 200ms ease, transform 180ms cubic-bezier(0.22, 0.84, 0.26, 1);
    }
    .ndl-media-tp-btn:hover {
      background: color-mix(in srgb, var(--hrv-color-text, #1a1a2e) 6%, transparent);
    }
    .ndl-media-tp-btn.is-pressing {
      animation: ndl-btn-bounce var(--hrv-motion-bounce, 0.35s cubic-bezier(0.2, 0.9, 0.24, 1)) forwards;
    }
    .ndl-media-tp-primary {
      background: color-mix(in srgb, var(--hrv-color-text, #1a1a2e) 22%, transparent);
    }
    .ndl-media-tp-primary:hover {
      background: color-mix(in srgb, var(--hrv-color-text, #1a1a2e) 30%, transparent);
    }
    .ndl-media-tp-btn svg { width: 20px; height: 20px; }
    .ndl-media-tp-btn [part^="m-"] {
      display: inline-flex;
      align-items: center;
      justify-content: center;
    }

    /* Footer row: source chip + time chip */
    .ndl-media-footer {
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 8px;
      flex-wrap: wrap;
    }
    .ndl-media-footer .ndl-chip {
      font-size: 12px;
      font-weight: 700;
      height: 28px;
      padding: 0 14px;
      background: color-mix(in srgb, var(--hrv-color-text, #1a1a2e) 4%, transparent);
      border: 1px solid color-mix(in srgb, var(--hrv-color-text, #1a1a2e) 6%, transparent);
      max-width: 200px;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }

    /* Bottom-edge progress bar. Absolutely positioned relative to [part=card]'s
       padding-box, so bottom:0 + left/right:0 puts it flush at the inside of
       the bottom border. The card's overflow:hidden + 28px radius clip the
       corners cleanly. */
    .ndl-media-progress-track {
      position: absolute;
      left: 0;
      right: 0;
      bottom: 0;
      height: 8px;
      background: color-mix(in srgb, var(--hrv-color-text, #1a1a2e) 8%, transparent);
      pointer-events: none;
      z-index: 2;
    }
    .ndl-media-progress-fill {
      height: 100%;
      width: 0%;
      background: var(--hrv-color-primary, #3b82f6);
      transition: width 1s linear;
    }
    .ndl-media-progress-track[data-show="false"] { display: none; }

    /* Read-only label */
    .ndl-media-ro-label {
      font-size: 13px;
      font-weight: 600;
      color: var(--ndl-fg, var(--hrv-color-text, #1a1a2e));
      opacity: 0.6;
      text-align: center;
      padding: 8px 0;
    }
    .ndl-media-chip-device:empty,
    .ndl-media-chip-source:empty,
    .ndl-media-chip-time:empty,
    .ndl-media-ro-label:empty { display: none; }

    /* When playing-related controls are inactive (off/unavailable), collapse
       the body but leave the artwork tile visible. We use a data attribute
       on card-body rather than a separate shell so the bottom progress bar
       still positions correctly. */
    [part=card-body].ndl-media-body[data-collapsed="true"] .ndl-media-transport-row,
    [part=card-body].ndl-media-body[data-collapsed="true"] .ndl-media-footer {
      display: none;
    }

    /* Compact / mini */
    [part=card].ndl-compact .ndl-media-art-btn { width: 60px; height: 60px; border-radius: 16px; }
    [part=card].ndl-compact .ndl-media-hero { grid-template-columns: 60px minmax(0, 1fr) auto; }
    [part=card].ndl-compact .ndl-media-title { font-size: 13px; }
    [part=card].ndl-compact .ndl-media-tp-btn { height: 36px; width: 36px; }
    [part=card].ndl-compact .ndl-media-vol-btn { height: 28px; width: 28px; }
    [part=card].ndl-mini .ndl-media-transport-row,
    [part=card].ndl-mini .ndl-media-tv-controls,
    [part=card].ndl-mini .ndl-media-footer { display: none; }

    /* ---------- TV / Apple TV mode ---------- */
    /* Distinct blue gradient identity to signal "this is a TV/AVR/STB"
       at a glance. No album art ever shown - the icon stays as the device
       glyph. Source text moves into the info column (replacing artist).
       Three-button transport row: power | play/pause | volume(mute toggle). */
    [part=card].ndl-media-tv,
    [part=card].ndl-media-tv[data-state="on"],
    [part=card].ndl-media-tv[data-state="off"] {
      background: linear-gradient(135deg, #4d8ef5 0%, #7aa9f5 45%, #b8d4f5 100%);
      border-color: color-mix(in srgb, #4d8ef5 30%, var(--hrv-color-border, rgba(0,0,0,0.08)));
    }
    [part=card].ndl-media-tv::before {
      background: linear-gradient(180deg,
                  rgba(255,255,255,0.18),
                  rgba(255,255,255,0));
    }
    /* Hide the audio-mode artist line; show the TV source line. */
    [part=card].ndl-media-tv .ndl-media-artist { display: none; }
    [part=card]:not(.ndl-media-tv) .ndl-media-tv-source { display: none; }

    .ndl-media-tv-source {
      font-size: 12px;
      line-height: 1.3;
      color: var(--ndl-fg, var(--hrv-color-text, #1a1a2e));
      opacity: 0.7;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }
    .ndl-media-tv-source:empty { display: none; }

    /* TV mode: device icon in a smaller, more rounded square tile (not the
       big artwork tile we use for audio). Daniel's design treats the TV icon
       as just an icon, not an album-art placeholder. */
    [part=card].ndl-media-tv .ndl-media-hero {
      grid-template-columns: 64px minmax(0, 1fr) auto;
    }
    [part=card].ndl-media-tv .ndl-media-art-btn {
      width: 64px;
      height: 64px;
      border-radius: 18px;
      background: rgba(255, 255, 255, 0.32);
      border-color: rgba(255, 255, 255, 0.42);
    }
    [part=card].ndl-media-tv .ndl-media-art-btn:hover {
      background: rgba(255, 255, 255, 0.42);
    }
    [part=card].ndl-media-tv .ndl-media-art-icon svg {
      width: 28px;
      height: 28px;
    }

    /* TV mode: hide audio transport, source chip in footer, album-bg */
    [part=card].ndl-media-tv .ndl-media-transport-row,
    [part=card].ndl-media-tv .ndl-media-chip-source,
    [part=card].ndl-media-tv .ndl-media-album-bg { display: none; }
    /* Audio mode: hide TV-specific elements */
    [part=card]:not(.ndl-media-tv) .ndl-media-tv-controls { display: none; }

    /* TV controls row: 3 buttons spaced in a row, no pill cluster. */
    .ndl-media-tv-controls {
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 14px;
    }
    .ndl-media-tv-btn {
      align-items: center;
      appearance: none;
      background: rgba(255, 255, 255, 0.35);
      border: 1px solid rgba(255, 255, 255, 0.40);
      border-radius: 999px;
      box-shadow: inset 0 1px 0 rgba(255, 255, 255, 0.45),
                  0 2px 6px rgba(0, 0, 0, 0.06);
      color: var(--hrv-color-text, #1a1a2e);
      cursor: pointer;
      display: inline-flex;
      height: 40px;
      width: 40px;
      justify-content: center;
      line-height: 0;
      padding: 0;
      transition: transform 180ms cubic-bezier(0.22, 0.84, 0.26, 1),
                  background 200ms ease;
    }
    .ndl-media-tv-btn:hover { transform: translateY(-1px); }
    .ndl-media-tv-btn.is-pressing {
      animation: ndl-btn-bounce var(--hrv-motion-bounce, 0.35s cubic-bezier(0.2, 0.9, 0.24, 1)) forwards;
    }
    .ndl-media-tv-btn--primary {
      height: 46px;
      width: 46px;
      background: rgba(0, 0, 0, 0.18);
      border-color: rgba(0, 0, 0, 0.05);
      color: rgba(0, 0, 0, 0.82);
    }
    .ndl-media-tv-btn--primary:hover {
      background: rgba(0, 0, 0, 0.25);
    }
    .ndl-media-tv-btn svg { width: 18px; height: 18px; }
    .ndl-media-tv-btn--primary svg { width: 22px; height: 22px; }
    .ndl-media-tv-btn [part^="m-"] {
      display: inline-flex;
      align-items: center;
      justify-content: center;
    }

    /* TV mode footer chip on the blue background */
    [part=card].ndl-media-tv .ndl-media-footer .ndl-chip {
      background: rgba(255, 255, 255, 0.40);
      border: 1px solid rgba(255, 255, 255, 0.50);
      color: var(--hrv-color-text, #1a1a2e);
    }

    /* Compact override for TV controls */
    [part=card].ndl-media-tv.ndl-compact .ndl-media-tv-btn { height: 36px; width: 36px; }
    [part=card].ndl-media-tv.ndl-compact .ndl-media-tv-btn--primary { height: 42px; width: 42px; }
  `;

  class MediaPlayerCard extends BaseCard {
    #card = null;
    #body = null;
    #albumBgEl = null;
    #artBtn = null;
    #artImg = null;
    #titleEl = null;
    #artistEl = null;
    #deviceChipEl = null;
    #sourceChipEl = null;
    #timeChipEl = null;
    #roLabel = null;
    #playBtn = null;
    #progressTrack = null;
    #progressFill = null;

    #isPlaying = false;
    #isMuted = false;
    #isTvMode = false;
    #lastAttrs = {};
    #lastState = "";
    #lastDuration = 0;
    #lastPos = 0;
    #progressTimer = null;
    #wasOn = null;
    #layoutTeardown = null;
    #tvSourceEl = null;
    #powerBtn = null;
    #volMuteBtn = null;

    constructor(def, root, config, i18n) {
      super(def, root, config, i18n);
    }

    render() {
      const isWritable = this.def.capabilities === "read-write";
      const features = this.def.supported_features ?? [];
      const hints = this.config.displayHints ?? {};
      const showTransport = hints.show_transport !== false;
      const hasPlay = features.includes("play_pause") || features.includes("play");
      const hasPrevious = features.includes("previous_track");
      const hasNext = features.includes("next_track");
      const hasTurnOnOff = features.includes("turn_on") || features.includes("turn_off");
      const hasVolumeStep = hints.show_volume !== false && features.includes("volume_step");
      const hasMute = hints.show_volume !== false && features.includes("volume_mute");
      const showControls = isWritable && showTransport && (hasPlay || hasPrevious || hasNext);
      const showVolumeStep = isWritable && hasVolumeStep;

      // TV mode: vibrant blue identity, 3-button controls (power | play | mute),
      // source text in info column instead of footer chip. Triggered by the
      // entity's device_class (tv / receiver / set_top_box) or an explicit
      // display_hints.tv_mode override.
      // NOTE: TV mode review is incomplete. Initial pass shipped 2026-05-08
      // but the user's Apple TV was offline so the layout has only been spot-
      // checked. Revisit when a TV-class entity is reachable: verify volume
      // mute toggle behaviour, Apple-TV icon detection, source text overflow,
      // and consider porting Daniel's slide-down volume-slider panel.
      const tvDeviceClasses = ["tv", "receiver", "set_top_box"];
      const isTvMode = hints.tv_mode === true
        || (hints.tv_mode !== false && tvDeviceClasses.includes(this.def.device_class));
      this.#isTvMode = isTvMode;

      this.root.innerHTML = /* html */`
        <style>${MEDIA_STYLES}${COMPANION_DOT_STYLES}${NDL_ROW_CSS}</style>
        <div part="card" class="ndl-media-card${isTvMode ? " ndl-media-tv" : ""}">
          <div class="ndl-media-album-bg" data-has-art="false" aria-hidden="true"></div>
          ${isWritable ? /* html */`
            <div part="card-body" class="ndl-media-body">
              <div class="ndl-media-hero">
                <button class="ndl-media-art-btn" type="button" data-has-art="false" aria-label="${isTvMode ? "Power" : "Play/Pause"}">
                  <img class="ndl-media-art-img" alt="">
                  <span class="ndl-media-art-icon" part="card-icon" aria-hidden="true"></span>
                </button>
                <div class="ndl-media-info">
                  <div class="ndl-media-title"></div>
                  <div class="ndl-media-artist"></div>
                  <div class="ndl-media-tv-source"></div>
                </div>
                <div class="ndl-media-chips">
                  <span class="ndl-chip ndl-media-chip-device"></span>
                </div>
              </div>

              ${(showControls || showVolumeStep) ? /* html */`
                <div class="ndl-media-transport-row">
                  ${showVolumeStep ? /* html */`
                    <button class="ndl-media-vol-btn ndl-media-vol-down" type="button" aria-label="Volume down" title="Volume down">
                      <span part="m-vol-down" aria-hidden="true"></span>
                    </button>
                  ` : ""}
                  ${showControls ? /* html */`
                    <div class="ndl-media-transport-pill">
                      ${hasPrevious ? /* html */`<button class="ndl-media-tp-btn ndl-media-prev" type="button" aria-label="Previous" title="Previous"><span part="m-prev" aria-hidden="true"></span></button>` : ""}
                      ${hasPlay ? /* html */`<button class="ndl-media-tp-btn ndl-media-tp-primary ndl-media-play" type="button" aria-label="Play/Pause" title="Play/Pause"><span part="m-play" aria-hidden="true"></span></button>` : ""}
                      ${hasNext ? /* html */`<button class="ndl-media-tp-btn ndl-media-next" type="button" aria-label="Next" title="Next"><span part="m-next" aria-hidden="true"></span></button>` : ""}
                    </div>
                  ` : ""}
                  ${showVolumeStep ? /* html */`
                    <button class="ndl-media-vol-btn ndl-media-vol-up" type="button" aria-label="Volume up" title="Volume up">
                      <span part="m-vol-up" aria-hidden="true"></span>
                    </button>
                  ` : ""}
                </div>
              ` : ""}

              ${isTvMode ? /* html */`
                <div class="ndl-media-tv-controls">
                  ${hasTurnOnOff ? /* html */`
                    <button class="ndl-media-tv-btn ndl-media-tv-power" type="button" aria-label="Power" title="Power">
                      <span part="m-power" aria-hidden="true"></span>
                    </button>
                  ` : ""}
                  ${hasPlay ? /* html */`
                    <button class="ndl-media-tv-btn ndl-media-tv-btn--primary ndl-media-play" type="button" aria-label="Play/Pause" title="Play/Pause">
                      <span part="m-play" aria-hidden="true"></span>
                    </button>
                  ` : ""}
                  ${hasMute ? /* html */`
                    <button class="ndl-media-tv-btn ndl-media-tv-mute" type="button" aria-label="Mute" title="Mute">
                      <span part="m-vol" aria-hidden="true"></span>
                    </button>
                  ` : ""}
                </div>
              ` : ""}

              <div class="ndl-media-footer">
                <span class="ndl-chip ndl-media-chip-source"></span>
                <span class="ndl-chip ndl-media-chip-time"></span>
              </div>
            </div>
          ` : /* html */`
            <div part="card-body" class="ndl-media-body">
              <div class="ndl-media-ro-label"></div>
            </div>
          `}
          <div class="ndl-media-progress-track" data-show="false">
            <div class="ndl-media-progress-fill"></div>
          </div>
          ${this.renderAriaLiveHTML()}
          ${this.renderCompanionZoneHTML()}
          <div part="stale-indicator" aria-hidden="true"></div>
        </div>
      `;

      // Cache refs
      this.#card = this.root.querySelector("[part=card]");
      this.#body = this.root.querySelector(".ndl-media-body");
      this.#albumBgEl = this.root.querySelector(".ndl-media-album-bg");
      this.#artBtn = this.root.querySelector(".ndl-media-art-btn");
      this.#artImg = this.root.querySelector(".ndl-media-art-img");
      this.#titleEl = this.root.querySelector(".ndl-media-title");
      this.#artistEl = this.root.querySelector(".ndl-media-artist");
      this.#deviceChipEl = this.root.querySelector(".ndl-media-chip-device");
      this.#sourceChipEl = this.root.querySelector(".ndl-media-chip-source");
      this.#timeChipEl = this.root.querySelector(".ndl-media-chip-time");
      this.#roLabel = this.root.querySelector(".ndl-media-ro-label");
      this.#playBtn = this.root.querySelector(".ndl-media-play");
      this.#progressTrack = this.root.querySelector(".ndl-media-progress-track");
      this.#progressFill = this.root.querySelector(".ndl-media-progress-fill");
      this.#tvSourceEl = this.root.querySelector(".ndl-media-tv-source");
      this.#powerBtn = this.root.querySelector(".ndl-media-tv-power");
      this.#volMuteBtn = this.root.querySelector(".ndl-media-tv-mute");

      // Icons. The artwork tile's fallback icon depends on mode and brand:
      // Apple TV uses mdi:apple, other TVs use mdi:television, audio uses
      // mdi:cast. Apple-TV detection from the entity id / friendly_name.
      const haystack = `${this.def.entity_id ?? ""} ${this.def.friendly_name ?? ""}`.toLowerCase();
      const isAppleTv = isTvMode && (haystack.includes("apple tv") || haystack.includes("apple_tv"));
      const iconFallback = isAppleTv
        ? this.resolveIcon("mdi:apple", "mdi:cast")
        : isTvMode
          ? this.resolveIcon("mdi:television", "mdi:cast")
          : "mdi:cast";
      this.renderIcon(this.resolveIcon(this.def.icon, iconFallback), "card-icon");
      if (hasPrevious) {
        this.renderIcon("mdi:skip-previous", "m-prev");
      }
      if (hasNext) {
        this.renderIcon("mdi:skip-next", "m-next");
      }
      if (hasPlay) this.renderIcon("mdi:play", "m-play");
      if (showVolumeStep && !isTvMode) {
        // Speaker-with-minus / speaker-with-plus glyphs read as "volume" more
        // clearly than bare plus/minus.
        this.renderIcon("mdi:volume-minus", "m-vol-down");
        this.renderIcon("mdi:volume-plus", "m-vol-up");
      }
      if (isTvMode) {
        if (hasTurnOnOff) this.renderIcon("mdi:power", "m-power");
        if (hasMute) this.renderIcon("mdi:volume-high", "m-vol");
      }

      // Tap on artwork. Audio: play/pause. TV: power toggle (when supported)
      // since TV mode treats power as the primary action. Both can be
      // overridden via gestureConfig.tap.
      if (this.#artBtn && isWritable) {
        this._attachGestureHandlers(this.#artBtn, {
          onTap: () => {
            _triggerBounce(this.#artBtn);
            const tap = this.config.gestureConfig?.tap;
            if (tap) { this._runAction(tap); return; }
            if (isTvMode && hasTurnOnOff) {
              this.#sendPowerToggle();
            } else if (hasPlay) {
              this.config.card?.sendCommand("media_play_pause", {});
            }
          },
        });
      }

      // Transport buttons
      if (this.#playBtn) {
        this.#playBtn.addEventListener("click", () => {
          _triggerBounce(this.#playBtn);
          this.config.card?.sendCommand("media_play_pause", {});
        });
      }

      // TV mode power button - toggles turn_on / turn_off
      if (this.#powerBtn) {
        this.#powerBtn.addEventListener("click", () => {
          _triggerBounce(this.#powerBtn);
          this.#sendPowerToggle();
        });
      }

      // TV mode volume button - mute toggle (single-tap action). For more
      // granular volume control, the user can use HA's native UI; we may add
      // a slide-down volume panel later (matching Daniel's behaviour).
      if (this.#volMuteBtn) {
        this.#volMuteBtn.addEventListener("click", () => {
          _triggerBounce(this.#volMuteBtn);
          this.config.card?.sendCommand("volume_mute", { is_volume_muted: !this.#isMuted });
        });
      }
      const prevBtn = this.root.querySelector(".ndl-media-prev");
      const nextBtn = this.root.querySelector(".ndl-media-next");
      if (prevBtn) {
        prevBtn.addEventListener("click", () => {
          _triggerBounce(prevBtn);
          this.config.card?.sendCommand("media_previous_track", {});
        });
      }
      if (nextBtn) {
        nextBtn.addEventListener("click", () => {
          _triggerBounce(nextBtn);
          this.config.card?.sendCommand("media_next_track", {});
        });
      }

      // Volume +/- buttons. HA's volume_up / volume_down services step the
      // volume by the entity's configured step, regardless of whether the
      // entity supports volume_set or only volume_step.
      const volDownBtn = this.root.querySelector(".ndl-media-vol-down");
      const volUpBtn = this.root.querySelector(".ndl-media-vol-up");
      if (volDownBtn) {
        volDownBtn.addEventListener("click", () => {
          _triggerBounce(volDownBtn);
          this.config.card?.sendCommand("volume_down", {});
        });
      }
      if (volUpBtn) {
        volUpBtn.addEventListener("click", () => {
          _triggerBounce(volUpBtn);
          this.config.card?.sendCommand("volume_up", {});
        });
      }

      this.renderCompanions();
      _applyCompanionTooltips(this.root);
      this._attachGestureHandlers(this.#card);
      this.#layoutTeardown = _layoutObserver(this);
    }

    applyState(state, attributes) {
      this.#lastState = state;
      this.#isPlaying = state === "playing";
      this.#lastAttrs = attributes;
      this.#isMuted = attributes.is_volume_muted ?? false;

      // Active = anything other than off/unavailable/unknown.
      const active = state !== "off" && state !== "unavailable" && state !== "unknown";

      if (this.#card) this.#card.dataset.state = active ? "on" : "off";

      if (this.#wasOn !== null && this.#wasOn !== active && this.#card) {
        this.#card.classList.remove("ndl-powering-up", "ndl-powering-down");
        void this.#card.getBoundingClientRect();
        this.#card.classList.add(active ? "ndl-powering-up" : "ndl-powering-down");
      }
      this.#wasOn = active;

      // Collapse transport+footer when off (artwork stays visible)
      if (this.#body) this.#body.dataset.collapsed = String(!active);

      // Album artwork - replaces the card-icon when available
      const rawPic = attributes.entity_picture;
      const pic = rawPic
        ? (rawPic.startsWith("http") ? rawPic : (this.config.haUrl || "") + rawPic)
        : null;
      if (this.#artImg) this.#artImg.src = pic || "";
      if (this.#artBtn) this.#artBtn.dataset.hasArt = String(!!pic);
      if (this.#albumBgEl) {
        this.#albumBgEl.dataset.hasArt = String(!!pic);
        if (pic) {
          this.#albumBgEl.style.setProperty("--ndl-media-art-url", `url("${pic.replace(/"/g, '\\"')}")`);
        } else {
          this.#albumBgEl.style.removeProperty("--ndl-media-art-url");
        }
      }

      // Title / artist
      const title = attributes.media_title || attributes.app_name || "";
      if (this.#titleEl) this.#titleEl.textContent = title;
      if (this.#artistEl) this.#artistEl.textContent = attributes.media_artist || "";

      // Header chip = entity friendly_name (Daniel calls this the "device chip")
      if (this.#deviceChipEl) this.#deviceChipEl.textContent = this.def.friendly_name || "";

      // Source: shown as text in the info column for TV mode, as a footer
      // chip otherwise. Falls back to app_name (covers Cast/Spotify Connect
      // cases like "YouTube Music" where there's no separate `source` attr).
      const sourceText = attributes.source || attributes.app_name || "";
      if (this.#isTvMode) {
        if (this.#tvSourceEl) this.#tvSourceEl.textContent = active ? sourceText : "";
        if (this.#sourceChipEl) this.#sourceChipEl.textContent = "";
      } else {
        if (this.#sourceChipEl) this.#sourceChipEl.textContent = active ? sourceText : "";
        if (this.#tvSourceEl) this.#tvSourceEl.textContent = "";
      }

      // Time chip + bottom progress bar driven from media_duration / media_position
      this.#updateProgressAndTime(attributes);

      // Play/pause icon swap; TV mode mute icon swap
      this.renderIcon(this.#isPlaying ? "mdi:pause" : "mdi:play", "m-play");
      if (this.#isTvMode && this.#volMuteBtn) {
        this.renderIcon(this.#isMuted ? "mdi:volume-off" : "mdi:volume-high", "m-vol");
      }

      // Read-only label
      if (this.#roLabel) {
        this.#roLabel.textContent = title || _capitalize(state);
      }

      this.announceState(`${this.def.friendly_name}, ${state}${title ? `, ${title}` : ""}`);
    }

    predictState(action, data) {
      if (action === "media_play_pause") {
        return { state: this.#isPlaying ? "paused" : "playing", attributes: this.#lastAttrs };
      }
      if (action === "turn_on") {
        return { state: "idle", attributes: this.#lastAttrs };
      }
      if (action === "turn_off") {
        return { state: "off", attributes: this.#lastAttrs };
      }
      if (action === "volume_mute") {
        return { state: this.#lastState, attributes: { ...this.#lastAttrs, is_volume_muted: !!data.is_volume_muted } };
      }
      return null;
    }

    destroy() {
      if (this.#progressTimer) { clearInterval(this.#progressTimer); this.#progressTimer = null; }
      if (this.#layoutTeardown) { this.#layoutTeardown(); this.#layoutTeardown = null; }
    }

    #sendPowerToggle() {
      const isOff = this.#lastState === "off" || this.#lastState === "unavailable" || this.#lastState === "unknown";
      const action = isOff ? "turn_on" : "turn_off";
      if (this.def.supported_features?.includes(action)) {
        this.config.card?.sendCommand(action, {});
      }
    }

    #updateProgressAndTime(attrs) {
      if (this.#progressTimer) { clearInterval(this.#progressTimer); this.#progressTimer = null; }

      const duration = attrs.media_duration;
      const position = attrs.media_position;
      const updated = attrs.media_position_updated_at;

      if (duration == null || position == null) {
        if (this.#progressTrack) this.#progressTrack.dataset.show = "false";
        if (this.#timeChipEl) this.#timeChipEl.textContent = "";
        return;
      }

      if (this.#progressTrack) this.#progressTrack.dataset.show = "true";

      // Account for time elapsed since the entity's last position update
      const elapsed = updated
        ? (Date.now() / 1000 - new Date(updated).getTime() / 1000)
        : 0;
      let pos = position + (this.#isPlaying ? elapsed : 0);
      this.#lastDuration = duration;

      const update = () => {
        pos = Math.min(pos, duration);
        this.#lastPos = pos;
        const frac = duration > 0 ? (pos / duration) * 100 : 0;
        if (this.#progressFill) this.#progressFill.style.width = `${frac}%`;
        if (this.#timeChipEl) {
          this.#timeChipEl.textContent = `${this.#fmtTime(Math.floor(pos))} / ${this.#fmtTime(Math.floor(duration))}`;
        }
      };
      update();

      if (this.#isPlaying) {
        this.#progressTimer = setInterval(() => { pos += 1; update(); }, 1000);
      }
    }

    #fmtTime(sec) {
      const m = Math.floor(sec / 60);
      const s = Math.floor(sec % 60);
      return `${m}:${s < 10 ? "0" : ""}${s}`;
    }
  }

  // ---------------------------------------------------------------------------
  // InputNumberCard
  // ---------------------------------------------------------------------------

  const INPNUM_STYLES = /* css */`
    ${NODALIA_BASE}

    /* Input-number icon: accent-tinted background, dark glyph for clear
       contrast against light surfaces (matches Daniel's pattern - tinted bg
       with text-coloured icon, not same-hue-on-same-hue). */
    [part=card][data-state="on"] [part=card-icon].ndl-inpnum-icon {
      background: color-mix(in srgb,
                  var(--ndl-accent, var(--hrv-color-accent, #66d9e8)) 38%,
                  color-mix(in srgb, var(--hrv-color-text, #1a1a2e) 8%, transparent));
    }
    [part=card][data-state="on"] [part=card-icon].ndl-inpnum-icon svg {
      color: var(--ndl-fg, var(--hrv-color-text, #1a1a2e));
      opacity: 1;
    }

    .ndl-inpnum-chip {
      font-size: 12px;
      font-weight: 700;
      height: 24px;
      padding: 0 12px;
    }
    .ndl-inpnum-chip:empty { display: none; }

    [part=card-body] {
      display: flex;
      flex-direction: column;
      gap: 12px;
      margin-top: 12px;
    }

    /* Slider mode - same pill recipe as fan/cover */
    .ndl-inpnum-slider-wrap {
      align-items: center;
      background: color-mix(in srgb, var(--hrv-color-text, #1a1a2e) 4%, transparent);
      border: 1px solid color-mix(in srgb, var(--hrv-color-text, #1a1a2e) 6%, transparent);
      border-radius: 999px;
      box-shadow: inset 0 1px 0 color-mix(in srgb, var(--hrv-color-text, #1a1a2e) 4%, transparent);
      display: flex;
      min-height: 44px;
      padding: 0 14px;
    }
    .ndl-inpnum-slider-shell {
      flex: 1;
      min-width: 0;
      position: relative;
    }
    .ndl-inpnum-slider-track {
      position: absolute;
      top: 50%;
      left: 0;
      right: 0;
      height: 18px;
      transform: translateY(-50%);
      border-radius: 999px;
      background: color-mix(in srgb, var(--hrv-color-text, #1a1a2e) 14%, transparent);
      overflow: hidden;
      pointer-events: none;
    }
    .ndl-inpnum-slider-track::before {
      content: "";
      position: absolute;
      inset: 0;
      border-radius: inherit;
      background: var(--ndl-accent, var(--hrv-color-accent, #66d9e8));
      transform: scaleX(calc(var(--ndl-inpnum-progress, 0) / 100));
      transform-origin: left center;
      transition: transform 0.15s ease;
    }
    .ndl-inpnum-slider {
      -webkit-appearance: none;
      appearance: none;
      background: transparent;
      border: 0;
      width: 100%;
      height: 44px;
      margin: 0;
      cursor: pointer;
      outline: none;
      position: relative;
      z-index: 2;
    }
    .ndl-inpnum-slider::-webkit-slider-thumb {
      -webkit-appearance: none;
      width: 28px; height: 28px;
      background: transparent;
      cursor: grab;
    }
    .ndl-inpnum-slider::-webkit-slider-thumb:active { cursor: grabbing; }
    .ndl-inpnum-slider::-moz-range-thumb {
      width: 28px; height: 28px;
      background: transparent;
      border: 0;
      cursor: grab;
    }

    /* Buttons mode: [-] [VALUE BIG] [+] */
    .ndl-inpnum-buttons-row {
      display: grid;
      grid-template-columns: auto minmax(0, 1fr) auto;
      gap: 12px;
      align-items: center;
    }
    .ndl-inpnum-step-btn {
      align-items: center;
      appearance: none;
      -webkit-backdrop-filter: blur(18px);
      backdrop-filter: blur(18px);
      background: color-mix(in srgb, var(--hrv-color-text, #1a1a2e) 5%, transparent);
      border: 1px solid color-mix(in srgb, var(--hrv-color-text, #1a1a2e) 6%, transparent);
      border-radius: 999px;
      box-shadow: inset 0 1px 0 color-mix(in srgb, var(--hrv-color-text, #1a1a2e) 6%, transparent);
      color: var(--ndl-fg, var(--hrv-color-text, #1a1a2e));
      cursor: pointer;
      display: inline-flex;
      height: 44px;
      width: 44px;
      justify-content: center;
      line-height: 0;
      padding: 0;
      transition: transform 180ms cubic-bezier(0.22, 0.84, 0.26, 1),
                  background 200ms ease;
    }
    .ndl-inpnum-step-btn:hover { transform: translateY(-1px); }
    .ndl-inpnum-step-btn.is-pressing {
      animation: ndl-btn-bounce var(--hrv-motion-bounce, 0.35s cubic-bezier(0.2, 0.9, 0.24, 1)) forwards;
    }
    .ndl-inpnum-step-btn:disabled {
      opacity: 0.4;
      cursor: default;
    }
    .ndl-inpnum-step-btn svg { width: 22px; height: 22px; }
    .ndl-inpnum-step-btn [part^="num-"] {
      display: inline-flex;
      align-items: center;
      justify-content: center;
    }
    .ndl-inpnum-value-display {
      display: flex;
      align-items: baseline;
      justify-content: center;
      gap: 4px;
      font-variant-numeric: tabular-nums;
      color: var(--ndl-fg, var(--hrv-color-text, #1a1a2e));
    }
    .ndl-inpnum-value {
      font-size: 32px;
      font-weight: 700;
      line-height: 1;
    }
    .ndl-inpnum-unit {
      font-size: 14px;
      font-weight: 500;
      opacity: 0.7;
    }
    .ndl-inpnum-unit:empty { display: none; }

    /* Read-only label */
    .ndl-inpnum-ro-label {
      font-size: 13px;
      font-weight: 600;
      color: var(--ndl-fg, var(--hrv-color-text, #1a1a2e));
      opacity: 0.6;
      text-align: center;
      padding: 8px 0;
    }
    .ndl-inpnum-ro-label:empty { display: none; }

    /* Compact / mini */
    [part=card].ndl-compact .ndl-inpnum-step-btn { height: 38px; width: 38px; }
    [part=card].ndl-compact .ndl-inpnum-value { font-size: 26px; }
    [part=card].ndl-compact .ndl-inpnum-slider-wrap { min-height: 40px; padding: 0 12px; }
  `;

  class InputNumberCard extends BaseCard {
    #card = null;
    #chipEl = null;
    #valueEl = null;
    #unitEl = null;
    #roLabel = null;
    #slider = null;
    #shellEl = null;
    #minusBtn = null;
    #plusBtn = null;

    #value = 0;
    #min = 0;
    #max = 100;
    #step = 1;
    #unit = "";
    #lastState = "";
    #displayMode = "slider";
    #sendValue;
    #layoutTeardown = null;

    constructor(def, root, config, i18n) {
      super(def, root, config, i18n);
      this.#sendValue = _debounce(this.#doSendValue.bind(this), 300);
    }

    render() {
      const isWritable = this.def.capabilities === "read-write";
      const hint = this.config.displayHints?.display_mode ?? "slider";
      this.#displayMode = (hint === "buttons") ? "buttons" : "slider";
      this.#min = this.def.feature_config?.min ?? 0;
      this.#max = this.def.feature_config?.max ?? 100;
      this.#step = this.def.feature_config?.step ?? 1;
      this.#unit = this.def.unit_of_measurement ?? "";

      const showSlider = isWritable && this.#displayMode === "slider";
      const showButtons = isWritable && this.#displayMode === "buttons";

      this.root.innerHTML = /* html */`
        <style>${INPNUM_STYLES}${COMPANION_DOT_STYLES}${NDL_ROW_CSS}</style>
        <div part="card" class="ndl-inpnum-card">
          <div part="card-header">
            <span part="card-icon" class="ndl-inpnum-icon" aria-hidden="true"></span>
            <span part="card-name">${_esc(this.def.friendly_name)}</span>
            ${this.#displayMode === "slider" ? `<span class="ndl-chip ndl-inpnum-chip"></span>` : ""}
          </div>
          ${(showSlider || showButtons) ? /* html */`
            <div part="card-body">
              ${showSlider ? /* html */`
                <div class="ndl-inpnum-slider-wrap">
                  <div class="ndl-inpnum-slider-shell">
                    <div class="ndl-inpnum-slider-track"></div>
                    <input type="range" class="ndl-inpnum-slider"
                      min="${this.#min}" max="${this.#max}" step="${this.#step}" value="${this.#min}"
                      aria-label="${_esc(this.def.friendly_name)}">
                  </div>
                </div>
              ` : /* html */`
                <div class="ndl-inpnum-buttons-row">
                  <button class="ndl-inpnum-step-btn ndl-inpnum-minus" type="button" aria-label="Decrease" title="Decrease">
                    <span part="num-minus" aria-hidden="true"></span>
                  </button>
                  <div class="ndl-inpnum-value-display">
                    <span class="ndl-inpnum-value"></span>
                    <span class="ndl-inpnum-unit">${_esc(this.#unit)}</span>
                  </div>
                  <button class="ndl-inpnum-step-btn ndl-inpnum-plus" type="button" aria-label="Increase" title="Increase">
                    <span part="num-plus" aria-hidden="true"></span>
                  </button>
                </div>
              `}
              ${this.renderHistoryZoneHTML()}
            </div>
          ` : !isWritable ? /* html */`
            <div part="card-body">
              <div class="ndl-inpnum-ro-label"></div>
              ${this.renderHistoryZoneHTML()}
            </div>
          ` : ""}
          ${this.renderAriaLiveHTML()}
          ${this.renderCompanionZoneHTML()}
          <div part="stale-indicator" aria-hidden="true"></div>
        </div>
      `;

      this.#card = this.root.querySelector("[part=card]");
      this.#chipEl = this.root.querySelector(".ndl-inpnum-chip");
      this.#valueEl = this.root.querySelector(".ndl-inpnum-value");
      this.#unitEl = this.root.querySelector(".ndl-inpnum-unit");
      this.#roLabel = this.root.querySelector(".ndl-inpnum-ro-label");
      this.#slider = this.root.querySelector(".ndl-inpnum-slider");
      this.#shellEl = this.root.querySelector(".ndl-inpnum-slider-shell");
      this.#minusBtn = this.root.querySelector(".ndl-inpnum-minus");
      this.#plusBtn = this.root.querySelector(".ndl-inpnum-plus");

      this.renderIcon(this.resolveIcon(this.def.icon, "mdi:numeric"), "card-icon");
      if (this.#minusBtn) this.renderIcon("mdi:minus", "num-minus");
      if (this.#plusBtn) this.renderIcon("mdi:plus", "num-plus");

      // Slider drag - Number() not parseInt (lesson #47, fractional steps)
      if (this.#slider) {
        this.#slider.addEventListener("input", () => {
          this.#value = Number(this.#slider.value);
          this.#updateProgressVar();
          this.#updateChip();
          this.#sendValue();
        });
        this.guardSlider(this.#slider, this.#sendValue);
      }

      // +/- buttons
      if (this.#minusBtn) {
        this.#minusBtn.addEventListener("click", () => {
          _triggerBounce(this.#minusBtn);
          const next = _clamp(this.#value - this.#step, this.#min, this.#max);
          if (next === this.#value) return;
          this.#value = next;
          this.#updateValueDisplay();
          this.#sendValue();
        });
      }
      if (this.#plusBtn) {
        this.#plusBtn.addEventListener("click", () => {
          _triggerBounce(this.#plusBtn);
          const next = _clamp(this.#value + this.#step, this.#min, this.#max);
          if (next === this.#value) return;
          this.#value = next;
          this.#updateValueDisplay();
          this.#sendValue();
        });
      }

      this.renderCompanions();
      _applyCompanionTooltips(this.root);
      this._attachGestureHandlers(this.#card);
      this.#layoutTeardown = _layoutObserver(this);
    }

    applyState(state, _attributes) {
      this.#lastState = state;
      const numVal = parseFloat(state);
      const isAvailable = !isNaN(numVal) && state !== "unavailable" && state !== "unknown";

      if (this.#card) this.#card.dataset.state = isAvailable ? "on" : "off";

      // Accent: input_number palette
      const palette = _colorsFor("input_number");
      if (this.#card) {
        if (isAvailable) this.#card.style.setProperty("--ndl-accent", palette.accent);
        else this.#card.style.removeProperty("--ndl-accent");
      }

      if (isAvailable) {
        // Sync value, but guard slider drag
        const sliderActive = this.#slider && this.isSliderActive(this.#slider);
        if (!sliderActive) {
          this.#value = numVal;
          if (this.#slider) this.#slider.value = String(numVal);
        }
        this.#updateProgressVar();
        this.#updateChip();
        this.#updateValueDisplay();
        this.#updateButtonsDisabled();
      } else {
        if (this.#chipEl) this.#chipEl.textContent = "";
        if (this.#valueEl) this.#valueEl.textContent = "—";
      }

      if (this.#roLabel) {
        this.#roLabel.textContent = isAvailable
          ? this.#formatValue(this.#value)
          : _capitalize(state);
      }

      this.announceState(`${this.def.friendly_name}, ${isAvailable ? this.#formatValue(this.#value) : state}`);
    }

    destroy() {
      if (this.#layoutTeardown) { this.#layoutTeardown(); this.#layoutTeardown = null; }
    }

    #updateProgressVar() {
      if (!this.#shellEl) return;
      const span = Math.max(this.#step, this.#max - this.#min);
      const pct = _clamp(((this.#value - this.#min) / span) * 100, 0, 100);
      this.#shellEl.style.setProperty("--ndl-inpnum-progress", String(pct));
    }

    #updateChip() {
      if (!this.#chipEl) return;
      this.#chipEl.textContent = this.#formatValue(this.#value);
    }

    #updateValueDisplay() {
      if (!this.#valueEl) return;
      this.#valueEl.textContent = this.#formatNumber(this.#value);
      if (this.#unitEl) this.#unitEl.textContent = this.#unit;
    }

    #updateButtonsDisabled() {
      if (this.#minusBtn) this.#minusBtn.disabled = this.#value <= this.#min;
      if (this.#plusBtn) this.#plusBtn.disabled = this.#value >= this.#max;
    }

    #formatValue(v) {
      const numStr = this.#formatNumber(v);
      return this.#unit ? `${numStr} ${this.#unit}` : numStr;
    }

    // Format the number with a sensible number of decimals based on the
    // entity's step. step=0.1 -> 1 decimal, step=0.01 -> 2 decimals, etc.
    #formatNumber(v) {
      if (this.#step >= 1 || !Number.isFinite(this.#step)) {
        return String(Math.round(v));
      }
      const decimals = Math.min(4, Math.max(0, -Math.floor(Math.log10(this.#step))));
      return v.toFixed(decimals);
    }

    #doSendValue() {
      // Lesson #46 - send the exact value the user picked (slider snaps to
      // the entity's step, +/- buttons compute step-multiples). Don't round.
      this.config.card?.sendCommand("set_value", { value: this.#value });
    }
  }

  // ---------------------------------------------------------------------------
  // InputSelectCard
  // ---------------------------------------------------------------------------

  const INPSEL_STYLES = /* css */`
    ${NODALIA_BASE}

    /* Input-select icon: accent-tinted background + dark glyph */
    [part=card][data-state="on"] [part=card-icon].ndl-inpsel-icon {
      background: color-mix(in srgb,
                  var(--ndl-accent, var(--hrv-color-accent, #8ce99a)) 38%,
                  color-mix(in srgb, var(--hrv-color-text, #1a1a2e) 8%, transparent));
    }
    [part=card][data-state="on"] [part=card-icon].ndl-inpsel-icon svg {
      color: var(--ndl-fg, var(--hrv-color-text, #1a1a2e));
      opacity: 1;
    }

    .ndl-inpsel-chip {
      font-size: 12px;
      font-weight: 700;
      height: 24px;
      padding: 0 12px;
      max-width: 140px;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }
    .ndl-inpsel-chip:empty { display: none; }

    .ndl-inpsel-grid {
      display: flex;
      flex-wrap: wrap;
      gap: 6px;
      margin-top: 12px;
    }
    .ndl-inpsel-option {
      padding: 6px 14px;
      border: 1px solid color-mix(in srgb, var(--hrv-color-text, #1a1a2e) 8%, transparent);
      border-radius: 999px;
      background: color-mix(in srgb, var(--hrv-color-text, #1a1a2e) 4%, transparent);
      font-size: 12px;
      font-weight: 600;
      color: var(--ndl-fg, var(--hrv-color-text, #1a1a2e));
      cursor: pointer;
      transition: background 0.2s ease, border-color 0.2s ease, transform 180ms cubic-bezier(0.22, 0.84, 0.26, 1);
      user-select: none;
    }
    .ndl-inpsel-option:hover {
      background: color-mix(in srgb, var(--hrv-color-text, #1a1a2e) 8%, transparent);
      transform: translateY(-1px);
    }
    .ndl-inpsel-option.is-pressing {
      animation: ndl-btn-bounce var(--hrv-motion-bounce, 0.35s cubic-bezier(0.2, 0.9, 0.24, 1)) forwards;
    }
    .ndl-inpsel-option[data-selected="true"] {
      background: color-mix(in srgb, var(--ndl-accent, var(--hrv-color-accent, #8ce99a)) 28%, transparent);
      border-color: color-mix(in srgb, var(--ndl-accent, var(--hrv-color-accent, #8ce99a)) 60%, transparent);
    }

    /* Dropdown mode */
    .ndl-inpsel-shell {
      margin-top: 12px;
      position: relative;
    }
    .ndl-inpsel-trigger {
      width: 100%;
      padding: 10px 14px;
      border-radius: 14px;
      background: color-mix(in srgb, var(--hrv-color-text, #1a1a2e) 4%, transparent);
      border: 1px solid color-mix(in srgb, var(--hrv-color-text, #1a1a2e) 8%, transparent);
      color: var(--ndl-fg, var(--hrv-color-text, #1a1a2e));
      font-family: inherit;
      font-size: 13px;
      font-weight: 600;
      text-align: left;
      cursor: pointer;
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 8px;
      transition: background 200ms ease, border-color 200ms ease;
    }
    .ndl-inpsel-trigger:hover {
      background: color-mix(in srgb, var(--hrv-color-text, #1a1a2e) 8%, transparent);
    }
    .ndl-inpsel-trigger:disabled { opacity: 0.5; cursor: not-allowed; }
    [part=card][data-state="on"] .ndl-inpsel-trigger {
      background: color-mix(in srgb, var(--ndl-accent, var(--hrv-color-accent, #8ce99a)) 14%, transparent);
      border-color: color-mix(in srgb, var(--ndl-accent, var(--hrv-color-accent, #8ce99a)) 30%, transparent);
    }
    .ndl-inpsel-trigger-arrow {
      font-size: 10px;
      opacity: 0.6;
      transition: transform 200ms ease;
    }
    .ndl-inpsel-trigger[aria-expanded="true"] .ndl-inpsel-trigger-arrow {
      transform: rotate(180deg);
    }
    .ndl-inpsel-dropdown {
      /* Rendered as a popover in the top layer so it escapes stacking
         contexts and overflow:hidden on every ancestor. */
      position: fixed;
      margin: 0;
      inset: unset;
      background: var(--hrv-card-background, #ffffff);
      border: 1px solid color-mix(in srgb, var(--hrv-color-text, #1a1a2e) 10%, transparent);
      border-radius: 14px;
      box-shadow: 0 8px 24px rgba(0,0,0,0.25);
      max-height: 240px;
      overflow-y: auto;
      scrollbar-width: thin;
      padding: 4px;
      color: var(--ndl-fg, var(--hrv-color-text, #1a1a2e));
      font-family: inherit;
    }
    .ndl-inpsel-dropdown:not(:popover-open) { display: none; }
    .ndl-inpsel-dropdown-option {
      display: block;
      width: 100%;
      padding: 8px 12px;
      border: none;
      background: transparent;
      color: var(--ndl-fg, var(--hrv-color-text, #1a1a2e));
      font-family: inherit;
      font-size: 13px;
      text-align: left;
      cursor: pointer;
      border-radius: 10px;
      transition: background 150ms ease;
    }
    .ndl-inpsel-dropdown-option:hover,
    .ndl-inpsel-dropdown-option:focus-visible {
      background: color-mix(in srgb, var(--hrv-color-text, #1a1a2e) 8%, transparent);
      outline: none;
    }
    .ndl-inpsel-dropdown-option[data-selected="true"] {
      background: color-mix(in srgb, var(--ndl-accent, var(--hrv-color-accent, #8ce99a)) 22%, transparent);
      font-weight: 600;
    }
  `;

  class InputSelectCard extends BaseCard {
    #card = null;
    #chipEl = null;
    #grid = null;
    #optionButtons = [];
    #triggerBtn = null;
    #triggerLabel = null;
    #dropdown = null;
    #dropdownOptions = [];
    #isOpen = false;
    #docClickHandler = null;
    #repositionHandler = null;
    #options = [];
    #lastOptionsKey = "";
    #displayMode = "pills";
    #wasOn = null;
    #layoutTeardown = null;
    #currentState = "";

    render() {
      const isWritable = this.def.capabilities === "read-write";
      this.#options = this.def.feature_config?.options ?? [];
      const hint = this.config.displayHints?.display_mode ?? this.def.display_hints?.display_mode ?? "pills";
      this.#displayMode = (hint === "dropdown") ? "dropdown" : "pills";

      const bodyHTML = !isWritable ? "" :
        this.#displayMode === "dropdown"
          ? /* html */`
            <div part="card-body">
              <div class="ndl-inpsel-shell">
                <button class="ndl-inpsel-trigger" type="button"
                  aria-haspopup="listbox" aria-expanded="false"
                  aria-label="${_esc(this.def.friendly_name)}">
                  <span class="ndl-inpsel-trigger-label">-</span>
                  <span class="ndl-inpsel-trigger-arrow" aria-hidden="true">&#9660;</span>
                </button>
                <div class="ndl-inpsel-dropdown" role="listbox" popover="manual"></div>
              </div>
            </div>`
          : /* html */`<div part="card-body"><div class="ndl-inpsel-grid"></div></div>`;

      this.root.innerHTML = /* html */`
        <style>${INPSEL_STYLES}${COMPANION_DOT_STYLES}${NDL_ROW_CSS}</style>
        <div part="card" class="ndl-inpsel-card">
          <div part="card-header">
            <span part="card-icon" class="ndl-inpsel-icon" aria-hidden="true"></span>
            <span part="card-name">${_esc(this.def.friendly_name)}</span>
            <span class="ndl-chip ndl-inpsel-chip"></span>
          </div>
          ${bodyHTML}
          ${this.renderAriaLiveHTML()}
          ${this.renderCompanionZoneHTML()}
          <div part="stale-indicator" aria-hidden="true"></div>
        </div>
      `;
      this.#card = this.root.querySelector("[part=card]");
      this.#chipEl = this.root.querySelector(".ndl-inpsel-chip");
      this.#grid = this.root.querySelector(".ndl-inpsel-grid");
      this.#triggerBtn = this.root.querySelector(".ndl-inpsel-trigger");
      this.#triggerLabel = this.root.querySelector(".ndl-inpsel-trigger-label");
      this.#dropdown = this.root.querySelector(".ndl-inpsel-dropdown");
      this.#optionButtons = [];
      this.#dropdownOptions = [];
      this.#lastOptionsKey = "";

      this.renderIcon(this.resolveIcon(this.def.icon, "mdi:format-list-bulleted"), "card-icon");

      if (this.#triggerBtn && isWritable) {
        this.#triggerBtn.addEventListener("click", (e) => {
          e.stopPropagation();
          if (this.#isOpen) this.#closeDropdown();
          else this.#openDropdown();
        });
        this.#triggerBtn.addEventListener("keydown", (e) => {
          if ((e.key === "Enter" || e.key === " " || e.key === "ArrowDown") && !this.#isOpen) {
            e.preventDefault();
            this.#openDropdown();
            const first = this.#dropdown?.querySelector(".ndl-inpsel-dropdown-option");
            first?.focus();
          } else if (e.key === "Escape" && this.#isOpen) {
            this.#closeDropdown();
            this.#triggerBtn.focus();
          }
        });
        this.#docClickHandler = (e) => {
          if (this.#isOpen && !this.root.host.contains(e.target)) this.#closeDropdown();
        };
        document.addEventListener("click", this.#docClickHandler);
      }

      this.renderCompanions();
      _applyCompanionTooltips(this.root);
      this._attachGestureHandlers(this.#card);
      this.#layoutTeardown = _layoutObserver(this);
    }

    #buildPills(options) {
      this.#grid.innerHTML = "";
      this.#optionButtons = [];
      for (const opt of options) {
        const btn = document.createElement("button");
        btn.type = "button";
        btn.className = "ndl-inpsel-option";
        btn.dataset.option = opt;
        btn.textContent = _capitalize(opt);
        btn.addEventListener("click", () => {
          _triggerBounce(btn);
          this.config.card?.sendCommand("select_option", { option: opt });
        });
        this.#grid.appendChild(btn);
        this.#optionButtons.push(btn);
      }
    }

    #buildDropdownOptions(options) {
      if (!this.#dropdown) return;
      this.#dropdown.innerHTML = "";
      this.#dropdownOptions = [];
      for (const opt of options) {
        const btn = document.createElement("button");
        btn.type = "button";
        btn.className = "ndl-inpsel-dropdown-option";
        btn.role = "option";
        btn.dataset.option = opt;
        btn.textContent = _capitalize(opt);
        btn.addEventListener("click", () => {
          this.config.card?.sendCommand("select_option", { option: opt });
          this.#closeDropdown();
          this.#triggerBtn?.focus();
        });
        btn.addEventListener("keydown", (e) => {
          const opts = this.#dropdownOptions;
          const idx = opts.indexOf(btn);
          if (e.key === "ArrowDown") {
            e.preventDefault();
            opts[Math.min(idx + 1, opts.length - 1)]?.focus();
          } else if (e.key === "ArrowUp") {
            e.preventDefault();
            if (idx === 0) this.#triggerBtn?.focus();
            else opts[idx - 1]?.focus();
          } else if (e.key === "Escape") {
            this.#closeDropdown();
            this.#triggerBtn?.focus();
          }
        });
        this.#dropdown.appendChild(btn);
        this.#dropdownOptions.push(btn);
      }
    }

    #positionDropdown() {
      if (!this.#dropdown || !this.#triggerBtn) return;
      const btnRect = this.#triggerBtn.getBoundingClientRect();
      const spaceBelow = window.innerHeight - btnRect.bottom;
      const spaceAbove = btnRect.top;
      // Drop-up detection (lesson #34): if not enough viewport space
      // below the trigger, position the dropdown above instead.
      const dropHeight = Math.min(this.#dropdown.scrollHeight || 240, 240);
      const placeAbove = spaceBelow < dropHeight + 8 && spaceAbove > spaceBelow;
      this.#dropdown.style.left = `${Math.round(btnRect.left)}px`;
      this.#dropdown.style.width = `${Math.round(btnRect.width)}px`;
      if (placeAbove) {
        const top = Math.max(8, btnRect.top - dropHeight - 6);
        this.#dropdown.style.top = `${Math.round(top)}px`;
      } else {
        this.#dropdown.style.top = `${Math.round(btnRect.bottom + 6)}px`;
      }
    }

    #openDropdown() {
      if (!this.#dropdown || !this.#options.length) return;
      // showPopover() puts the element in the browser's top layer, escaping
      // every stacking context and `overflow: hidden` ancestor. Position is
      // computed in viewport coordinates because position: fixed.
      try {
        if (typeof this.#dropdown.showPopover === "function") {
          this.#dropdown.showPopover();
        } else {
          this.#dropdown.style.display = "block";
        }
      } catch { /* showPopover throws if already open - ignore */ }
      this.#triggerBtn?.setAttribute("aria-expanded", "true");
      this.#positionDropdown();
      this.#repositionHandler = () => this.#positionDropdown();
      window.addEventListener("scroll", this.#repositionHandler, true);
      window.addEventListener("resize", this.#repositionHandler);
      this.#isOpen = true;
    }

    #closeDropdown() {
      if (!this.#dropdown) return;
      try {
        if (typeof this.#dropdown.hidePopover === "function") {
          this.#dropdown.hidePopover();
        } else {
          this.#dropdown.style.display = "";
        }
      } catch { /* hidePopover throws if already closed - ignore */ }
      this.#triggerBtn?.setAttribute("aria-expanded", "false");
      if (this.#repositionHandler) {
        window.removeEventListener("scroll", this.#repositionHandler, true);
        window.removeEventListener("resize", this.#repositionHandler);
        this.#repositionHandler = null;
      }
      this.#isOpen = false;
    }

    applyState(state, attributes) {
      this.#currentState = state;
      const isAvailable = state !== "unavailable" && state !== "unknown";

      if (this.#card) this.#card.dataset.state = isAvailable ? "on" : "off";

      if (this.#wasOn !== null && this.#wasOn !== isAvailable && this.#card) {
        this.#card.classList.remove("ndl-powering-up", "ndl-powering-down");
        void this.#card.getBoundingClientRect();
        this.#card.classList.add(isAvailable ? "ndl-powering-up" : "ndl-powering-down");
      }
      this.#wasOn = isAvailable;

      const palette = _colorsFor("input_select");
      if (this.#card) {
        if (isAvailable) this.#card.style.setProperty("--ndl-accent", palette.accent);
        else this.#card.style.removeProperty("--ndl-accent");
      }

      if (this.#chipEl) {
        this.#chipEl.textContent = isAvailable ? _capitalize(state) : "";
      }

      // Lesson #28 - rebuild option DOM only when the list actually changes.
      // Defensive: only adopt attributes.options if it is a non-empty array.
      // predictState returns {} for attributes which would otherwise clear
      // the option list and collapse the card body during optimistic updates.
      const incoming = attributes?.options;
      const options = (Array.isArray(incoming) && incoming.length) ? incoming : this.#options;
      this.#options = options;
      const optionsKey = options.join("|");
      if (optionsKey !== this.#lastOptionsKey) {
        this.#lastOptionsKey = optionsKey;
        if (this.#displayMode === "dropdown") this.#buildDropdownOptions(options);
        else if (this.#grid) this.#buildPills(options);
      }

      if (this.#displayMode === "dropdown") {
        if (this.#triggerLabel) this.#triggerLabel.textContent = isAvailable ? _capitalize(state) : "-";
        for (const btn of this.#dropdownOptions) {
          const sel = btn.dataset.option === state;
          btn.setAttribute("data-selected", String(sel));
          btn.setAttribute("aria-selected", String(sel));
        }
      } else {
        for (const btn of this.#optionButtons) {
          btn.setAttribute("data-selected", String(btn.dataset.option === state));
        }
      }
      this.announceState(`${this.def.friendly_name}, ${state}`);
    }

    predictState(action, data) {
      if (action === "select_option" && data.option) {
        // Include cached options so applyState doesn't see attributes.options
        // disappear during the optimistic frame.
        return { state: data.option, attributes: { options: this.#options } };
      }
      return null;
    }

    destroy() {
      if (this.#layoutTeardown) { this.#layoutTeardown(); this.#layoutTeardown = null; }
      if (this.#docClickHandler) {
        document.removeEventListener("click", this.#docClickHandler);
        this.#docClickHandler = null;
      }
      if (this.#repositionHandler) {
        window.removeEventListener("scroll", this.#repositionHandler, true);
        window.removeEventListener("resize", this.#repositionHandler);
        this.#repositionHandler = null;
      }
      // Make sure any open popover is released so it doesn't outlive the card.
      try { this.#dropdown?.hidePopover?.(); } catch { /* ignore */ }
    }
  }

  // ---------------------------------------------------------------------------
  // TimerCard
  // ---------------------------------------------------------------------------

  const TIMER_STYLES = /* css */`
    ${NODALIA_BASE}

    /* Timer icon: accent-tinted background + dark glyph */
    [part=card][data-state="on"] [part=card-icon].ndl-timer-icon {
      background: color-mix(in srgb,
                  var(--ndl-accent, var(--hrv-color-accent, #b197fc)) 38%,
                  color-mix(in srgb, var(--hrv-color-text, #1a1a2e) 8%, transparent));
    }
    [part=card][data-state="on"] [part=card-icon].ndl-timer-icon svg {
      color: var(--ndl-fg, var(--hrv-color-text, #1a1a2e));
      opacity: 1;
    }

    .ndl-timer-chip {
      font-size: 12px;
      font-weight: 700;
      height: 24px;
      padding: 0 12px;
    }
    .ndl-timer-chip:empty { display: none; }
    .ndl-timer-chip[data-state="active"],
    .ndl-timer-chip[data-state="paused"] {
      background: color-mix(in srgb, var(--ndl-accent, var(--hrv-color-accent, #b197fc)) 22%, transparent);
      border-color: color-mix(in srgb, var(--ndl-accent, var(--hrv-color-accent, #b197fc)) 50%, transparent);
    }

    [part=card-body] {
      display: flex;
      flex-direction: column;
      gap: 12px;
      align-items: center;
      margin-top: 8px;
    }

    /* Big countdown display */
    .ndl-timer-display {
      font-size: 42px;
      font-weight: 700;
      color: var(--ndl-fg, var(--hrv-color-text, #1a1a2e));
      font-variant-numeric: tabular-nums;
      line-height: 1;
      text-align: center;
    }
    .ndl-timer-display[data-paused="true"] { opacity: 0.5; }
    .ndl-timer-display[data-state="idle"] { opacity: 0.4; }

    .ndl-timer-controls {
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 12px;
    }
    .ndl-timer-btn {
      align-items: center;
      appearance: none;
      -webkit-backdrop-filter: blur(18px);
      backdrop-filter: blur(18px);
      background: color-mix(in srgb, var(--hrv-color-text, #1a1a2e) 5%, transparent);
      border: 1px solid color-mix(in srgb, var(--hrv-color-text, #1a1a2e) 6%, transparent);
      border-radius: 999px;
      box-shadow: inset 0 1px 0 color-mix(in srgb, var(--hrv-color-text, #1a1a2e) 6%, transparent);
      color: var(--ndl-fg, var(--hrv-color-text, #1a1a2e));
      cursor: pointer;
      display: inline-flex;
      height: 40px;
      width: 40px;
      justify-content: center;
      line-height: 0;
      padding: 0;
      transition: transform 180ms cubic-bezier(0.22, 0.84, 0.26, 1),
                  background 200ms ease;
    }
    .ndl-timer-btn:hover { transform: translateY(-1px); }
    .ndl-timer-btn.is-pressing {
      animation: ndl-btn-bounce var(--hrv-motion-bounce, 0.35s cubic-bezier(0.2, 0.9, 0.24, 1)) forwards;
    }
    .ndl-timer-btn:disabled {
      opacity: 0.35;
      cursor: default;
    }
    .ndl-timer-btn--primary {
      height: 48px;
      width: 48px;
      background: color-mix(in srgb, var(--ndl-accent, var(--hrv-color-accent, #b197fc)) 28%,
                  color-mix(in srgb, var(--hrv-color-text, #1a1a2e) 6%, transparent));
      border-color: color-mix(in srgb, var(--ndl-accent, var(--hrv-color-accent, #b197fc)) 50%, transparent);
    }
    .ndl-timer-btn svg { width: 18px; height: 18px; }
    .ndl-timer-btn--primary svg { width: 22px; height: 22px; }
    .ndl-timer-btn [part^="t-"] {
      display: inline-flex;
      align-items: center;
      justify-content: center;
    }
  `;

  class TimerCard extends BaseCard {
    #card = null;
    #chipEl = null;
    #display = null;
    #playBtn = null;
    #cancelBtn = null;
    #finishBtn = null;
    #timerInterval = null;
    #remaining = 0;
    #finishesAt = null;
    #state = "idle";
    #wasOn = null;
    #layoutTeardown = null;

    render() {
      const isWritable = this.def.capabilities === "read-write";
      this.root.innerHTML = /* html */`
        <style>${TIMER_STYLES}${COMPANION_DOT_STYLES}${NDL_ROW_CSS}</style>
        <div part="card" class="ndl-timer-card">
          <div part="card-header">
            <span part="card-icon" class="ndl-timer-icon" aria-hidden="true"></span>
            <span part="card-name">${_esc(this.def.friendly_name)}</span>
            <span class="ndl-chip ndl-timer-chip"></span>
          </div>
          <div part="card-body">
            <div class="ndl-timer-display">0:00:00</div>
            ${isWritable ? /* html */`
              <div class="ndl-timer-controls">
                <button class="ndl-timer-btn ndl-timer-cancel" type="button" aria-label="Cancel" title="Cancel" disabled>
                  <span part="t-cancel" aria-hidden="true"></span>
                </button>
                <button class="ndl-timer-btn ndl-timer-btn--primary ndl-timer-pp" type="button" aria-label="Start / Pause" title="Start / Pause">
                  <span part="t-pp" aria-hidden="true"></span>
                </button>
                <button class="ndl-timer-btn ndl-timer-finish" type="button" aria-label="Finish" title="Finish" disabled>
                  <span part="t-finish" aria-hidden="true"></span>
                </button>
              </div>
            ` : ""}
          </div>
          ${this.renderAriaLiveHTML()}
          ${this.renderCompanionZoneHTML()}
          <div part="stale-indicator" aria-hidden="true"></div>
        </div>
      `;
      this.#card = this.root.querySelector("[part=card]");
      this.#chipEl = this.root.querySelector(".ndl-timer-chip");
      this.#display = this.root.querySelector(".ndl-timer-display");
      this.#playBtn = this.root.querySelector(".ndl-timer-pp");
      this.#cancelBtn = this.root.querySelector(".ndl-timer-cancel");
      this.#finishBtn = this.root.querySelector(".ndl-timer-finish");

      this.renderIcon(this.resolveIcon(this.def.icon, "mdi:timer-outline"), "card-icon");
      this.renderIcon("mdi:play", "t-pp");
      this.renderIcon("mdi:stop", "t-cancel");
      this.renderIcon("mdi:check-circle", "t-finish");

      if (this.#playBtn) {
        this.#playBtn.addEventListener("click", () => {
          _triggerBounce(this.#playBtn);
          this.config.card?.sendCommand(this.#state === "active" ? "pause" : "start", {});
        });
      }
      if (this.#cancelBtn) {
        this.#cancelBtn.addEventListener("click", () => {
          _triggerBounce(this.#cancelBtn);
          this.config.card?.sendCommand("cancel", {});
        });
      }
      if (this.#finishBtn) {
        this.#finishBtn.addEventListener("click", () => {
          _triggerBounce(this.#finishBtn);
          this.config.card?.sendCommand("finish", {});
        });
      }

      this.renderCompanions();
      _applyCompanionTooltips(this.root);
      this._attachGestureHandlers(this.#card);
      this.#layoutTeardown = _layoutObserver(this);
    }

    applyState(state, attributes) {
      this.#state = state;
      const isActive = state === "active";
      const isPaused = state === "paused";
      const isOn = isActive || isPaused;

      if (this.#card) this.#card.dataset.state = isOn ? "on" : "off";

      if (this.#wasOn !== null && this.#wasOn !== isOn && this.#card) {
        this.#card.classList.remove("ndl-powering-up", "ndl-powering-down");
        void this.#card.getBoundingClientRect();
        this.#card.classList.add(isOn ? "ndl-powering-up" : "ndl-powering-down");
      }
      this.#wasOn = isOn;

      const palette = _colorsFor("timer");
      if (this.#card) {
        if (isOn) this.#card.style.setProperty("--ndl-accent", palette.accent);
        else this.#card.style.removeProperty("--ndl-accent");
      }

      if (isActive && attributes.finishes_at) {
        this.#finishesAt = new Date(attributes.finishes_at).getTime();
        this.#startTick();
      } else {
        this.#stopTick();
        this.#finishesAt = null;
        if (isPaused && attributes.remaining) this.#remaining = this.#parseDur(attributes.remaining);
        else if (attributes.duration) this.#remaining = state === "idle" ? this.#parseDur(attributes.duration) : 0;
        else this.#remaining = 0;
      }

      if (this.#display) {
        this.#display.setAttribute("data-paused", String(isPaused));
        this.#display.setAttribute("data-state", state);
        this.#updateDisp();
      }

      this.renderIcon(isActive ? "mdi:pause" : "mdi:play", "t-pp");

      if (this.#chipEl) {
        this.#chipEl.textContent = _capitalize(state);
        this.#chipEl.dataset.state = state;
      }

      if (this.#cancelBtn) this.#cancelBtn.disabled = state === "idle";
      if (this.#finishBtn) this.#finishBtn.disabled = state === "idle";

      this.announceState(`${this.def.friendly_name}, ${state}`);
    }

    predictState(action, _data) {
      if (action === "start") return { state: "active", attributes: {} };
      if (action === "pause") return { state: "paused", attributes: {} };
      if (action === "cancel" || action === "finish") return { state: "idle", attributes: {} };
      return null;
    }

    destroy() {
      this.#stopTick();
      if (this.#layoutTeardown) { this.#layoutTeardown(); this.#layoutTeardown = null; }
    }

    #parseDur(d) {
      if (typeof d !== "string") return 0;
      const p = d.split(":").map(Number);
      return p.length === 3 ? p[0] * 3600 + p[1] * 60 + p[2]
           : p.length === 2 ? p[0] * 60 + p[1]
           : p[0] || 0;
    }

    #startTick() {
      this.#stopTick();
      this.#timerInterval = setInterval(() => this.#updateDisp(), 500);
    }

    #stopTick() {
      if (this.#timerInterval) {
        clearInterval(this.#timerInterval);
        this.#timerInterval = null;
      }
    }

    #updateDisp() {
      let s = this.#remaining;
      if (this.#finishesAt) s = Math.max(0, Math.round((this.#finishesAt - Date.now()) / 1000));
      const h = Math.floor(s / 3600);
      const m = Math.floor((s % 3600) / 60);
      const sec = s % 60;
      if (this.#display) {
        this.#display.textContent = `${h}:${String(m).padStart(2, "0")}:${String(sec).padStart(2, "0")}`;
      }
    }
  }

  // ---------------------------------------------------------------------------
  // GenericCard / HarvestActionCard / RemoteCard
  // ---------------------------------------------------------------------------

  const GENERIC_STYLES = /* css */`
    ${NODALIA_BASE}

    /* Generic icon: accent-tinted background + dark glyph when on */
    [part=card][data-state="on"] [part=card-icon].ndl-generic-icon {
      background: color-mix(in srgb,
                  var(--ndl-accent, var(--hrv-color-accent, #74c0fc)) 38%,
                  color-mix(in srgb, var(--hrv-color-text, #1a1a2e) 8%, transparent));
    }
    [part=card][data-state="on"] [part=card-icon].ndl-generic-icon svg {
      color: var(--ndl-fg, var(--hrv-color-text, #1a1a2e));
      opacity: 1;
    }

    .ndl-generic-chip {
      font-size: 12px;
      font-weight: 700;
      height: 24px;
      padding: 0 12px;
    }
    .ndl-generic-chip[data-state="on"] {
      background: color-mix(in srgb, var(--ndl-accent, var(--hrv-color-accent, #74c0fc)) 22%, transparent);
      border-color: color-mix(in srgb, var(--ndl-accent, var(--hrv-color-accent, #74c0fc)) 50%, transparent);
    }
    .ndl-generic-chip:empty { display: none; }
  `;

  class GenericCard extends BaseCard {
    #card = null;
    #chipEl = null;
    #isOn = false;
    #wasOn = null;
    #layoutTeardown = null;

    render() {
      const isWritable = this.def.capabilities === "read-write";
      this.root.innerHTML = /* html */`
        <style>${GENERIC_STYLES}${COMPANION_DOT_STYLES}${NDL_ROW_CSS}</style>
        <div part="card" class="ndl-generic-card">
          <div part="card-header">
            <span part="card-icon" class="ndl-generic-icon" aria-hidden="true"></span>
            <span part="card-name">${_esc(this.def.friendly_name)}</span>
            <span class="ndl-chip ndl-generic-chip"></span>
          </div>
          ${this.renderAriaLiveHTML()}
          ${this.renderCompanionZoneHTML()}
          <div part="stale-indicator" aria-hidden="true"></div>
        </div>
      `;
      this.#card = this.root.querySelector("[part=card]");
      this.#chipEl = this.root.querySelector(".ndl-generic-chip");
      this.renderIcon(this.resolveIcon(this.def.icon, "mdi:help-circle"), "card-icon");

      // Tap on icon = toggle, when writable. Generic fallback for unknown
      // domains so tap still does something sensible.
      if (isWritable) {
        const iconEl = this.root.querySelector("[part=card-icon]");
        this._attachGestureHandlers(iconEl, {
          onTap: () => {
            _triggerBounce(iconEl);
            const tap = this.config.gestureConfig?.tap;
            if (tap) { this._runAction(tap); return; }
            this.config.card?.sendCommand("toggle", {});
          },
        });
      }

      this.renderCompanions();
      _applyCompanionTooltips(this.root);
      this._attachGestureHandlers(this.#card);
      this.#layoutTeardown = _layoutObserver(this);
    }

    applyState(state, _attributes) {
      const isOnState = state === "on";
      this.#isOn = isOnState;
      const isAvailable = state !== "unavailable" && state !== "unknown";

      // For generic, "on"/"off" maps directly. Other states (numeric, custom)
      // count as on-but-with-a-value.
      const showAccent = isAvailable && state !== "off";
      if (this.#card) this.#card.dataset.state = showAccent ? "on" : "off";

      if (this.#wasOn !== null && this.#wasOn !== showAccent && this.#card) {
        this.#card.classList.remove("ndl-powering-up", "ndl-powering-down");
        void this.#card.getBoundingClientRect();
        this.#card.classList.add(showAccent ? "ndl-powering-up" : "ndl-powering-down");
      }
      this.#wasOn = showAccent;

      if (this.#card) {
        if (showAccent) this.#card.style.setProperty("--ndl-accent", _DEFAULT_COLORS.accent);
        else this.#card.style.removeProperty("--ndl-accent");
      }

      if (this.#chipEl) {
        this.#chipEl.textContent = _capitalize(state);
        this.#chipEl.dataset.state = showAccent ? "on" : "off";
      }
      this.announceState(`${this.def.friendly_name}, ${state}`);
    }

    predictState(action, _data) {
      if (action !== "toggle") return null;
      return { state: this.#isOn ? "off" : "on", attributes: {} };
    }

    destroy() {
      if (this.#layoutTeardown) { this.#layoutTeardown(); this.#layoutTeardown = null; }
    }
  }

  class HarvestActionCard extends BaseCard {
    #card = null;
    #chipEl = null;
    #layoutTeardown = null;

    render() {
      const isWritable = this.def.capabilities === "read-write";
      this.root.innerHTML = /* html */`
        <style>${GENERIC_STYLES}${COMPANION_DOT_STYLES}${NDL_ROW_CSS}</style>
        <div part="card" class="ndl-generic-card" data-state="on">
          <div part="card-header">
            <span part="card-icon" class="ndl-generic-icon" aria-hidden="true"></span>
            <span part="card-name">${_esc(this.def.friendly_name)}</span>
            <span class="ndl-chip ndl-generic-chip" data-state="on">Action</span>
          </div>
          ${this.renderAriaLiveHTML()}
          ${this.renderCompanionZoneHTML()}
          <div part="stale-indicator" aria-hidden="true"></div>
        </div>
      `;
      this.#card = this.root.querySelector("[part=card]");
      this.#chipEl = this.root.querySelector(".ndl-generic-chip");
      // Always-active accent (harvest_action triggers are always interactive)
      this.#card.style.setProperty("--ndl-accent", _colorsFor("harvest_action").accent);
      this.renderIcon(this.resolveIcon(this.def.icon, "mdi:play-circle-outline"), "card-icon");
      if (isWritable) {
        const iconEl = this.root.querySelector("[part=card-icon]");
        this._attachGestureHandlers(iconEl, {
          onTap: () => {
            _triggerBounce(iconEl);
            const tap = this.config.gestureConfig?.tap;
            if (tap) { this._runAction(tap); return; }
            this.config.card?.sendCommand("trigger", {});
          },
        });
      }
      this.renderCompanions();
      _applyCompanionTooltips(this.root);
      this._attachGestureHandlers(this.#card);
      this.#layoutTeardown = _layoutObserver(this);
    }

    applyState(state, _attributes) {
      this.announceState(`${this.def.friendly_name}, ${state}`);
    }

    destroy() {
      if (this.#layoutTeardown) { this.#layoutTeardown(); this.#layoutTeardown = null; }
    }
  }

  const REMOTE_STYLES = /* css */`
    ${NODALIA_BASE}

    /* Remote icon: accent-tinted background + dark glyph */
    [part=card][data-state="on"] [part=card-icon].ndl-remote-icon {
      background: color-mix(in srgb,
                  var(--ndl-accent, var(--hrv-color-accent, #adb5bd)) 38%,
                  color-mix(in srgb, var(--hrv-color-text, #1a1a2e) 8%, transparent));
    }
    [part=card][data-state="on"] [part=card-icon].ndl-remote-icon svg {
      color: var(--ndl-fg, var(--hrv-color-text, #1a1a2e));
      opacity: 1;
    }
    .ndl-remote-chip:empty { display: none; }

    [part=card-body] {
      display: flex;
      flex-direction: column;
      align-items: center;
      gap: 10px;
      margin-top: 12px;
    }

    .ndl-remote-power,
    .ndl-remote-activity {
      appearance: none;
      -webkit-backdrop-filter: blur(18px);
      backdrop-filter: blur(18px);
      background: color-mix(in srgb, var(--hrv-color-text, #1a1a2e) 5%, transparent);
      border: 1px solid color-mix(in srgb, var(--hrv-color-text, #1a1a2e) 6%, transparent);
      border-radius: 14px;
      box-shadow: inset 0 1px 0 color-mix(in srgb, var(--hrv-color-text, #1a1a2e) 6%, transparent);
      color: var(--ndl-fg, var(--hrv-color-text, #1a1a2e));
      cursor: pointer;
      font: inherit;
      padding: 9px 14px;
      width: 100%;
      transition: transform 180ms cubic-bezier(0.22, 0.84, 0.26, 1),
                  background 200ms ease;
    }
    .ndl-remote-power:hover { transform: translateY(-1px); }
    .ndl-remote-power.is-pressing {
      animation: ndl-btn-bounce var(--hrv-motion-bounce, 0.35s cubic-bezier(0.2, 0.9, 0.24, 1)) forwards;
    }
    .ndl-remote-power[aria-pressed="true"] {
      background: color-mix(in srgb, var(--ndl-accent, var(--hrv-color-accent, #adb5bd)) 28%,
                  color-mix(in srgb, var(--hrv-color-text, #1a1a2e) 6%, transparent));
      border-color: color-mix(in srgb, var(--ndl-accent, var(--hrv-color-accent, #adb5bd)) 50%, transparent);
    }
    .ndl-remote-power:disabled,
    .ndl-remote-activity:disabled { opacity: 0.4; cursor: not-allowed; }
  `;

  class RemoteCard extends BaseCard {
    #card = null;
    #chipEl = null;
    #layoutTeardown = null;

    render() {
      const isWritable = this.def.capabilities === "read-write";
      this.root.innerHTML = /* html */`
        <style>${REMOTE_STYLES}${COMPANION_DOT_STYLES}${NDL_ROW_CSS}</style>
        <div part="card" class="ndl-remote-card" data-state="on">
          <div part="card-header">
            <span part="card-icon" class="ndl-remote-icon" aria-hidden="true"></span>
            <span part="card-name">${_esc(this.def.friendly_name)}</span>
            <span class="ndl-chip ndl-remote-chip"></span>
          </div>
          ${isWritable ? /* html */`
            <div part="card-body">
              <button class="ndl-remote-power" part="power-toggle" type="button"></button>
              <select class="ndl-remote-activity" part="activity-select" aria-label="${_esc(this.def.friendly_name)} activity" hidden></select>
            </div>
          ` : ""}
          ${this.renderAriaLiveHTML()}
          ${this.renderCompanionZoneHTML()}
          <div part="stale-indicator" aria-hidden="true"></div>
        </div>
      `;
      this.#card = this.root.querySelector("[part=card]");
      this.#chipEl = this.root.querySelector(".ndl-remote-chip");
      this.#card.style.setProperty("--ndl-accent", _colorsFor("remote").accent);
      this.renderIcon(this.resolveIcon(this.def.icon, "mdi:remote"), "card-icon");

      if (isWritable) {
        const power = this.root.querySelector("[part=power-toggle]");
        power?.addEventListener("click", () => {
          _triggerBounce(power);
          const isOn = power.getAttribute("aria-pressed") === "true";
          this.config.card?.sendCommand(isOn ? "turn_off" : "turn_on", {});
        });
        const activity = this.root.querySelector("[part=activity-select]");
        activity?.addEventListener("change", () => {
          if (activity.value) this.config.card?.sendCommand("turn_on", { activity: activity.value });
        });
      }
      this.renderCompanions();
      _applyCompanionTooltips(this.root);
      this._attachGestureHandlers(this.#card);
      this.#layoutTeardown = _layoutObserver(this);
    }

    applyState(state, attributes) {
      const isUnavailable = state === "unavailable" || state === "unknown";
      const currentActivity = typeof attributes?.current_activity === "string"
        ? attributes.current_activity
        : "";
      if (this.#chipEl) this.#chipEl.textContent = currentActivity || _capitalize(state);
      const power = this.root.querySelector("[part=power-toggle]");
      if (power) {
        power.disabled = isUnavailable;
        power.textContent = state === "on" ? "On" : "Off";
        power.setAttribute("aria-pressed", String(state === "on"));
        power.setAttribute("aria-label", `${this.def.friendly_name} - ${state === "on" ? "Turn off" : "Turn on"}`);
      }
      const activity = this.root.querySelector("[part=activity-select]");
      if (activity) {
        const activities = Array.isArray(attributes?.activity_list)
          ? attributes.activity_list.filter(item => typeof item === "string")
          : [];
        activity.replaceChildren(...activities.map(item => {
          const option = document.createElement("option");
          option.value = item;
          option.textContent = item;
          return option;
        }));
        activity.hidden = activities.length === 0;
        activity.disabled = isUnavailable;
        if (currentActivity && activities.includes(currentActivity)) {
          activity.value = currentActivity;
        } else if (activities.length > 0) {
          activity.selectedIndex = -1;
        }
      }
      this.announceState(`${this.def.friendly_name}, ${state}${currentActivity ? `, ${currentActivity}` : ""}`);
    }

    predictState(action, data) {
      if (action === "turn_off") return { state: "off", attributes: {} };
      if (action === "turn_on") {
        return {
          state: "on",
          attributes: data?.activity ? { current_activity: data.activity } : {},
        };
      }
      return null;
    }

    destroy() {
      if (this.#layoutTeardown) { this.#layoutTeardown(); this.#layoutTeardown = null; }
    }
  }

  // ---------------------------------------------------------------------------
  // WeatherCard
  // ---------------------------------------------------------------------------

  // Condition-driven gradient palettes (sky-based colour logic)
  const _COND_COLORS = {
    "sunny":           { from: "#ffe566", to: "#ffd132", accent: "#f7b731" },
    "clear-night":     { from: "#748ffc", to: "#5c7cfa", accent: "#4c6ef5" },
    "partlycloudy":    { from: "#9fd1ff", to: "#74c0fc", accent: "#4dabf7" },
    "cloudy":          { from: "#b8c9d9", to: "#9ab2c4", accent: "#7a9db5" },
    "fog":             { from: "#c8d6df", to: "#b0c0ca", accent: "#8fa4b2" },
    "rainy":           { from: "#74c0fc", to: "#4dabf7", accent: "#339af0" },
    "pouring":         { from: "#4dabf7", to: "#339af0", accent: "#1c7ed6" },
    "snowy":           { from: "#e7f5ff", to: "#bac8ff", accent: "#91a7ff" },
    "snowy-rainy":     { from: "#c5f6fa", to: "#99e9f2", accent: "#66d9e8" },
    "hail":            { from: "#c5f6fa", to: "#a5d8ff", accent: "#74c0fc" },
    "lightning":       { from: "#d0bfff", to: "#9775fa", accent: "#7048e8" },
    "lightning-rainy": { from: "#74c0fc", to: "#5c7cfa", accent: "#4c6ef5" },
    "windy":           { from: "#96f2d7", to: "#63e6be", accent: "#38d9a9" },
    "windy-variant":   { from: "#96f2d7", to: "#63e6be", accent: "#38d9a9" },
    "exceptional":     { from: "#ffd8a8", to: "#ffa94d", accent: "#fd7e14" },
  };
  const _COND_COLORS_DEFAULT = { from: "#9fd1ff", to: "#74c0fc", accent: "#4dabf7" };

  function _condColors(condition) {
    return _COND_COLORS[condition] ?? _COND_COLORS_DEFAULT;
  }

  // Simplified temperature-to-colour for the large temperature number
  function _tempColor(celsius) {
    const c = Number(celsius);
    if (!Number.isFinite(c)) return null;
    if (c < 0)  return "#74c0fc";
    if (c < 15) return "#38d9a9";
    if (c < 25) return "#ffd132";
    if (c < 35) return "#f59f42";
    return "#e03131";
  }

  const _NDL_COND_PATHS = {
    "sunny":           "M12,7A5,5 0 0,1 17,12A5,5 0 0,1 12,17A5,5 0 0,1 7,12A5,5 0 0,1 12,7M12,9A3,3 0 0,0 9,12A3,3 0 0,0 12,15A3,3 0 0,0 15,12A3,3 0 0,0 12,9M12,2L14.39,5.42C13.65,5.15 12.84,5 12,5C11.16,5 10.35,5.15 9.61,5.42L12,2M3.34,7L7.5,6.65C6.9,7.16 6.36,7.78 5.94,8.5C5.5,9.24 5.25,10 5.11,10.79L3.34,7M3.36,17L5.12,13.23C5.26,14 5.53,14.78 5.95,15.5C6.37,16.24 6.91,16.86 7.5,17.37L3.36,17M20.65,7L18.88,10.79C18.74,10 18.47,9.23 18.05,8.5C17.63,7.78 17.1,7.15 16.5,6.64L20.65,7M20.64,17L16.5,17.36C17.09,16.85 17.62,16.22 18.04,15.5C18.46,14.77 18.73,14 18.87,13.21L20.64,17M12,22L9.59,18.56C10.33,18.83 11.14,19 12,19C12.82,19 13.63,18.83 14.37,18.56L12,22Z",
    "clear-night":     "M17.75,4.09L15.22,6.03L16.13,9.09L13.5,7.28L10.87,9.09L11.78,6.03L9.25,4.09L12.44,4L13.5,1L14.56,4L17.75,4.09M21.25,11L19.61,12.25L20.2,14.23L18.5,13.06L16.8,14.23L17.39,12.25L15.75,11L17.81,10.95L18.5,9L19.19,10.95L21.25,11M18.97,15.95C19.8,15.87 20.69,17.05 20.16,17.8C19.84,18.25 19.5,18.67 19.08,19.07C15.17,23 8.84,23 4.94,19.07C1.03,15.17 1.03,8.83 4.94,4.93C5.34,4.53 5.76,4.17 6.21,3.85C6.96,3.32 8.14,4.21 8.06,5.04C7.79,7.9 8.75,10.87 10.95,13.06C13.14,15.26 16.1,16.22 18.97,15.95M17.33,17.97C14.5,17.81 11.7,16.64 9.53,14.5C7.36,12.31 6.2,9.5 6.04,6.68C3.23,9.82 3.34,14.64 6.35,17.66C9.37,20.67 14.19,20.78 17.33,17.97Z",
    "partlycloudy":    "M12.74,5.47C15.1,6.5 16.35,9.03 15.92,11.46C17.19,12.56 18,14.19 18,16V16.17C18.31,16.06 18.65,16 19,16A3,3 0 0,1 22,19A3,3 0 0,1 19,22H6A4,4 0 0,1 2,18A4,4 0 0,1 6,14H6.27C5,12.45 4.6,10.24 5.5,8.26C6.72,5.5 9.97,4.24 12.74,5.47M11.93,7.3C10.16,6.5 8.09,7.31 7.31,9.07C6.85,10.09 6.93,11.22 7.41,12.13C8.5,10.83 10.16,10 12,10C12.7,10 13.38,10.12 14,10.34C13.94,9.06 13.18,7.86 11.93,7.3M13.55,3.64C13,3.4 12.45,3.23 11.88,3.12L14.37,1.82L15.27,4.71C14.76,4.29 14.19,3.93 13.55,3.64M6.09,4.44C5.6,4.79 5.17,5.19 4.8,5.63L4.91,2.82L7.87,3.5C7.25,3.71 6.65,4.03 6.09,4.44M18,9.71C17.91,9.12 17.78,8.55 17.59,8L19.97,9.5L17.92,11.73C18.03,11.08 18.05,10.4 18,9.71M3.04,11.3C3.11,11.9 3.24,12.47 3.43,13L1.06,11.5L3.1,9.28C3,9.93 2.97,10.61 3.04,11.3M19,18H16V16A4,4 0 0,0 12,12A4,4 0 0,0 8,16H6A2,2 0 0,0 4,18A2,2 0 0,0 6,20H19A1,1 0 0,0 20,19A1,1 0 0,0 19,18Z",
    "cloudy":          "M6,19A5,5 0 0,1 1,14A5,5 0 0,1 6,9C7,6.65 9.3,5 12,5C15.43,5 18.24,7.66 18.5,11.03L19,11A4,4 0 0,1 23,15A4,4 0 0,1 19,19H6M19,13H17V12A5,5 0 0,0 12,7C9.5,7 7.45,8.82 7.06,11.19C6.73,11.07 6.37,11 6,11A3,3 0 0,0 3,14A3,3 0 0,0 6,17H19A2,2 0 0,0 21,15A2,2 0 0,0 19,13Z",
    "fog":             "M3,15H13A1,1 0 0,1 14,16A1,1 0 0,1 13,17H3A1,1 0 0,1 2,16A1,1 0 0,1 3,15M16,15H21A1,1 0 0,1 22,16A1,1 0 0,1 21,17H16A1,1 0 0,1 15,16A1,1 0 0,1 16,15M1,12A5,5 0 0,1 6,7C7,4.65 9.3,3 12,3C15.43,3 18.24,5.66 18.5,9.03L19,9C21.19,9 22.97,10.76 23,13H21A2,2 0 0,0 19,11H17V10A5,5 0 0,0 12,5C9.5,5 7.45,6.82 7.06,9.19C6.73,9.07 6.37,9 6,9A3,3 0 0,0 3,12C3,12.35 3.06,12.69 3.17,13H1.1L1,12M3,19H5A1,1 0 0,1 6,20A1,1 0 0,1 5,21H3A1,1 0 0,1 2,20A1,1 0 0,1 3,19M8,19H21A1,1 0 0,1 22,20A1,1 0 0,1 21,21H8A1,1 0 0,1 7,20A1,1 0 0,1 8,19Z",
    "rainy":           "M6,14.03A1,1 0 0,1 7,15.03C7,15.58 6.55,16.03 6,16.03C3.24,16.03 1,13.79 1,11.03C1,8.27 3.24,6.03 6,6.03C7,3.68 9.3,2.03 12,2.03C15.43,2.03 18.24,4.69 18.5,8.06L19,8.03A4,4 0 0,1 23,12.03C23,14.23 21.21,16.03 19,16.03H18C17.45,16.03 17,15.58 17,15.03C17,14.47 17.45,14.03 18,14.03H19A2,2 0 0,0 21,12.03A2,2 0 0,0 19,10.03H17V9.03C17,6.27 14.76,4.03 12,4.03C9.5,4.03 7.45,5.84 7.06,8.21C6.73,8.09 6.37,8.03 6,8.03A3,3 0 0,0 3,11.03A3,3 0 0,0 6,14.03M12,14.15C12.18,14.39 12.37,14.66 12.56,14.94C13,15.56 14,17.03 14,18C14,19.11 13.1,20 12,20A2,2 0 0,1 10,18C10,17.03 11,15.56 11.44,14.94C11.63,14.66 11.82,14.4 12,14.15M12,11.03L11.5,11.59C11.5,11.59 10.65,12.55 9.79,13.81C8.93,15.06 8,16.56 8,18A4,4 0 0,0 12,22A4,4 0 0,0 16,18C16,16.56 15.07,15.06 14.21,13.81C13.35,12.55 12.5,11.59 12.5,11.59",
    "pouring":         "M9,12C9.53,12.14 9.85,12.69 9.71,13.22L8.41,18.05C8.27,18.59 7.72,18.9 7.19,18.76C6.65,18.62 6.34,18.07 6.5,17.54L7.78,12.71C7.92,12.17 8.47,11.86 9,12M13,12C13.53,12.14 13.85,12.69 13.71,13.22L11.64,20.95C11.5,21.5 10.95,21.8 10.41,21.66C9.88,21.5 9.56,20.97 9.7,20.43L11.78,12.71C11.92,12.17 12.47,11.86 13,12M17,12C17.53,12.14 17.85,12.69 17.71,13.22L16.41,18.05C16.27,18.59 15.72,18.9 15.19,18.76C14.65,18.62 14.34,18.07 14.5,17.54L15.78,12.71C15.92,12.17 16.47,11.86 17,12M17,10V9A5,5 0 0,0 12,4C9.5,4 7.45,5.82 7.06,8.19C6.73,8.07 6.37,8 6,8A3,3 0 0,0 3,11C3,12.11 3.6,13.08 4.5,13.6V13.59C5,13.87 5.14,14.5 4.87,14.96C4.59,15.43 4,15.6 3.5,15.32V15.33C2,14.47 1,12.85 1,11A5,5 0 0,1 6,6C7,3.65 9.3,2 12,2C15.43,2 18.24,4.66 18.5,8.03L19,8A4,4 0 0,1 23,12C23,13.5 22.2,14.77 21,15.46V15.46C20.5,15.73 19.91,15.57 19.63,15.09C19.36,14.61 19.5,14 20,13.72V13.73C20.6,13.39 21,12.74 21,12A2,2 0 0,0 19,10H17Z",
    "snowy":           "M6,14A1,1 0 0,1 7,15A1,1 0 0,1 6,16A5,5 0 0,1 1,11A5,5 0 0,1 6,6C7,3.65 9.3,2 12,2C15.43,2 18.24,4.66 18.5,8.03L19,8A4,4 0 0,1 23,12A4,4 0 0,1 19,16H18A1,1 0 0,1 17,15A1,1 0 0,1 18,14H19A2,2 0 0,0 21,12A2,2 0 0,0 19,10H17V9A5,5 0 0,0 12,4C9.5,4 7.45,5.82 7.06,8.19C6.73,8.07 6.37,8 6,8A3,3 0 0,0 3,11A3,3 0 0,0 6,14M7.88,18.07L10.07,17.5L8.46,15.88C8.07,15.5 8.07,14.86 8.46,14.46C8.85,14.07 9.5,14.07 9.88,14.46L11.5,16.07L12.07,13.88C12.21,13.34 12.76,13.03 13.29,13.17C13.83,13.31 14.14,13.86 14,14.4L13.41,16.59L15.6,16C16.14,15.86 16.69,16.17 16.83,16.71C16.97,17.24 16.66,17.79 16.12,17.93L13.93,18.5L15.54,20.12C15.93,20.5 15.93,21.15 15.54,21.54C15.15,21.93 14.5,21.93 14.12,21.54L12.5,19.93L11.93,22.12C11.79,22.66 11.24,22.97 10.71,22.83C10.17,22.69 9.86,22.14 10,21.6L10.59,19.41L8.4,20C7.86,20.14 7.31,19.83 7.17,19.29C7.03,18.76 7.34,18.21 7.88,18.07Z",
    "snowy-rainy":     "M4,16.36C3.86,15.82 4.18,15.25 4.73,15.11L7,14.5L5.33,12.86C4.93,12.46 4.93,11.81 5.33,11.4C5.73,11 6.4,11 6.79,11.4L8.45,13.05L9.04,10.8C9.18,10.24 9.75,9.92 10.29,10.07C10.85,10.21 11.17,10.78 11,11.33L10.42,13.58L12.67,13C13.22,12.83 13.79,13.15 13.93,13.71C14.08,14.25 13.76,14.82 13.2,14.96L10.95,15.55L12.6,17.21C13,17.6 13,18.27 12.6,18.67C12.2,19.07 11.54,19.07 11.15,18.67L9.5,17L8.89,19.27C8.75,19.83 8.18,20.14 7.64,20C7.08,19.86 6.77,19.29 6.91,18.74L7.5,16.5L5.26,17.09C4.71,17.23 4.14,16.92 4,16.36M1,10A5,5 0 0,1 6,5C7,2.65 9.3,1 12,1C15.43,1 18.24,3.66 18.5,7.03L19,7A4,4 0 0,1 23,11A4,4 0 0,1 19,15A1,1 0 0,1 18,14A1,1 0 0,1 19,13A2,2 0 0,0 21,11A2,2 0 0,0 19,9H17V8A5,5 0 0,0 12,3C9.5,3 7.45,4.82 7.06,7.19C6.73,7.07 6.37,7 6,7A3,3 0 0,0 3,10C3,10.85 3.35,11.61 3.91,12.16C4.27,12.55 4.26,13.16 3.88,13.54C3.5,13.93 2.85,13.93 2.47,13.54C1.56,12.63 1,11.38 1,10M14.03,20.43C14.13,20.82 14.5,21.04 14.91,20.94L16.5,20.5L16.06,22.09C15.96,22.5 16.18,22.87 16.57,22.97C16.95,23.08 17.35,22.85 17.45,22.46L17.86,20.89L19.03,22.05C19.3,22.33 19.77,22.33 20.05,22.05C20.33,21.77 20.33,21.3 20.05,21.03L18.89,19.86L20.46,19.45C20.85,19.35 21.08,18.95 20.97,18.57C20.87,18.18 20.5,17.96 20.09,18.06L18.5,18.5L18.94,16.91C19.04,16.5 18.82,16.13 18.43,16.03C18.05,15.92 17.65,16.15 17.55,16.54L17.14,18.11L15.97,16.95C15.7,16.67 15.23,16.67 14.95,16.95C14.67,17.24 14.67,17.7 14.95,17.97L16.11,19.14L14.54,19.55C14.15,19.65 13.92,20.05 14.03,20.43Z",
    "hail":            "M6,14A1,1 0 0,1 7,15A1,1 0 0,1 6,16A5,5 0 0,1 1,11A5,5 0 0,1 6,6C7,3.65 9.3,2 12,2C15.43,2 18.24,4.66 18.5,8.03L19,8A4,4 0 0,1 23,12A4,4 0 0,1 19,16H18A1,1 0 0,1 17,15A1,1 0 0,1 18,14H19A2,2 0 0,0 21,12A2,2 0 0,0 19,10H17V9A5,5 0 0,0 12,4C9.5,4 7.45,5.82 7.06,8.19C6.73,8.07 6.37,8 6,8A3,3 0 0,0 3,11A3,3 0 0,0 6,14M10,18A2,2 0 0,1 12,20A2,2 0 0,1 10,22A2,2 0 0,1 8,20A2,2 0 0,1 10,18M14.5,16A1.5,1.5 0 0,1 16,17.5A1.5,1.5 0 0,1 14.5,19A1.5,1.5 0 0,1 13,17.5A1.5,1.5 0 0,1 14.5,16M10.5,12A1.5,1.5 0 0,1 12,13.5A1.5,1.5 0 0,1 10.5,15A1.5,1.5 0 0,1 9,13.5A1.5,1.5 0 0,1 10.5,12Z",
    "lightning":       "M6,16A5,5 0 0,1 1,11A5,5 0 0,1 6,6C7,3.65 9.3,2 12,2C15.43,2 18.24,4.66 18.5,8.03L19,8A4,4 0 0,1 23,12A4,4 0 0,1 19,16H18A1,1 0 0,1 17,15A1,1 0 0,1 18,14H19A2,2 0 0,0 21,12A2,2 0 0,0 19,10H17V9A5,5 0 0,0 12,4C9.5,4 7.45,5.82 7.06,8.19C6.73,8.07 6.37,8 6,8A3,3 0 0,0 3,11A3,3 0 0,0 6,14H7A1,1 0 0,1 8,15A1,1 0 0,1 7,16H6M12,11H15L13,15H15L11.25,22L12,17H9.5L12,11Z",
    "lightning-rainy": "M4.5,13.59C5,13.87 5.14,14.5 4.87,14.96C4.59,15.44 4,15.6 3.5,15.33V15.33C2,14.47 1,12.85 1,11A5,5 0 0,1 6,6C7,3.65 9.3,2 12,2C15.43,2 18.24,4.66 18.5,8.03L19,8A4,4 0 0,1 23,12A4,4 0 0,1 19,16A1,1 0 0,1 18,15A1,1 0 0,1 19,14A2,2 0 0,0 21,12A2,2 0 0,0 19,10H17V9A5,5 0 0,0 12,4C9.5,4 7.45,5.82 7.06,8.19C6.73,8.07 6.37,8 6,8A3,3 0 0,0 3,11C3,12.11 3.6,13.08 4.5,13.6V13.59M9.5,11H12.5L10.5,15H12.5L8.75,22L9.5,17H7L9.5,11M17.5,18.67C17.5,19.96 16.5,21 15.25,21C14,21 13,19.96 13,18.67C13,17.12 15.25,14.5 15.25,14.5C15.25,14.5 17.5,17.12 17.5,18.67Z",
    "windy":           "M4,10A1,1 0 0,1 3,9A1,1 0 0,1 4,8H12A2,2 0 0,0 14,6A2,2 0 0,0 12,4C11.45,4 10.95,4.22 10.59,4.59C10.2,5 9.56,5 9.17,4.59C8.78,4.2 8.78,3.56 9.17,3.17C9.9,2.45 10.9,2 12,2A4,4 0 0,1 16,6A4,4 0 0,1 12,10H4M19,12A1,1 0 0,0 20,11A1,1 0 0,0 19,10C18.72,10 18.47,10.11 18.29,10.29C17.9,10.68 17.27,10.68 16.88,10.29C16.5,9.9 16.5,9.27 16.88,8.88C17.42,8.34 18.17,8 19,8A3,3 0 0,1 22,11A3,3 0 0,1 19,14H5A1,1 0 0,1 4,13A1,1 0 0,1 5,12H19M18,18H4A1,1 0 0,1 3,17A1,1 0 0,1 4,16H18A3,3 0 0,1 21,19A3,3 0 0,1 18,22C17.17,22 16.42,21.66 15.88,21.12C15.5,20.73 15.5,20.1 15.88,19.71C16.27,19.32 16.9,19.32 17.29,19.71C17.47,19.89 17.72,20 18,20A1,1 0 0,0 19,19A1,1 0 0,0 18,18Z",
    "windy-variant":   "M6,6L6.69,6.06C7.32,3.72 9.46,2 12,2A5.5,5.5 0 0,1 17.5,7.5L17.42,8.45C17.88,8.16 18.42,8 19,8A3,3 0 0,1 22,11A3,3 0 0,1 19,14H6A4,4 0 0,1 2,10A4,4 0 0,1 6,6M6,8A2,2 0 0,0 4,10A2,2 0 0,0 6,12H19A1,1 0 0,0 20,11A1,1 0 0,0 19,10H15.5V7.5A3.5,3.5 0 0,0 12,4A3.5,3.5 0 0,0 8.5,7.5V8H6M18,18H4A1,1 0 0,1 3,17A1,1 0 0,1 4,16H18A3,3 0 0,1 21,19A3,3 0 0,1 18,22C17.17,22 16.42,21.66 15.88,21.12C15.5,20.73 15.5,20.1 15.88,19.71C16.27,19.32 16.9,19.32 17.29,19.71C17.47,19.89 17.72,20 18,20A1,1 0 0,0 19,19A1,1 0 0,0 18,18Z",
    "exceptional":     "M11,15H13V17H11V15M11,7H13V13H11V7M12,2C6.47,2 2,6.5 2,12A10,10 0 0,0 12,22A10,10 0 0,0 22,12A10,10 0 0,0 12,2M12,20A8,8 0 0,1 4,12A8,8 0 0,1 12,4A8,8 0 0,1 20,12A8,8 0 0,1 12,20Z",
  };
  const _NDL_COND_DEFAULT = _NDL_COND_PATHS["cloudy"];

  function _ndlCondSvg(condition, size, color) {
    const d = _NDL_COND_PATHS[condition] ?? _NDL_COND_DEFAULT;
    const fill = color ? ` style="color:${color}"` : "";
    return `<svg viewBox="0 0 24 24" width="${size}" height="${size}" aria-hidden="true" focusable="false"${fill}><path d="${d}" fill="currentColor"/></svg>`;
  }

  const _NDL_SHORT_DAYS = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];

  const WEATHER_STYLES = /* css */`
    ${NODALIA_BASE}

    /* Weather icon: condition-tinted background + dark glyph */
    [part=card][data-state="on"] [part=card-icon].ndl-weather-icon {
      background: color-mix(in srgb,
                  var(--ndl-accent, var(--hrv-color-accent, #4dabf7)) 38%,
                  color-mix(in srgb, var(--hrv-color-text, #1a1a2e) 8%, transparent));
    }
    [part=card][data-state="on"] [part=card-icon].ndl-weather-icon svg {
      color: var(--ndl-fg, var(--hrv-color-text, #1a1a2e));
      opacity: 1;
    }

    @keyframes ndl-chip-pop {
      0%   { transform: scale(0.7); opacity: 0; }
      70%  { transform: scale(1.05); }
      100% { transform: scale(1);   opacity: 1; }
    }

    [part=card-header] {
      grid-template-columns: 58px minmax(0, 1fr) auto !important;
    }

    [part=card-body] {
      display: flex;
      flex-direction: column;
      gap: 12px;
      min-width: 0;
    }

    /* Hero zone: temp number with attached unit, condition stacked below */
    .ndl-weather-hero {
      display: flex;
      flex-direction: column;
      gap: 4px;
      min-width: 0;
    }

    .ndl-weather-temp-line {
      display: inline-flex;
      align-items: baseline;
      line-height: 1;
    }

    .ndl-weather-num {
      font-size: 44px;
      font-weight: 700;
      color: var(--ndl-fg, var(--hrv-color-text, #1a1a2e));
      letter-spacing: -0.02em;
      line-height: 1;
    }

    .ndl-weather-unit {
      font-size: 22px;
      font-weight: 600;
      color: var(--ndl-fg, var(--hrv-color-text, #1a1a2e));
      opacity: 0.7;
      margin-left: 1px;
    }

    .ndl-weather-cond {
      font-size: 15px;
      font-weight: 500;
      color: var(--ndl-fg, var(--hrv-color-text, #1a1a2e));
      opacity: 0.75;
      text-transform: capitalize;
    }

    /* Stat chips in the header right column */
    .ndl-weather-chips {
      display: flex;
      flex-wrap: wrap;
      gap: 6px;
      justify-content: flex-end;
      max-width: 100%;
    }

    .ndl-weather-chip {
      display: inline-flex;
      align-items: center;
      gap: 5px;
      padding: 5px 12px;
      border-radius: 20px;
      background: color-mix(in srgb, var(--hrv-color-text, #1a1a2e) 6%, transparent);
      border: 1px solid color-mix(in srgb,
                  var(--ndl-accent, var(--hrv-color-accent, #4dabf7)) 18%,
                  color-mix(in srgb, var(--hrv-color-text, #1a1a2e) 8%, transparent));
      font-size: 12px;
      font-weight: 600;
      color: var(--ndl-fg, var(--hrv-color-text, #1a1a2e));
      animation: ndl-chip-pop 0.35s ease both;
      white-space: nowrap;
    }

    .ndl-weather-chip svg {
      color: var(--ndl-accent, var(--hrv-color-accent, #4dabf7));
      opacity: 1;
    }

    /* Forecast period toggle: segmented Hours | Week */
    .ndl-forecast-toolbar {
      display: flex;
      justify-content: flex-end;
      gap: 8px;
    }
    .ndl-forecast-tabs {
      display: inline-flex;
      padding: 3px;
      background: color-mix(in srgb, var(--hrv-color-text, #1a1a2e) 6%, transparent);
      border: 1px solid color-mix(in srgb, var(--hrv-color-text, #1a1a2e) 8%, transparent);
      border-radius: 999px;
      gap: 2px;
    }
    .ndl-forecast-tab {
      appearance: none;
      border: none;
      background: transparent;
      padding: 6px 16px;
      font-size: 12px;
      font-weight: 700;
      font-family: inherit;
      color: var(--ndl-fg, var(--hrv-color-text, #1a1a2e));
      opacity: 0.75;
      cursor: pointer;
      border-radius: 999px;
      transition: background 0.18s ease, opacity 0.18s ease;
    }
    .ndl-forecast-tab:hover { opacity: 1; }
    .ndl-forecast-tab[aria-selected="true"] {
      background: color-mix(in srgb,
                  var(--ndl-accent, var(--hrv-color-accent, #4dabf7)) 22%,
                  color-mix(in srgb, var(--hrv-color-text, #1a1a2e) 4%, transparent));
      opacity: 1;
    }
    .ndl-forecast-tab[hidden] { display: none; }
    .ndl-forecast-toolbar[hidden] { display: none; }

    /* Forecast strip: hourly mode scrolls horizontally; daily mode fills width */
    .ndl-forecast-strip {
      display: flex;
      gap: 8px;
      padding: 4px 0 6px;
      width: 100%;
      min-width: 0;
      user-select: none;
    }
    .ndl-forecast-strip[data-mode=hourly] {
      overflow-x: auto;
      overflow-y: hidden;
      -webkit-overflow-scrolling: touch;
      touch-action: pan-x;
      scrollbar-width: none;
      cursor: grab;
    }
    .ndl-forecast-strip[data-mode=hourly]::-webkit-scrollbar { display: none; }
    .ndl-forecast-strip[data-mode=hourly]:active { cursor: grabbing; }
    .ndl-forecast-strip[data-mode=daily] {
      justify-content: space-between;
      overflow: hidden;
    }
    .ndl-forecast-strip:empty { display: none; }
    .ndl-forecast-strip[data-dragging="true"] * { pointer-events: none; }

    .ndl-forecast-scroll-track {
      width: 100%;
      align-self: stretch;
      height: 4px;
      border-radius: 4px;
      background: color-mix(in srgb, var(--hrv-color-text, #1a1a2e) 10%, transparent);
      position: relative;
      cursor: pointer;
    }
    .ndl-forecast-scroll-track[hidden] { display: none; }
    .ndl-forecast-scroll-thumb {
      position: absolute;
      top: 0;
      height: 100%;
      border-radius: 4px;
      background: color-mix(in srgb,
                  var(--ndl-accent, var(--hrv-color-accent, #4dabf7)) 60%,
                  color-mix(in srgb, var(--hrv-color-text, #1a1a2e) 30%, transparent));
      transition: left 80ms linear;
      cursor: grab;
      user-select: none;
    }
    .ndl-forecast-scroll-thumb:active { cursor: grabbing; }

    /* Forecast cards: time, icon, temp, condition, optional precip */
    .ndl-forecast-day {
      display: flex;
      flex-direction: column;
      align-items: center;
      gap: 6px;
      padding: 12px 10px;
      border-radius: 18px;
      background: color-mix(in srgb, var(--hrv-color-text, #1a1a2e) 6%, transparent);
      border: 1px solid color-mix(in srgb,
                  var(--ndl-accent, var(--hrv-color-accent, #4dabf7)) 16%,
                  color-mix(in srgb, var(--hrv-color-text, #1a1a2e) 8%, transparent));
      animation: ndl-fade-up 0.35s cubic-bezier(0.22, 0.84, 0.26, 1) both;
      min-width: 0;
      box-sizing: border-box;
    }
    .ndl-forecast-strip[data-mode=hourly] .ndl-forecast-day {
      min-width: 88px;
      flex: 0 0 auto;
    }
    .ndl-forecast-strip[data-mode=daily] .ndl-forecast-day {
      flex: 1 1 0;
    }

    .ndl-forecast-day-name {
      font-size: 12px;
      font-weight: 700;
      color: var(--ndl-fg, var(--hrv-color-text, #1a1a2e));
      opacity: 0.85;
      text-transform: uppercase;
      letter-spacing: 0.04em;
    }

    .ndl-forecast-day-icon svg {
      color: var(--ndl-accent, var(--hrv-color-accent, #4dabf7));
      width: 28px;
      height: 28px;
      display: block;
    }

    .ndl-forecast-day-temp {
      font-size: 18px;
      font-weight: 700;
      color: var(--ndl-fg, var(--hrv-color-text, #1a1a2e));
      line-height: 1;
    }
    .ndl-forecast-day-templow {
      font-size: 11px;
      font-weight: 500;
      opacity: 0.55;
    }

    .ndl-forecast-day-cond {
      font-size: 11px;
      font-weight: 500;
      color: var(--ndl-fg, var(--hrv-color-text, #1a1a2e));
      opacity: 0.75;
      text-transform: capitalize;
      max-width: 100%;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }

    .ndl-forecast-day-precip {
      display: inline-flex;
      align-items: center;
      gap: 4px;
      font-size: 11px;
      font-weight: 600;
      color: var(--ndl-accent, var(--hrv-color-accent, #4dabf7));
      opacity: 0.95;
    }
    .ndl-forecast-day-precip svg {
      color: currentColor;
      width: 12px;
      height: 12px;
    }

    /* Compact + mini layout adjustments */
    [part=card].ndl-compact .ndl-weather-num { font-size: 36px; }
    [part=card].ndl-compact .ndl-weather-cond { font-size: 13px; }
    [part=card].ndl-compact .ndl-forecast-day { min-width: 72px; padding: 10px 8px; }
    [part=card].ndl-mini .ndl-weather-chips,
    [part=card].ndl-mini .ndl-forecast-toolbar,
    [part=card].ndl-mini .ndl-forecast-strip,
    [part=card].ndl-mini .ndl-forecast-scroll-track { display: none; }
    [part=card].ndl-mini .ndl-weather-num { font-size: 28px; }
    [part=card].ndl-mini .ndl-weather-cond { font-size: 12px; }
  `;

  class WeatherCard extends BaseCard {
    /** @type {HTMLElement|null} */ #card            = null;
    /** @type {HTMLElement|null} */ #numEl           = null;
    /** @type {HTMLElement|null} */ #unitEl          = null;
    /** @type {HTMLElement|null} */ #condEl          = null;
    /** @type {HTMLElement|null} */ #humidityEl      = null;
    /** @type {HTMLElement|null} */ #windEl          = null;
    /** @type {HTMLElement|null} */ #pressureEl      = null;
    /** @type {HTMLElement|null} */ #forecastEl      = null;
    /** @type {HTMLElement|null} */ #toolbarEl       = null;
    /** @type {HTMLElement|null} */ #hourlyTabEl     = null;
    /** @type {HTMLElement|null} */ #dailyTabEl      = null;
    /** @type {HTMLElement|null} */ #scrollTrackEl   = null;
    /** @type {HTMLElement|null} */ #scrollThumbEl   = null;
    #layoutTeardown = null;
    get #forecastMode() { return this.config._forecastMode ?? "daily"; }
    set #forecastMode(v) { this.config._forecastMode = v; }
    #forecastDaily  = null;
    #forecastHourly = null;
    #lastAccent = "#4dabf7";
    #dragCleanup = null;

    static #HUMIDITY_PATH = "M12,3.77L11.25,4.61C11.25,4.61 9.97,6.06 8.68,7.94C7.39,9.82 6,12.07 6,14.23A6,6 0 0,0 12,20.23A6,6 0 0,0 18,14.23C18,12.07 16.61,9.82 15.32,7.94C14.03,6.06 12.75,4.61 12.75,4.61L12,3.77M12,1A1,1 0 0,1 13,2L13,2.01C13,2.01 14.35,3.56 15.72,5.55C17.09,7.54 18.5,9.93 18.5,12.5A6.5,6.5 0 0,1 12,19A6.5,6.5 0 0,1 5.5,12.5C5.5,9.93 6.91,7.54 8.28,5.55C9.65,3.56 11,2.01 11,2.01L11,2A1,1 0 0,1 12,1Z";
    static #WIND_PATH     = "M4,10A1,1 0 0,1 3,9A1,1 0 0,1 4,8H12A2,2 0 0,0 14,6A2,2 0 0,0 12,4C11.45,4 10.95,4.22 10.59,4.59C10.2,5 9.56,5 9.17,4.59C8.78,4.2 8.78,3.56 9.17,3.17C9.9,2.45 10.9,2 12,2A4,4 0 0,1 16,6A4,4 0 0,1 12,10H4M19,12A1,1 0 0,0 20,11A1,1 0 0,0 19,10C18.72,10 18.47,10.11 18.29,10.29C17.9,10.68 17.27,10.68 16.88,10.29C16.5,9.9 16.5,9.27 16.88,8.88C17.42,8.34 18.17,8 19,8A3,3 0 0,1 22,11A3,3 0 0,1 19,14H5A1,1 0 0,1 4,13A1,1 0 0,1 5,12H19M18,18H4A1,1 0 0,1 3,17A1,1 0 0,1 4,16H18A3,3 0 0,1 21,19A3,3 0 0,1 18,22C17.17,22 16.42,21.66 15.88,21.12C15.5,20.73 15.5,20.1 15.88,19.71C16.27,19.32 16.9,19.32 17.29,19.71C17.47,19.89 17.72,20 18,20A1,1 0 0,0 19,19A1,1 0 0,0 18,18Z";
    static #PRESSURE_PATH = "M12,2A10,10 0 0,0 2,12A10,10 0 0,0 12,22A10,10 0 0,0 22,12A10,10 0 0,0 12,2M12,4A8,8 0 0,1 20,12C20,14.4 19,16.5 17.3,18C15.9,16.7 14,16 12,16C10,16 8.2,16.7 6.7,18C5,16.5 4,14.4 4,12A8,8 0 0,1 12,4M14,5.89C13.62,5.9 13.26,6.15 13.1,6.54L11.58,10C10.6,10.18 9.81,10.79 9.4,11.6L6.27,11.29C5.82,11.25 5.4,11.54 5.29,11.97C5.18,12.41 5.4,12.86 5.82,13.04L8.88,14.31C9.16,15.29 9.93,16.08 10.92,16.35L11.28,19.39C11.33,19.83 11.7,20.16 12.14,20.16C12.18,20.16 12.22,20.16 12.27,20.15C12.75,20.09 13.1,19.66 13.04,19.18L12.68,16.19C13.55,15.8 14.15,14.96 14.21,14H17.58C18.05,14 18.44,13.62 18.44,13.14C18.44,12.67 18.05,12.29 17.58,12.29H14.21C14.15,11.74 13.93,11.24 13.59,10.84L15.07,7.42C15.27,6.97 15.07,6.44 14.63,6.24C14.43,6 14.21,5.88 14,5.89Z";

    static #chipSvg(path) {
      return `<svg viewBox="0 0 24 24" width="12" height="12" aria-hidden="true" focusable="false"><path d="${path}" fill="currentColor"/></svg>`;
    }

    render() {
      this.root.innerHTML = /* html */`
        <style>${WEATHER_STYLES}${COMPANION_DOT_STYLES}${NDL_ROW_CSS}</style>
        <div part="card" class="ndl-weather-card">
          <div part="card-header">
            <span part="card-icon" class="ndl-weather-icon" aria-hidden="true"></span>
            <span part="card-name">${_esc(this.def.friendly_name)}</span>
            <div class="ndl-weather-chips" role="group" aria-label="Conditions">
              <span class="ndl-weather-chip" data-stat="humidity">
                ${WeatherCard.#chipSvg(WeatherCard.#HUMIDITY_PATH)}
                <span data-value>--</span>
              </span>
              <span class="ndl-weather-chip" data-stat="wind" style="animation-delay:60ms">
                ${WeatherCard.#chipSvg(WeatherCard.#WIND_PATH)}
                <span data-value>--</span>
              </span>
              <span class="ndl-weather-chip" data-stat="pressure" style="animation-delay:120ms">
                ${WeatherCard.#chipSvg(WeatherCard.#PRESSURE_PATH)}
                <span data-value>--</span>
              </span>
            </div>
          </div>
          <div part="card-body">
            <div class="ndl-weather-hero">
              <div class="ndl-weather-temp-line">
                <span class="ndl-weather-num" aria-live="polite">--</span><span class="ndl-weather-unit"></span>
              </div>
              <span class="ndl-weather-cond">--</span>
            </div>
            <div class="ndl-forecast-toolbar" hidden>
              <div class="ndl-forecast-tabs" role="tablist">
                <button class="ndl-forecast-tab" type="button" data-tab="hourly" role="tab" aria-selected="false" hidden>Hourly</button>
                <button class="ndl-forecast-tab" type="button" data-tab="daily"  role="tab" aria-selected="true">5-Day</button>
              </div>
            </div>
            <div class="ndl-forecast-strip" data-mode="daily" role="list" aria-label="Forecast"></div>
            <div class="ndl-forecast-scroll-track" hidden><div class="ndl-forecast-scroll-thumb"></div></div>
          </div>
          ${this.renderHistoryZoneHTML()}
          ${this.renderAriaLiveHTML()}
          ${this.renderCompanionZoneHTML()}
          <div part="stale-indicator" aria-hidden="true"></div>
        </div>
      `;

      this.#card          = this.root.querySelector("[part=card]");
      this.#numEl         = this.root.querySelector(".ndl-weather-num");
      this.#unitEl        = this.root.querySelector(".ndl-weather-unit");
      this.#condEl        = this.root.querySelector(".ndl-weather-cond");
      this.#humidityEl    = this.root.querySelector("[data-stat=humidity] [data-value]");
      this.#windEl        = this.root.querySelector("[data-stat=wind] [data-value]");
      this.#pressureEl    = this.root.querySelector("[data-stat=pressure] [data-value]");
      this.#forecastEl    = this.root.querySelector(".ndl-forecast-strip");
      this.#toolbarEl     = this.root.querySelector(".ndl-forecast-toolbar");
      this.#hourlyTabEl   = this.root.querySelector('.ndl-forecast-tab[data-tab="hourly"]');
      this.#dailyTabEl    = this.root.querySelector('.ndl-forecast-tab[data-tab="daily"]');
      this.#scrollTrackEl = this.root.querySelector(".ndl-forecast-scroll-track");
      this.#scrollThumbEl = this.root.querySelector(".ndl-forecast-scroll-thumb");

      // Tab clicks switch the forecast mode.
      this.#hourlyTabEl?.addEventListener("click", () => this.#setMode("hourly"));
      this.#dailyTabEl?.addEventListener("click", () => this.#setMode("daily"));

      if (this.#forecastEl) {
        this.#forecastEl.addEventListener("scroll", () => this.#syncScrollThumb(), { passive: true });
        this.#installDragScroll(this.#forecastEl);
      }
      if (this.#scrollTrackEl) {
        this.#scrollTrackEl.addEventListener("pointerdown", (e) => this.#onTrackPointerDown(e));
      }

      // Default accent (used until first state arrives).
      if (this.#card) {
        this.#card.dataset.state = "on";
        this.#card.style.setProperty("--ndl-accent", _COND_COLORS_DEFAULT.accent);
      }
      this.renderIcon(this.resolveIcon(this.def.icon, "mdi:weather-cloudy"), "card-icon");
      this.renderCompanions();
      _applyCompanionTooltips(this.root);
      this.#layoutTeardown = _layoutObserver(this);
    }

    #setMode(mode) {
      if (this.#forecastMode === mode) return;
      this.#forecastMode = mode;
      this.#syncTabState();
      this.#renderActiveForecast(this.#lastAccent);
    }

    #syncTabState() {
      if (this.#hourlyTabEl) this.#hourlyTabEl.setAttribute("aria-selected", String(this.#forecastMode === "hourly"));
      if (this.#dailyTabEl)  this.#dailyTabEl.setAttribute("aria-selected",  String(this.#forecastMode === "daily"));
    }

    /**
     * Install pointer-based drag scrolling on a horizontal scroll container,
     * with momentum (gentle ease-out) on release.
     */
    #installDragScroll(strip) {
      // Velocity is computed from the last SAMPLE_WINDOW ms of pointer motion
      // and multiplied by VELOCITY_BOOST so a quick flick produces a snappy
      // fling. Decay is per-tick (~16ms): higher = longer coast.
      const SAMPLE_WINDOW = 80;
      const VELOCITY_BOOST = 1.6;
      const DECAY = 0.96;
      const MIN_VEL = 0.04;

      let pointerId = null;
      let startX = 0;
      let startScroll = 0;
      let velocity = 0;        // px / ms
      let moved = false;
      let momentumRaf = 0;
      const samples = [];

      const stopMomentum = () => {
        if (momentumRaf) { cancelAnimationFrame(momentumRaf); momentumRaf = 0; }
      };

      const computeReleaseVelocity = (now) => {
        while (samples.length && samples[0].t < now - SAMPLE_WINDOW) samples.shift();
        if (samples.length < 2) return 0;
        const first = samples[0];
        const last  = samples[samples.length - 1];
        const dt = last.t - first.t;
        if (dt <= 0) return 0;
        return (last.x - first.x) / dt;
      };

      const startMomentum = () => {
        if (Math.abs(velocity) < MIN_VEL) return;
        let prev = performance.now();
        const tick = (now) => {
          const dt = now - prev; prev = now;
          strip.scrollLeft -= velocity * dt;
          velocity *= Math.pow(DECAY, dt / 16);
          if (Math.abs(velocity) < MIN_VEL) { momentumRaf = 0; velocity = 0; return; }
          const max = strip.scrollWidth - strip.clientWidth;
          if (strip.scrollLeft <= 0 || strip.scrollLeft >= max) { momentumRaf = 0; velocity = 0; return; }
          momentumRaf = requestAnimationFrame(tick);
        };
        momentumRaf = requestAnimationFrame(tick);
      };

      const onDown = (e) => {
        if (strip.scrollWidth <= strip.clientWidth) return;
        if (e.pointerType === "touch") return;
        const t = e.target;
        if (t && t !== strip && t.closest?.("button, a")) return;
        stopMomentum();
        pointerId = e.pointerId;
        startX = e.clientX;
        startScroll = strip.scrollLeft;
        velocity = 0;
        moved = false;
        samples.length = 0;
        samples.push({ x: e.clientX, t: e.timeStamp });
        try { strip.setPointerCapture(pointerId); } catch { /* ignore */ }
      };
      const onMove = (e) => {
        if (e.pointerId !== pointerId) return;
        const dx = e.clientX - startX;
        if (Math.abs(dx) > 4) { moved = true; strip.dataset.dragging = "true"; }
        strip.scrollLeft = startScroll - dx;
        samples.push({ x: e.clientX, t: e.timeStamp });
        const cutoff = e.timeStamp - SAMPLE_WINDOW;
        while (samples.length > 2 && samples[0].t < cutoff) samples.shift();
      };
      const onUp = (e) => {
        if (e.pointerId !== pointerId) return;
        try { strip.releasePointerCapture(pointerId); } catch { /* ignore */ }
        pointerId = null;
        if (moved) {
          const click = (ev) => { ev.stopPropagation(); ev.preventDefault(); };
          window.addEventListener("click", click, { capture: true, once: true });
          requestAnimationFrame(() => strip.removeAttribute("data-dragging"));
          velocity = computeReleaseVelocity(e.timeStamp) * VELOCITY_BOOST;
          startMomentum();
        }
        samples.length = 0;
      };
      strip.addEventListener("pointerdown",   onDown);
      strip.addEventListener("pointermove",   onMove);
      strip.addEventListener("pointerup",     onUp);
      strip.addEventListener("pointercancel", onUp);
      // Stop momentum if the user starts a wheel/touch interaction.
      strip.addEventListener("wheel",     stopMomentum, { passive: true });
      strip.addEventListener("touchstart", stopMomentum, { passive: true });

      this.#dragCleanup = () => {
        stopMomentum();
        strip.removeEventListener("pointerdown",   onDown);
        strip.removeEventListener("pointermove",   onMove);
        strip.removeEventListener("pointerup",     onUp);
        strip.removeEventListener("pointercancel", onUp);
        strip.removeEventListener("wheel",         stopMomentum);
        strip.removeEventListener("touchstart",    stopMomentum);
      };
    }

    applyState(state, attributes) {
      const condition = state || "cloudy";
      const isAvailable = state !== "unavailable" && state !== "unknown";
      const colors = _condColors(condition);
      this.#lastAccent = colors.accent;

      if (this.#card) {
        this.#card.dataset.state = isAvailable ? "on" : "off";
        if (isAvailable) {
          this.#card.style.setProperty("--ndl-accent", colors.accent);
        } else {
          this.#card.style.removeProperty("--ndl-accent");
        }
      }

      const condLabel = this.i18n.t(`weather.${condition}`) !== `weather.${condition}`
        ? this.i18n.t(`weather.${condition}`)
        : condition.replace(/-/g, " ");
      if (this.#condEl) this.#condEl.textContent = condLabel;

      const temp = attributes.temperature ?? attributes.native_temperature;
      // Default to "°C" when no unit is exposed by the entity (matches Daniel's
      // upstream behaviour). Bare "C"/"F" gets the degree prepended.
      let tempUnit = String(
        attributes.temperature_unit
        || attributes.native_temperature_unit
        || this.def.unit_of_measurement
        || "°C"
      ).trim();
      if (tempUnit && !/^°/.test(tempUnit) && tempUnit.length <= 2) {
        tempUnit = `°${tempUnit}`;
      }
      if (this.#numEl) {
        const num = temp != null ? Number(temp) : null;
        this.#numEl.textContent = (num != null && Number.isFinite(num))
          ? (Number.isInteger(num) ? String(num) : num.toFixed(1))
          : "--";
      }
      if (this.#unitEl) this.#unitEl.textContent = tempUnit;

      if (this.#humidityEl) {
        const h = attributes.humidity;
        this.#humidityEl.textContent = h != null ? `${h}%` : "--";
      }
      if (this.#windEl) {
        const w = attributes.wind_speed;
        const wu = attributes.wind_speed_unit ?? "";
        this.#windEl.textContent = w != null ? `${w} ${wu}`.trim() : "--";
      }
      if (this.#pressureEl) {
        const p = attributes.pressure;
        const pu = attributes.pressure_unit ?? "";
        this.#pressureEl.textContent = p != null ? `${p} ${pu}`.trim() : "--";
      }

      this.renderIcon(this.resolveIcon(this.def.icon, "mdi:weather-cloudy"), "card-icon");

      const show = (this.config.displayHints ?? this.def.display_hints ?? {}).show_forecast === true;
      this.#forecastDaily  = show ? (attributes.forecast_daily  ?? attributes.forecast ?? null) : null;
      this.#forecastHourly = show ? (attributes.forecast_hourly ?? null) : null;

      this.#syncForecastVisibility();
      this.#renderActiveForecast(colors.accent);

      this.announceState(
        `${this.def.friendly_name}, ${condLabel}, ${temp != null ? temp : "--"}${tempUnit}`,
      );
    }

    /** Show/hide the toolbar and tabs based on which forecast types are available. */
    #syncForecastVisibility() {
      const hasDaily  = Array.isArray(this.#forecastDaily)  && this.#forecastDaily.length > 0;
      const hasHourly = Array.isArray(this.#forecastHourly) && this.#forecastHourly.length > 0;

      if (this.#hourlyTabEl) this.#hourlyTabEl.hidden = !hasHourly;
      if (this.#dailyTabEl)  this.#dailyTabEl.hidden  = !hasDaily;
      if (this.#toolbarEl)   this.#toolbarEl.hidden   = !(hasDaily || hasHourly) || !(hasDaily && hasHourly);

      // Pick a sensible default mode if the current one has no data.
      if (this.#forecastMode === "hourly" && !hasHourly && hasDaily) this.#forecastMode = "daily";
      if (this.#forecastMode === "daily"  && !hasDaily  && hasHourly) this.#forecastMode = "hourly";
      this.#syncTabState();
    }

    #renderActiveForecast(accent) {
      if (!this.#forecastEl) return;
      const data = this.#forecastMode === "hourly" ? this.#forecastHourly : this.#forecastDaily;
      this.#forecastEl.setAttribute("data-mode", this.#forecastMode);

      if (!Array.isArray(data) || data.length === 0) {
        this.#forecastEl.innerHTML = "";
        if (this.#scrollTrackEl) this.#scrollTrackEl.hidden = true;
        return;
      }

      const items = this.#forecastMode === "daily" ? data.slice(0, 5) : data.slice(0, 24);
      this.#forecastEl.innerHTML = items.map((entry, i) => {
        const dt = new Date(entry.datetime);
        let label;
        if (this.#forecastMode === "hourly") {
          label = dt.toLocaleTimeString([], { hour: "numeric", minute: "2-digit" });
        } else {
          label = _NDL_SHORT_DAYS[dt.getDay()] ?? "";
        }
        const hi  = (entry.temperature ?? entry.native_temperature);
        const lo  = (entry.templow ?? entry.native_templow);
        const cnd = entry.condition || "cloudy";
        const cndLabel = this.i18n.t(`weather.${cnd}`) !== `weather.${cnd}` ? this.i18n.t(`weather.${cnd}`) : cnd.replace(/-/g, " ");
        const precip = entry.precipitation ?? entry.native_precipitation;
        const precipUnit = entry.precipitation_unit ?? "mm";
        const iconSvg = _ndlCondSvg(cnd, 28, accent ?? null);

        const hiStr = hi != null && Number.isFinite(Number(hi))
          ? `${Math.round(Number(hi))}°` : "--";
        const loStr = lo != null && Number.isFinite(Number(lo))
          ? `${Math.round(Number(lo))}°` : null;

        return /* html */`
          <div class="ndl-forecast-day" role="listitem" style="animation-delay:${Math.min(i, 8) * 50}ms">
            <span class="ndl-forecast-day-name">${_esc(String(label))}</span>
            <div class="ndl-forecast-day-icon" aria-hidden="true">${iconSvg}</div>
            <div class="ndl-forecast-day-temp">${_esc(String(hiStr))}</div>
            ${loStr ? `<div class="ndl-forecast-day-templow">${_esc(loStr)}</div>` : ""}
            <span class="ndl-forecast-day-cond" title="${_esc(cndLabel)}">${_esc(cndLabel)}</span>
            ${precip != null && Number.isFinite(Number(precip)) && Number(precip) > 0
              ? `<span class="ndl-forecast-day-precip">${_ndlCondSvg("rainy", 12, null)} ${_esc(`${Number(precip)} ${precipUnit}`.trim())}</span>`
              : ""}
          </div>`;
      }).join("");

      requestAnimationFrame(() => this.#syncScrollThumb());
    }

    #syncScrollThumb() {
      const strip = this.#forecastEl;
      const track = this.#scrollTrackEl;
      const thumb = this.#scrollThumbEl;
      if (!strip || !track || !thumb) return;
      const ratio = strip.scrollWidth > strip.clientWidth
        ? strip.clientWidth / strip.scrollWidth
        : 1;
      if (ratio >= 1) {
        track.hidden = true;
        return;
      }
      track.hidden = false;
      const trackW = track.clientWidth;
      const thumbW = Math.max(24, ratio * trackW);
      const maxLeft = trackW - thumbW;
      const scrollRatio = strip.scrollLeft / (strip.scrollWidth - strip.clientWidth);
      thumb.style.width = `${thumbW}px`;
      thumb.style.left  = `${scrollRatio * maxLeft}px`;
    }

    #onTrackPointerDown(e) {
      const strip = this.#forecastEl;
      const track = this.#scrollTrackEl;
      const thumb = this.#scrollThumbEl;
      if (!strip || !track || !thumb) return;
      e.preventDefault();
      const trackRect = track.getBoundingClientRect();
      const thumbW = parseFloat(thumb.style.width) || 24;

      const scrollTo = (clientX) => {
        const relX = clientX - trackRect.left - thumbW / 2;
        const maxLeft = trackRect.width - thumbW;
        const ratio = Math.max(0, Math.min(1, relX / maxLeft));
        strip.scrollLeft = ratio * (strip.scrollWidth - strip.clientWidth);
      };

      scrollTo(e.clientX);

      const onMove = (ev) => scrollTo(ev.clientX);
      const onUp   = () => {
        window.removeEventListener("pointermove", onMove);
        window.removeEventListener("pointerup",   onUp);
      };
      window.addEventListener("pointermove", onMove);
      window.addEventListener("pointerup",   onUp);
    }

    destroy() {
      if (this.#layoutTeardown) { this.#layoutTeardown(); this.#layoutTeardown = null; }
      if (this.#dragCleanup)    { this.#dragCleanup();    this.#dragCleanup    = null; }
    }
  }

  // ---------------------------------------------------------------------------
  // Badge card
  // ---------------------------------------------------------------------------

  const _BADGE_ICON_COLORS = {
    auto: "var(--hrv-color-primary)",
    red: "#ef4444", orange: "#f97316", amber: "#f59e0b", yellow: "#eab308",
    green: "#22c55e", teal: "#14b8a6", cyan: "#06b6d4", blue: "#3b82f6",
    indigo: "#6366f1", purple: "#a855f7", pink: "#ec4899", grey: "#9ca3af",
  };

  // States considered "off" for active/inactive treatment. Only meaningful
  // for domains where state has on/off semantics (light, switch, fan, cover,
  // climate, etc.). For informational domains (sensor, input_number,
  // input_select, weather), the state is data, not an on/off signal - those
  // domains are always treated as active unless the entity is unavailable.
  const _BADGE_INACTIVE = new Set([
    "off", "idle", "closed", "standby", "not_home",
    "locked", "jammed", "locking", "unlocking",
  ]);
  const _BADGE_UNAVAILABLE = new Set(["unavailable", "unknown"]);
  const _BADGE_ONOFF_DOMAINS = new Set([
    "light", "switch", "input_boolean", "fan", "climate", "cover",
    "media_player", "timer", "person", "device_tracker", "lock",
    "binary_sensor",
  ]);

  const _BADGE_DOMAIN_FB = {
    light:"mdi:lightbulb",switch:"mdi:toggle-switch",input_boolean:"mdi:toggle-switch",
    fan:"mdi:fan",sensor:"mdi:gauge",binary_sensor:"mdi:radiobox-blank",
    climate:"mdi:thermostat",media_player:"mdi:cast",cover:"mdi:window-shutter",
    timer:"mdi:timer",remote:"mdi:remote",input_number:"mdi:numeric",
    input_select:"mdi:format-list-bulleted",select:"mdi:format-list-bulleted",
    harvest_action:"mdi:play-circle-outline",
  };

  const BADGE_STYLES = /* css */`
    /* :host overrides per the converting-doc badge rules. min-width:unset and
       contain:none are required so the inline-flex pill collapses to its
       content width inside the host's layout, instead of inheriting the
       full-card 300px sizing from the shared base styles. */
    :host {
      width: auto !important;
      min-width: unset !important;
      display: inline-flex !important;
      contain: none !important;
      vertical-align: top !important;
      overflow: visible !important;
      line-height: 0 !important;
      padding: 0 !important;
      margin: 0 !important;
    }
    [part=badge] {
      display: inline-flex;
      align-items: center;
      gap: 8px;
      padding: 6px 14px 6px 8px;
      border-radius: 999px;
      background: linear-gradient(135deg,
                  color-mix(in srgb, var(--hrv-color-text, #1a1a2e) 4%, var(--hrv-color-surface, #ffffff)) 0%,
                  var(--hrv-color-surface, #ffffff) 100%);
      border: 1px solid color-mix(in srgb, var(--hrv-color-text, #1a1a2e) 8%, transparent);
      box-shadow: inset 0 1px 0 color-mix(in srgb, #ffffff 40%, transparent);
      font-family: var(--hrv-font-family, system-ui, -apple-system, sans-serif);
      color: var(--hrv-color-text, #1a1a2e);
      box-sizing: border-box;
      white-space: nowrap;
      overflow: hidden;
      cursor: default;
      transition: background 220ms ease, border-color 220ms ease;
      max-width: 100%;
    }
    [part=badge][data-state="active"] {
      background: linear-gradient(135deg,
                  color-mix(in srgb, var(--ndl-badge-color, var(--hrv-color-primary, #6366f1)) 12%, var(--hrv-color-surface, #ffffff)) 0%,
                  var(--hrv-color-surface, #ffffff) 100%);
      border-color: color-mix(in srgb, var(--ndl-badge-color, var(--hrv-color-primary, #6366f1)) 30%, transparent);
    }
    [part=badge-icon] {
      width: 28px;
      height: 28px;
      flex-shrink: 0;
      border-radius: 999px;
      display: inline-flex;
      align-items: center;
      justify-content: center;
      background: color-mix(in srgb, var(--hrv-color-text, #1a1a2e) 6%, transparent);
      transition: background 220ms ease, color 220ms ease;
    }
    [part=badge][data-state="active"] [part=badge-icon] {
      background: color-mix(in srgb, var(--ndl-badge-color, var(--hrv-color-primary, #6366f1)) 22%,
                  color-mix(in srgb, var(--hrv-color-text, #1a1a2e) 6%, transparent));
    }
    /* Icon colour: when --ndl-badge-color is set (user picked a specific
       color), it wins regardless of active/inactive. Inactive state still
       differentiates visually via reduced opacity. When unset, fall back to
       the theme's text colour for inactive, primary for active. */
    [part=badge-icon] svg {
      width: 18px;
      height: 18px;
      color: var(--ndl-badge-color, var(--hrv-color-text, #1a1a2e));
      opacity: 0.7;
    }
    [part=badge][data-state="active"] [part=badge-icon] svg {
      color: var(--ndl-badge-color, var(--hrv-color-primary, #6366f1));
      opacity: 1;
    }
    [part=badge-text] {
      display: flex;
      flex-direction: column;
      gap: 1px;
      min-width: 0;
    }
    [part=badge-name] {
      font-size: 11px;
      font-weight: 600;
      line-height: 1.3;
      overflow: hidden;
      text-overflow: ellipsis;
      max-width: 140px;
    }
    [part=badge-state] {
      font-size: 10px;
      line-height: 1.3;
      color: color-mix(in srgb, var(--hrv-color-text, #1a1a2e) 65%, transparent);
      overflow: hidden;
      text-overflow: ellipsis;
      max-width: 140px;
    }
    [part=badge-text].single [part=badge-name],
    [part=badge-text].single [part=badge-state] {
      font-size: 12px;
    }
    .sr-only {
      position: absolute;
      width: 1px; height: 1px;
      padding: 0; margin: -1px;
      overflow: hidden;
      clip: rect(0, 0, 0, 0);
      white-space: nowrap;
      border: 0;
    }
    @media (prefers-reduced-motion: reduce) {
      [part=badge],
      [part=badge-icon] { transition: none; }
    }
  `;

  class BadgeCard extends BaseCard {
    /** @type {HTMLElement|null} */ #iconEl = null;
    /** @type {HTMLElement|null} */ #stateEl = null;
    /** @type {HTMLElement|null} */ #badgeEl = null;

    render() {
      const hints = this.def.display_hints ?? {};
      const showIcon = hints.badge_show_icon !== false;
      const showName = hints.badge_show_name !== false;
      const showState = hints.badge_show_state !== false;
      const nameCls = showName ? "" : " sr-only";
      const stateCls = showState ? "" : " sr-only";
      const singleLine = (showName && !showState) || (!showName && showState);
      const textCls = singleLine ? " single" : "";
      this.root.innerHTML = /* html */`
        <style>${BADGE_STYLES}</style>
        <div part="badge" aria-label="${_esc(this.def.friendly_name)}" title="${_esc(this.def.friendly_name)}">
          ${showIcon ? '<span part="badge-icon" aria-hidden="true"></span>' : ""}
          <span part="badge-text" class="${textCls}">
            <span part="badge-name" class="${nameCls}">${_esc(this.def.friendly_name)}</span>
            <span part="badge-state" class="${stateCls}" aria-live="polite"></span>
          </span>
        </div>
        ${this.renderAriaLiveHTML()}
      `;
      this.#iconEl = this.root.querySelector("[part=badge-icon]");
      this.#stateEl = this.root.querySelector("[part=badge-state]");
      this.#badgeEl = this.root.querySelector("[part=badge]");
      if (showIcon) {
        const fb = _BADGE_DOMAIN_FB[this.def.domain] ?? "mdi:help-circle";
        this.renderIcon(this.resolveIcon(this.def.icon, fb), "badge-icon");
      }
    }

    applyState(state, attributes) {
      const hints = this.def.display_hints ?? {};
      const colorKey = hints.badge_icon_color ?? "auto";
      // Active = entity is reachable AND (informational domain OR not in
      // the on/off "inactive" set). input_select / sensor / input_number
      // states aren't on/off signals, so they're active unless unavailable.
      const isUnavailable = _BADGE_UNAVAILABLE.has(state);
      const isOnOffDomain = _BADGE_ONOFF_DOMAINS.has(this.def.domain);
      const isActive = !isUnavailable && (!isOnOffDomain || !_BADGE_INACTIVE.has(state));

      // data-state="active|inactive" drives the accent treatment in CSS.
      // --ndl-badge-color drives the icon glyph, the icon-circle tint, and
      // the badge background/border when active. Read from CSS by every
      // svg/background rule, so the user's chosen color cascades cleanly.
      if (this.#badgeEl) {
        this.#badgeEl.dataset.state = isActive ? "active" : "inactive";
        if (colorKey !== "auto") {
          const c = _BADGE_ICON_COLORS[colorKey] ?? _BADGE_ICON_COLORS.auto;
          this.#badgeEl.style.setProperty("--ndl-badge-color", c);
        } else {
          this.#badgeEl.style.removeProperty("--ndl-badge-color");
        }
      }

      if (this.#iconEl) {
        const fb = _BADGE_DOMAIN_FB[this.def.domain] ?? "mdi:help-circle";
        const rawIcon = this.def.icon_state_map?.[state] ?? this.def.icon ?? fb;
        this.renderIcon(this.resolveIcon(rawIcon, fb), "badge-icon");
      }
      const uom = attributes?.unit_of_measurement ?? this.def.unit_of_measurement ?? "";
      const label = this.formatStateLabel(state);
      const stateText = uom ? `${label} ${uom}` : label;
      if (this.#stateEl) this.#stateEl.textContent = stateText;
      if (this.#badgeEl) this.#badgeEl.title = `${this.def.friendly_name}: ${stateText}`;
      this.announceState(`${this.def.friendly_name}, ${state}`);
    }
  }

  // ---------------------------------------------------------------------------
  // Register all Nodalia renderers
  // ---------------------------------------------------------------------------

  HArvest._renderers = HArvest._renderers || {};
  const _rendererKey = (document.currentScript && document.currentScript.dataset.rendererId) || "nodalia";
  HArvest._renderers[_rendererKey] = {
    "light":          LightCard,
    "fan":            FanCard,
    "climate":        ClimateCard,
    "harvest_action": HarvestActionCard,
    "binary_sensor":  BinarySensorCard,
    "cover":          CoverCard,
    "input_boolean":  SwitchCard,
    "lock":           LockCard,
    "input_number":   InputNumberCard,
    "input_select":   InputSelectCard,
    "select":         InputSelectCard,
    "media_player":   MediaPlayerCard,
    "remote":         RemoteCard,
    "sensor":         SensorCard,
    "switch":         SwitchCard,
    "timer":          TimerCard,
    "weather":        WeatherCard,
    "generic":        GenericCard,
    "badge":          BadgeCard,
    _capabilities: {
      fan:          { display_modes: ["on-off", "continuous"] },
      input_number: { display_modes: ["slider", "buttons"] },
      input_select: { display_modes: ["pills", "dropdown"] },
      select:       { display_modes: ["pills", "dropdown"] },
      light:        { features: ["brightness", "color_temp", "rgb"] },
      climate:      { features: ["hvac_modes", "presets", "fan_mode", "swing_mode"] },
      cover:        { features: ["position", "tilt"] },
      media_player: { features: ["transport", "volume", "source"] },
    },
  };
})();
