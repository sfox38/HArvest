<?php
/**
 * bootstrap.php - Test bootstrap for HArvest WordPress plugin tests.
 *
 * Defines all WordPress constants and function stubs needed by the plugin
 * classes. Uses a global option store to simulate get_option/add_option/
 * delete_option without a live WordPress installation.
 */

// ---------------------------------------------------------------------------
// Constants required by the plugin files.
// ---------------------------------------------------------------------------

define( 'ABSPATH', __DIR__ . DIRECTORY_SEPARATOR );
define( 'HARVEST_VERSION', '1.0.0' );
define( 'HARVEST_PLUGIN_DIR', dirname( __DIR__ ) . '/harvest/' );
define( 'HARVEST_PLUGIN_URL', 'http://example.com/wp-content/plugins/harvest/' );
define( 'WP_UNINSTALL_PLUGIN', true );

// ---------------------------------------------------------------------------
// Global state stores (reset in each test's setUp).
// ---------------------------------------------------------------------------

$GLOBALS['_harvest_options']   = [];
$GLOBALS['_harvest_scripts']   = [];
$GLOBALS['_harvest_actions']   = [];
$GLOBALS['_harvest_filters']   = [];
$GLOBALS['_harvest_shortcodes'] = [];
$GLOBALS['_harvest_user_can']  = true;

// ---------------------------------------------------------------------------
// WordPress options API stubs.
// ---------------------------------------------------------------------------

function get_option( string $option, $default = false ) {
    return $GLOBALS['_harvest_options'][ $option ] ?? $default;
}

function add_option( string $option, $value = '' ): bool {
    if ( array_key_exists( $option, $GLOBALS['_harvest_options'] ) ) {
        return false;
    }
    $GLOBALS['_harvest_options'][ $option ] = $value;
    return true;
}

function update_option( string $option, $value ): bool {
    $GLOBALS['_harvest_options'][ $option ] = $value;
    return true;
}

function delete_option( string $option ): bool {
    if ( array_key_exists( $option, $GLOBALS['_harvest_options'] ) ) {
        unset( $GLOBALS['_harvest_options'][ $option ] );
        return true;
    }
    return false;
}

// ---------------------------------------------------------------------------
// WordPress hook stubs.
// ---------------------------------------------------------------------------

function add_action( string $hook, $callback, int $priority = 10, int $accepted_args = 1 ): bool {
    $GLOBALS['_harvest_actions'][] = [
        'hook'     => $hook,
        'callback' => $callback,
        'priority' => $priority,
    ];
    return true;
}

function add_filter( string $hook, $callback, int $priority = 10, int $accepted_args = 1 ): bool {
    $GLOBALS['_harvest_filters'][] = [
        'hook'     => $hook,
        'callback' => $callback,
        'priority' => $priority,
    ];
    return true;
}

function add_shortcode( string $tag, $callback ): void {
    $GLOBALS['_harvest_shortcodes'][ $tag ] = $callback;
}

function do_shortcode( string $content ): string {
    return $content;
}

// ---------------------------------------------------------------------------
// WordPress user capability stub.
// ---------------------------------------------------------------------------

function current_user_can( string $capability ): bool {
    return (bool) ( $GLOBALS['_harvest_user_can'] ?? true );
}

// ---------------------------------------------------------------------------
// WordPress escaping stubs (simplified - encode special HTML chars).
// ---------------------------------------------------------------------------

function esc_attr( string $text ): string {
    return htmlspecialchars( $text, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8' );
}

function esc_html( string $text ): string {
    return htmlspecialchars( $text, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8' );
}

function esc_url_raw( string $url ): string {
    return trim( $url );
}

function esc_html_e( string $text, string $domain = 'default' ): void {
    echo htmlspecialchars( $text, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8' );
}

// ---------------------------------------------------------------------------
// WordPress translation stubs.
// ---------------------------------------------------------------------------

function __( string $text, string $domain = 'default' ): string {
    return $text;
}

function esc_html__( string $text, string $domain = 'default' ): string {
    return htmlspecialchars( $text, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8' );
}

// ---------------------------------------------------------------------------
// WordPress script enqueueing stub.
// ---------------------------------------------------------------------------

function wp_enqueue_script(
    string $handle,
    string $src = '',
    array $deps = [],
    $ver = false,
    bool $in_footer = false
): void {
    $GLOBALS['_harvest_scripts'][] = [
        'handle'    => $handle,
        'src'       => $src,
        'deps'      => $deps,
        'ver'       => $ver,
        'in_footer' => $in_footer,
    ];
}

// ---------------------------------------------------------------------------
// WordPress settings/admin stubs.
// ---------------------------------------------------------------------------

function register_setting( string $option_group, string $option_name, array $args = [] ): void {}
function add_options_page( string $page_title, string $menu_title, string $capability, string $menu_slug, $callback = '' ): bool { return true; }
function settings_fields( string $option_group ): void {}
function settings_errors( string $setting = '', bool $sanitize = false, bool $hide_on_update = false ): void {}
function get_admin_page_title(): string { return 'HArvest Settings'; }
function submit_button( ?string $text = null, string $type = 'primary', string $name = 'submit', bool $wrap = true, $other_attributes = null ): void {}

function checked( $checked, $current = true, bool $echo = true ): string {
    $result = ( $checked == $current ) ? ' checked="checked"' : '';
    if ( $echo ) {
        echo $result;
    }
    return $result;
}

// ---------------------------------------------------------------------------
// WordPress shortcode_atts stub - mirrors WP behaviour (no filters).
// ---------------------------------------------------------------------------

function shortcode_atts( array $pairs, $atts, string $shortcode = '' ): array {
    $atts = (array) $atts;
    $out  = [];
    foreach ( $pairs as $name => $default ) {
        $out[ $name ] = array_key_exists( $name, $atts ) ? $atts[ $name ] : $default;
    }
    return $out;
}

// ---------------------------------------------------------------------------
// WordPress plugin lifecycle stubs.
// ---------------------------------------------------------------------------

function register_activation_hook( string $file, $callback ): void {}
function register_deactivation_hook( string $file, $callback ): void {}
function plugin_dir_path( string $file ): string { return dirname( $file ) . DIRECTORY_SEPARATOR; }
function plugin_dir_url( string $file ): string {
    return 'http://example.com/wp-content/plugins/' . basename( dirname( $file ) ) . '/';
}

// ---------------------------------------------------------------------------
// Autoloader and plugin class includes.
// ---------------------------------------------------------------------------

require_once dirname( __DIR__ ) . '/vendor/autoload.php';

require_once dirname( __DIR__ ) . '/includes/class-harvest-settings.php';
require_once dirname( __DIR__ ) . '/includes/class-harvest-shortcode.php';
require_once dirname( __DIR__ ) . '/includes/class-harvest-assets.php';
require_once dirname( __DIR__ ) . '/includes/class-harvest-csp.php';
