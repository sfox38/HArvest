<?php
/**
 * CspTest.php - Tests for Harvest_Csp.
 */

use PHPUnit\Framework\TestCase;

class CspTest extends TestCase {

    protected function setUp(): void {
        parent::setUp();
        $GLOBALS['_harvest_options'] = [
            'harvest_ha_url' => 'https://ha.example.com',
        ];
    }

    // -----------------------------------------------------------------------
    // modify_csp_headers - empty HA URL
    // -----------------------------------------------------------------------

    public function test_empty_ha_url_returns_headers_unchanged(): void {
        $GLOBALS['_harvest_options']['harvest_ha_url'] = '';
        $headers = [ 'X-Frame-Options' => 'SAMEORIGIN' ];
        $result  = Harvest_Csp::modify_csp_headers( $headers );
        $this->assertSame( $headers, $result );
    }

    public function test_empty_ha_url_does_not_add_csp_header(): void {
        $GLOBALS['_harvest_options']['harvest_ha_url'] = '';
        $result = Harvest_Csp::modify_csp_headers( [] );
        $this->assertArrayNotHasKey( 'Content-Security-Policy', $result );
    }

    // -----------------------------------------------------------------------
    // modify_csp_headers - https to wss conversion
    // -----------------------------------------------------------------------

    public function test_https_url_is_converted_to_wss_in_csp(): void {
        $GLOBALS['_harvest_options']['harvest_ha_url'] = 'https://ha.example.com';
        $result = Harvest_Csp::modify_csp_headers( [] );
        $this->assertStringContainsString( 'wss://ha.example.com', $result['Content-Security-Policy'] );
    }

    public function test_http_url_is_converted_to_wss_in_csp(): void {
        $GLOBALS['_harvest_options']['harvest_ha_url'] = 'http://ha.local';
        $result = Harvest_Csp::modify_csp_headers( [] );
        $this->assertStringContainsString( 'wss://ha.local', $result['Content-Security-Policy'] );
    }

    public function test_https_prefix_is_not_present_in_csp_connect_src(): void {
        $GLOBALS['_harvest_options']['harvest_ha_url'] = 'https://ha.example.com';
        $result = Harvest_Csp::modify_csp_headers( [] );
        $csp = $result['Content-Security-Policy'];
        // The https URL should not appear verbatim - only the wss version.
        $this->assertStringNotContainsString( 'https://ha.example.com', $csp );
    }

    // -----------------------------------------------------------------------
    // modify_csp_headers - no existing CSP header
    // -----------------------------------------------------------------------

    public function test_no_existing_csp_creates_connect_src_header(): void {
        $result = Harvest_Csp::modify_csp_headers( [] );
        $this->assertArrayHasKey( 'Content-Security-Policy', $result );
    }

    public function test_no_existing_csp_new_header_contains_connect_src(): void {
        $result = Harvest_Csp::modify_csp_headers( [] );
        $this->assertStringContainsString( 'connect-src', $result['Content-Security-Policy'] );
    }

    public function test_no_existing_csp_new_header_includes_self(): void {
        $result = Harvest_Csp::modify_csp_headers( [] );
        $this->assertStringContainsString( "'self'", $result['Content-Security-Policy'] );
    }

    public function test_no_existing_csp_existing_headers_are_preserved(): void {
        $headers = [ 'X-Frame-Options' => 'SAMEORIGIN' ];
        $result  = Harvest_Csp::modify_csp_headers( $headers );
        $this->assertArrayHasKey( 'X-Frame-Options', $result );
        $this->assertSame( 'SAMEORIGIN', $result['X-Frame-Options'] );
    }

    // -----------------------------------------------------------------------
    // modify_csp_headers - existing CSP without connect-src
    // -----------------------------------------------------------------------

    public function test_existing_csp_without_connect_src_appends_directive(): void {
        $headers = [ 'Content-Security-Policy' => "default-src 'self'" ];
        $result  = Harvest_Csp::modify_csp_headers( $headers );
        $this->assertStringContainsString( 'connect-src', $result['Content-Security-Policy'] );
    }

    public function test_existing_csp_without_connect_src_preserves_existing_directives(): void {
        $headers = [ 'Content-Security-Policy' => "default-src 'self'" ];
        $result  = Harvest_Csp::modify_csp_headers( $headers );
        $this->assertStringContainsString( "default-src 'self'", $result['Content-Security-Policy'] );
    }

    public function test_existing_csp_without_connect_src_adds_wss_url(): void {
        $headers = [ 'Content-Security-Policy' => "default-src 'self'" ];
        $result  = Harvest_Csp::modify_csp_headers( $headers );
        $this->assertStringContainsString( 'wss://ha.example.com', $result['Content-Security-Policy'] );
    }

    // -----------------------------------------------------------------------
    // modify_csp_headers - existing CSP with connect-src
    // -----------------------------------------------------------------------

    public function test_existing_connect_src_gets_wss_url_appended(): void {
        $headers = [ 'Content-Security-Policy' => "default-src 'self'; connect-src 'self' https://api.example.com" ];
        $result  = Harvest_Csp::modify_csp_headers( $headers );
        $this->assertStringContainsString( 'wss://ha.example.com', $result['Content-Security-Policy'] );
    }

    public function test_existing_connect_src_keeps_original_values(): void {
        $headers = [ 'Content-Security-Policy' => "connect-src 'self' https://api.example.com" ];
        $result  = Harvest_Csp::modify_csp_headers( $headers );
        $this->assertStringContainsString( 'https://api.example.com', $result['Content-Security-Policy'] );
    }

    // -----------------------------------------------------------------------
    // modify_csp_headers - URL already present (idempotency)
    // -----------------------------------------------------------------------

    public function test_url_already_in_csp_returns_policy_unchanged(): void {
        $policy  = "connect-src 'self' wss://ha.example.com";
        $headers = [ 'Content-Security-Policy' => $policy ];
        $result  = Harvest_Csp::modify_csp_headers( $headers );
        $this->assertSame( $policy, $result['Content-Security-Policy'] );
    }

    public function test_calling_modify_twice_does_not_duplicate_url(): void {
        $headers = [];
        $result  = Harvest_Csp::modify_csp_headers( $headers );
        $result2 = Harvest_Csp::modify_csp_headers( $result );
        $count1  = substr_count( $result['Content-Security-Policy'], 'wss://ha.example.com' );
        $count2  = substr_count( $result2['Content-Security-Policy'], 'wss://ha.example.com' );
        $this->assertSame( $count1, $count2 );
    }

    // -----------------------------------------------------------------------
    // init registers the wp_headers filter
    // -----------------------------------------------------------------------

    public function test_init_registers_wp_headers_filter(): void {
        $GLOBALS['_harvest_filters'] = [];
        Harvest_Csp::init();
        $hooks = array_column( $GLOBALS['_harvest_filters'], 'hook' );
        $this->assertContains( 'wp_headers', $hooks );
    }
}
