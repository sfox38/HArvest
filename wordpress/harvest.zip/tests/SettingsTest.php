<?php
/**
 * SettingsTest.php - Tests for Harvest_Settings.
 */

use PHPUnit\Framework\TestCase;

class SettingsTest extends TestCase {

    protected function setUp(): void {
        parent::setUp();
        $GLOBALS['_harvest_options'] = [];
        $GLOBALS['_harvest_actions'] = [];
    }

    // -----------------------------------------------------------------------
    // sanitize_ha_url
    // -----------------------------------------------------------------------

    public function test_sanitize_ha_url_strips_trailing_slash(): void {
        $result = Harvest_Settings::sanitize_ha_url( 'https://ha.example.com/' );
        $this->assertSame( 'https://ha.example.com', $result );
    }

    public function test_sanitize_ha_url_strips_multiple_trailing_slashes(): void {
        $result = Harvest_Settings::sanitize_ha_url( 'https://ha.example.com///' );
        $this->assertSame( 'https://ha.example.com', $result );
    }

    public function test_sanitize_ha_url_trims_whitespace(): void {
        $result = Harvest_Settings::sanitize_ha_url( '  https://ha.example.com  ' );
        $this->assertSame( 'https://ha.example.com', $result );
    }

    public function test_sanitize_ha_url_passes_clean_url_unchanged(): void {
        $result = Harvest_Settings::sanitize_ha_url( 'https://ha.example.com' );
        $this->assertSame( 'https://ha.example.com', $result );
    }

    public function test_sanitize_ha_url_empty_returns_empty(): void {
        $result = Harvest_Settings::sanitize_ha_url( '' );
        $this->assertSame( '', $result );
    }

    public function test_sanitize_ha_url_preserves_port(): void {
        $result = Harvest_Settings::sanitize_ha_url( 'https://ha.example.com:8123/' );
        $this->assertSame( 'https://ha.example.com:8123', $result );
    }

    // -----------------------------------------------------------------------
    // sanitize_widget_source
    // -----------------------------------------------------------------------

    public function test_sanitize_widget_source_accepts_bundled(): void {
        $this->assertSame( 'bundled', Harvest_Settings::sanitize_widget_source( 'bundled' ) );
    }

    public function test_sanitize_widget_source_accepts_custom(): void {
        $this->assertSame( 'custom', Harvest_Settings::sanitize_widget_source( 'custom' ) );
    }

    public function test_sanitize_widget_source_rejects_invalid_returns_bundled(): void {
        $this->assertSame( 'bundled', Harvest_Settings::sanitize_widget_source( 'remote' ) );
    }

    public function test_sanitize_widget_source_rejects_empty_returns_bundled(): void {
        $this->assertSame( 'bundled', Harvest_Settings::sanitize_widget_source( '' ) );
    }

    public function test_sanitize_widget_source_rejects_cdn_returns_bundled(): void {
        // 'cdn' was removed as a valid source option.
        $this->assertSame( 'bundled', Harvest_Settings::sanitize_widget_source( 'cdn' ) );
    }

    // -----------------------------------------------------------------------
    // get_ha_url
    // -----------------------------------------------------------------------

    public function test_get_ha_url_returns_stored_option(): void {
        $GLOBALS['_harvest_options']['harvest_ha_url'] = 'https://myhome.duckdns.org';
        $this->assertSame( 'https://myhome.duckdns.org', Harvest_Settings::get_ha_url() );
    }

    public function test_get_ha_url_returns_empty_string_when_not_set(): void {
        $this->assertSame( '', Harvest_Settings::get_ha_url() );
    }

    // -----------------------------------------------------------------------
    // get_widget_source
    // -----------------------------------------------------------------------

    public function test_get_widget_source_returns_stored_option(): void {
        $GLOBALS['_harvest_options']['harvest_widget_source'] = 'custom';
        $this->assertSame( 'custom', Harvest_Settings::get_widget_source() );
    }

    public function test_get_widget_source_returns_bundled_as_default(): void {
        // get_option returns false when not set, and (string) false is ''.
        // Harvest_Settings::get_widget_source() casts to string so returns ''.
        // This mirrors real WP behaviour when the option row does not exist.
        $result = Harvest_Settings::get_widget_source();
        $this->assertSame( 'bundled', $result );
    }

    // -----------------------------------------------------------------------
    // init registers expected hooks
    // -----------------------------------------------------------------------

    public function test_init_registers_admin_menu_action(): void {
        $GLOBALS['_harvest_actions'] = [];
        Harvest_Settings::init();
        $hooks = array_column( $GLOBALS['_harvest_actions'], 'hook' );
        $this->assertContains( 'admin_menu', $hooks );
    }

    public function test_init_registers_admin_init_action(): void {
        $GLOBALS['_harvest_actions'] = [];
        Harvest_Settings::init();
        $hooks = array_column( $GLOBALS['_harvest_actions'], 'hook' );
        $this->assertContains( 'admin_init', $hooks );
    }
}
