<?php
/**
 * AssetsTest.php - Tests for Harvest_Assets.
 */

use PHPUnit\Framework\TestCase;

class AssetsTest extends TestCase {

    protected function setUp(): void {
        parent::setUp();
        $GLOBALS['_harvest_options'] = [
            'harvest_widget_source' => 'bundled',
        ];
        $GLOBALS['_harvest_scripts'] = [];
        $this->resetEnqueuedFlag();
    }

    private function resetEnqueuedFlag(): void {
        $ref = new ReflectionProperty( Harvest_Assets::class, 'enqueued' );
        $ref->setValue( null, false );
    }

    // -----------------------------------------------------------------------
    // enqueue - bundled mode
    // -----------------------------------------------------------------------

    public function test_enqueue_bundled_calls_wp_enqueue_script(): void {
        Harvest_Assets::enqueue();
        $this->assertCount( 1, $GLOBALS['_harvest_scripts'] );
    }

    public function test_enqueue_bundled_uses_harvest_widget_handle(): void {
        Harvest_Assets::enqueue();
        $this->assertSame( 'harvest-widget', $GLOBALS['_harvest_scripts'][0]['handle'] );
    }

    public function test_enqueue_bundled_src_contains_plugin_url(): void {
        Harvest_Assets::enqueue();
        $src = $GLOBALS['_harvest_scripts'][0]['src'];
        $this->assertStringContainsString( HARVEST_PLUGIN_URL, $src );
    }

    public function test_enqueue_bundled_src_points_to_harvest_min_js(): void {
        Harvest_Assets::enqueue();
        $src = $GLOBALS['_harvest_scripts'][0]['src'];
        $this->assertStringContainsString( 'harvest.min.js', $src );
    }

    public function test_enqueue_bundled_version_is_harvest_version(): void {
        Harvest_Assets::enqueue();
        $this->assertSame( HARVEST_VERSION, $GLOBALS['_harvest_scripts'][0]['ver'] );
    }

    public function test_enqueue_bundled_loads_in_footer(): void {
        Harvest_Assets::enqueue();
        $this->assertTrue( $GLOBALS['_harvest_scripts'][0]['in_footer'] );
    }

    // -----------------------------------------------------------------------
    // enqueue - custom URL mode
    // -----------------------------------------------------------------------

    public function test_enqueue_custom_uses_provided_src(): void {
        $GLOBALS['_harvest_options']['harvest_widget_source'] = 'custom';
        $GLOBALS['_harvest_options']['harvest_widget_custom_url'] = 'https://example.com/harvest.min.js';
        Harvest_Assets::enqueue();
        $src = $GLOBALS['_harvest_scripts'][0]['src'];
        $this->assertSame( 'https://example.com/harvest.min.js', $src );
    }

    public function test_enqueue_custom_version_is_null(): void {
        $GLOBALS['_harvest_options']['harvest_widget_source'] = 'custom';
        $GLOBALS['_harvest_options']['harvest_widget_custom_url'] = 'https://example.com/harvest.min.js';
        Harvest_Assets::enqueue();
        $this->assertNull( $GLOBALS['_harvest_scripts'][0]['ver'] );
    }

    public function test_enqueue_custom_loads_in_footer(): void {
        $GLOBALS['_harvest_options']['harvest_widget_source'] = 'custom';
        $GLOBALS['_harvest_options']['harvest_widget_custom_url'] = 'https://example.com/harvest.min.js';
        Harvest_Assets::enqueue();
        $this->assertTrue( $GLOBALS['_harvest_scripts'][0]['in_footer'] );
    }

    public function test_enqueue_custom_without_url_falls_back_to_bundled(): void {
        $GLOBALS['_harvest_options']['harvest_widget_source'] = 'custom';
        $GLOBALS['_harvest_options']['harvest_widget_custom_url'] = '';
        Harvest_Assets::enqueue();
        $src = $GLOBALS['_harvest_scripts'][0]['src'];
        $this->assertStringContainsString( HARVEST_PLUGIN_URL, $src );
    }

    // -----------------------------------------------------------------------
    // enqueue - idempotency
    // -----------------------------------------------------------------------

    public function test_enqueue_called_twice_only_enqueues_once(): void {
        Harvest_Assets::enqueue();
        Harvest_Assets::enqueue();
        $this->assertCount( 1, $GLOBALS['_harvest_scripts'] );
    }

    public function test_enqueue_called_three_times_only_enqueues_once(): void {
        Harvest_Assets::enqueue();
        Harvest_Assets::enqueue();
        Harvest_Assets::enqueue();
        $this->assertCount( 1, $GLOBALS['_harvest_scripts'] );
    }

    // -----------------------------------------------------------------------
    // maybe_enqueue_from_footer
    // -----------------------------------------------------------------------

    public function test_maybe_enqueue_from_footer_does_nothing_when_not_enqueued(): void {
        Harvest_Assets::maybe_enqueue_from_footer();
        $this->assertCount( 0, $GLOBALS['_harvest_scripts'] );
    }

    public function test_maybe_enqueue_from_footer_does_nothing_after_enqueue(): void {
        Harvest_Assets::enqueue();
        $countAfterEnqueue = count( $GLOBALS['_harvest_scripts'] );
        Harvest_Assets::maybe_enqueue_from_footer();
        $this->assertCount( $countAfterEnqueue, $GLOBALS['_harvest_scripts'] );
    }
}
